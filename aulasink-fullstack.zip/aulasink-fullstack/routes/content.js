/* =====================================================================
 * AulaSink · routes/content.js   (montado en /api/courses)
 * ---------------------------------------------------------------------
 * Temario (lecciones) y tareas de un curso.
 *
 *   GET    /:cid/lessons              lista (estudiante: solo las habilitadas, con mi avance)
 *   POST   /:cid/lessons              [profesor] crear
 *   PUT    /:cid/lessons/order        [profesor] reordenar { ids: [...] }
 *   GET    /:cid/lessons/:tid         detalle
 *   PUT    /:cid/lessons/:tid         [profesor] editar (incluye habilitar / deshabilitar)
 *   DELETE /:cid/lessons/:tid         [profesor] eliminar
 *
 *   GET/POST /:cid/assignments, GET/PUT/DELETE /:cid/assignments/:tid   (igual, con fecha límite)
 *
 * Un estudiante NUNCA recibe la respuesta correcta antes de entregar: el servidor
 * quita `correct` y `explanation` y solo los devuelve junto con su entrega.
 * ===================================================================== */
'use strict';

const express = require('express');
const { HttpError } = require('../lib/http');
const S = require('../lib/security');
const U = require('../lib/util');
const Q = require('../lib/questions');

const KINDS = {
  lessons:     { type: 'lesson',     table: 'course_lessons', label: 'lección' },
  assignments: { type: 'assignment', table: 'assignments',    label: 'tarea' }
};

const DEFAULT_TASK_QUESTION = () => ({
  type: 'handwritten', prompt: 'Tu respuesta: escribe y/o adjunta fotos de tu trabajo.', points: 10
});

/** Resumen de una entrega (lo que cabe en listas). */
const subSummary = s => (s ? {
  id: s.id, status: s.status, progressPct: s.progress_pct, scorePct: U.num(s.score_pct),
  attempts: s.attempts, submittedAt: s.submitted_at, gradedAt: s.graded_at
} : null);

const hasManual = questions => questions.some(Q.isManual);
const canSave = sub => !sub || sub.status === 'draft' || sub.status === 'returned';
/** Una lección que se califica sola se puede repetir las veces que se quiera. */
const canSubmit = (sub, type, questions) => canSave(sub) || (type === 'lesson' && !hasManual(questions));

module.exports = function createContentRouter({ pool, access }) {
  const router = express.Router();

  const paragraphs = content => String(content || '').split(/\n\s*\n/).map(p => p.trim()).filter(Boolean);

  function rowToItem(kind, row) {
    const item = {
      id: row.id, courseId: row.course_id, title: row.title, published: Boolean(row.published),
      questions: U.parseJson(row.questions, []), updatedAt: row.updated_at
    };
    if (kind.type === 'lesson') {
      item.minutes = row.minutes;
      item.position = row.position;
      item.content = row.content;
    } else {
      item.instructions = row.instructions;
      item.dueAt = row.due_at;
    }
    return item;
  }

  async function loadItem(kind, courseId, tid, { publishedOnly }) {
    const [rows] = await pool.execute(
      `SELECT * FROM ${kind.table} WHERE id = ? AND course_id = ?${publishedOnly ? ' AND published = 1' : ''}`,
      [U.idParam(tid), courseId]);
    if (!rows[0]) throw new HttpError(404, 'No encontrado');
    return rows[0];
  }

  async function findSubmission(studentId, type, targetId) {
    const [rows] = await pool.execute(
      'SELECT * FROM submissions WHERE student_id = ? AND target_type = ? AND target_id = ?', [studentId, type, targetId]);
    return rows[0] || null;
  }

  /** Vista de un estudiante: preguntas sin respuestas + su propia entrega. */
  function studentDetail(kind, row, sub) {
    const item = rowToItem(kind, row);
    const questions = item.questions;
    const out = { ...item, questions: Q.publicQuestions(questions), hasManual: hasManual(questions) };
    if (kind.type === 'lesson') out.paragraphs = paragraphs(item.content);
    delete out.content;

    if (!sub) return { ...out, submission: null, canSave: true, canSubmit: true };

    const answers = U.parseJson(sub.answers, {});
    const submission = {
      ...subSummary(sub), answers,
      autoPoints: U.num(sub.auto_points), manualPoints: U.num(sub.manual_points), totalPoints: U.num(sub.total_points),
      late: Boolean(kind.type === 'assignment' && row.due_at && sub.submitted_at && new Date(sub.submitted_at) > new Date(row.due_at))
    };
    if (sub.status === 'submitted' || sub.status === 'graded') submission.review = Q.reviewOf(questions, answers);
    if (sub.status === 'graded') submission.grading = U.parseJson(sub.grading, {});
    if (sub.status === 'graded' || sub.status === 'returned') submission.teacherComment = sub.teacher_comment;
    return { ...out, submission, canSave: canSave(sub), canSubmit: canSubmit(sub, kind.type, questions) };
  }

  for (const [segment, kind] of Object.entries(KINDS)) {
    const base = `/:cid/${segment}`;

    /* ---------- Lista ---------- */
    router.get(base, async (req, res) => {
      const { course, role } = await access.loadCourse(req);
      const order = kind.type === 'lesson' ? 'position, created_at' : 'due_at IS NULL, due_at, created_at';
      const [rows] = await pool.execute(
        `SELECT * FROM ${kind.table} WHERE course_id = ?${role === 'student' ? ' AND published = 1' : ''} ORDER BY ${order}`,
        [course.id]);

      const subs = new Map();
      if (role === 'student') {
        const [mine] = await pool.execute(
          'SELECT * FROM submissions WHERE course_id = ? AND student_id = ? AND target_type = ?', [course.id, req.user.id, kind.type]);
        mine.forEach(s => subs.set(s.target_id, s));
      }
      const counts = new Map();                     // profesor: entregas por estado
      if (role === 'teacher') {
        const [grouped] = await pool.execute(
          `SELECT target_id, status, COUNT(*) AS n FROM submissions
            WHERE course_id = ? AND target_type = ? GROUP BY target_id, status`, [course.id, kind.type]);
        for (const g of grouped) {
          const c = counts.get(g.target_id) || {};
          c[g.status] = Number(g.n);
          counts.set(g.target_id, c);
        }
      }

      res.json({ items: rows.map(row => {
        const item = rowToItem(kind, row);
        const out = { id: item.id, title: item.title, published: item.published, questionCount: item.questions.length,
                      hasManual: hasManual(item.questions) };
        if (kind.type === 'lesson') { out.minutes = item.minutes; out.position = item.position; }
        else { out.dueAt = item.dueAt; }
        if (role === 'student') out.submission = subSummary(subs.get(item.id));
        else out.counts = counts.get(item.id) || {};
        return out;
      }) });
    });

    /* ---------- Detalle ---------- */
    router.get(`${base}/:tid`, async (req, res) => {
      if (kind.type === 'lesson' && req.params.tid === 'order') throw new HttpError(404, 'No encontrado');
      const { course, role } = await access.loadCourse(req);
      const row = await loadItem(kind, course.id, req.params.tid, { publishedOnly: role === 'student' });
      if (role === 'teacher') return res.json({ role, item: rowToItem(kind, row) });
      res.json({ role, item: studentDetail(kind, row, await findSubmission(req.user.id, kind.type, row.id)) });
    });

    /* ---------- Crear / editar / eliminar (profesor) ---------- */
    function parseBody(b) {
      const title = U.requireText(b.title, 160, `Escribe el título de la ${kind.label}.`);
      let questions = Q.sanitizeQuestions(b.questions);
      const common = { title, questions, published: b.published ? 1 : 0 };
      if (kind.type === 'lesson') {
        const content = typeof b.content === 'string' ? b.content.trim().slice(0, 20000) : '';
        if (!content && !questions.length) throw new HttpError(400, 'Añade contenido de estudio o al menos una pregunta.');
        const minutes = Math.min(240, Math.max(1, parseInt(b.minutes, 10) || 5));
        return { ...common, content, minutes };
      }
      const instructions = typeof b.instructions === 'string' ? b.instructions.trim().slice(0, 10000) : '';
      if (!instructions && !questions.length) throw new HttpError(400, 'Escribe las instrucciones o añade al menos una pregunta.');
      if (!questions.length) questions = Q.sanitizeQuestions([DEFAULT_TASK_QUESTION()]);   // toda tarea se puede entregar
      return { ...common, questions, instructions, dueAt: U.optionalDate(b.dueAt, 'La fecha límite no es válida.') };
    }

    async function applyUpdate(courseId, itemId, d) {
      const now = new Date();
      if (kind.type === 'lesson') {
        await pool.execute(
          `UPDATE course_lessons SET title = ?, minutes = ?, content = ?, questions = ?, published = ?, updated_at = ?
            WHERE id = ? AND course_id = ?`,
          [d.title, d.minutes, d.content, JSON.stringify(d.questions), d.published, now, itemId, courseId]);
      } else {
        await pool.execute(
          `UPDATE assignments SET title = ?, instructions = ?, questions = ?, due_at = ?, published = ?, updated_at = ?
            WHERE id = ? AND course_id = ?`,
          [d.title, d.instructions, JSON.stringify(d.questions), d.dueAt, d.published, now, itemId, courseId]);
      }
    }

    router.post(base, async (req, res) => {
      const { course } = await access.loadCourse(req, { teacherOnly: true });
      const d = parseBody(req.body || {});
      // El navegador puede enviar su propio id: si la petición se repite (cola sin conexión,
      // reintento por mala señal) no se crea un duplicado: se actualiza con lo último enviado.
      const wanted = req.body && req.body.id;
      const id = typeof wanted === 'string' && /^[A-Za-z0-9_-]{8,64}$/.test(wanted) ? wanted : S.newId();
      const [dup] = await pool.execute(`SELECT course_id FROM ${kind.table} WHERE id = ?`, [id]);
      if (dup.length) {
        if (dup[0].course_id !== course.id) throw new HttpError(409, 'Ese identificador ya está en uso.');
        await applyUpdate(course.id, id, d);
        return res.status(200).json({ id, existed: true });
      }
      const now = new Date();
      if (kind.type === 'lesson') {
        const [[{ next }]] = await pool.query('SELECT COALESCE(MAX(position), 0) + 1 AS next FROM course_lessons WHERE course_id = ?', [course.id]);
        await pool.execute(
          `INSERT INTO course_lessons (id, course_id, position, title, minutes, content, questions, published, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [id, course.id, next, d.title, d.minutes, d.content, JSON.stringify(d.questions), d.published, now, now]);
      } else {
        await pool.execute(
          `INSERT INTO assignments (id, course_id, title, instructions, questions, due_at, published, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [id, course.id, d.title, d.instructions, JSON.stringify(d.questions), d.dueAt, d.published, now, now]);
      }
      res.status(201).json({ id });
    });

    // Reordenar el temario (se declara antes de PUT /:tid)
    if (kind.type === 'lesson') {
      router.put(`${base}/order`, async (req, res) => {
        const { course } = await access.loadCourse(req, { teacherOnly: true });
        const ids = req.body && req.body.ids;
        if (!Array.isArray(ids) || ids.length > 500 || !ids.every(i => typeof i === 'string')) throw new HttpError(400, 'Orden inválido.');
        const [own] = await pool.execute('SELECT id FROM course_lessons WHERE course_id = ?', [course.id]);
        const valid = new Set(own.map(r => r.id));
        const ordered = ids.filter(id => valid.has(id));
        for (let i = 0; i < ordered.length; i++) {
          await pool.execute('UPDATE course_lessons SET position = ? WHERE id = ? AND course_id = ?', [i + 1, ordered[i], course.id]);
        }
        res.json({ ok: true });
      });
    }

    router.put(`${base}/:tid`, async (req, res) => {
      const { course } = await access.loadCourse(req, { teacherOnly: true });
      const row = await loadItem(kind, course.id, req.params.tid, { publishedOnly: false });
      const d = parseBody(req.body || {});
      await applyUpdate(course.id, row.id, d);
      res.json({ ok: true });
    });

    router.delete(`${base}/:tid`, async (req, res) => {
      const { course } = await access.loadCourse(req, { teacherOnly: true });
      const row = await loadItem(kind, course.id, req.params.tid, { publishedOnly: false });
      const conn = await pool.getConnection();
      try {
        await conn.beginTransaction();
        await conn.execute('DELETE FROM submissions WHERE course_id = ? AND target_type = ? AND target_id = ?', [course.id, kind.type, row.id]);
        await conn.execute(`DELETE FROM ${kind.table} WHERE id = ? AND course_id = ?`, [row.id, course.id]);
        await conn.commit();
      } catch (err) {
        await conn.rollback().catch(() => {});
        throw err;
      } finally {
        conn.release();
      }
      res.json({ ok: true });
    });
  }

  return router;
};
module.exports.helpers = { subSummary, hasManual, canSave, canSubmit, KINDS };
