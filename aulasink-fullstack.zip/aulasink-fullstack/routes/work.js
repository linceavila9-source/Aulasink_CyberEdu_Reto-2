/* =====================================================================
 * AulaSink · routes/work.js   (montado en /api/courses)
 * ---------------------------------------------------------------------
 * Desarrollo de lecciones y tareas por parte del estudiante.
 *
 *   PUT  /:cid/lessons|assignments/:tid/answers      guardar avance (borrador)
 *   POST /:cid/lessons|assignments/:tid/submit       entregar
 *   GET  /:cid/lessons|assignments/:tid/submissions  [profesor] entregas de todos los estudiantes
 *   POST /:cid/uploads                               [estudiante] subir una foto (JSON con dataUrl)
 *
 * La nota de las preguntas de opción múltiple se calcula aquí, nunca en el
 * navegador. Las de desarrollo y las de práctica a mano las califica el profesor.
 * ===================================================================== */
'use strict';

const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const express = require('express');
const { HttpError } = require('../lib/http');
const S = require('../lib/security');
const U = require('../lib/util');
const Q = require('../lib/questions');
const { subSummary, canSave, canSubmit, KINDS } = require('./content').helpers;

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;
const MAX_FILES_PER_STUDENT_PER_COURSE = 150;

/** Tipo real de la imagen según sus primeros bytes (no se confía en lo que diga el cliente). */
function sniffImage(buf) {
  if (buf.length > 12 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg', ext: 'jpg' };
  if (buf.length > 12 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: 'image/png', ext: 'png' };
  if (buf.length > 12 && buf.subarray(0, 4).toString('latin1') === 'RIFF' && buf.subarray(8, 12).toString('latin1') === 'WEBP') return { mime: 'image/webp', ext: 'webp' };
  return null;
}

module.exports = function createWorkRouter({ pool, access, uploadDir }) {
  const router = express.Router();

  async function loadTarget(req, kind, { publishedOnly }) {
    const { course, role } = await access.loadCourse(req);
    const [rows] = await pool.execute(
      `SELECT * FROM ${kind.table} WHERE id = ? AND course_id = ?${publishedOnly ? ' AND published = 1' : ''}`,
      [U.idParam(req.params.tid), course.id]);
    if (!rows[0]) throw new HttpError(404, 'No encontrado');
    return { course, role, row: rows[0], questions: U.parseJson(rows[0].questions, []) };
  }

  /** Cada archivo citado debe ser una foto subida por ESTE estudiante en ESTE curso. */
  async function verifyFiles(answers, courseId, studentId) {
    const ids = Q.fileIdsOf(answers);
    if (!ids.length) return;
    const [rows] = await pool.query('SELECT id FROM files WHERE id IN (?) AND owner_id = ? AND course_id = ?', [ids, studentId, courseId]);
    if (rows.length !== new Set(ids).size) throw new HttpError(400, 'Una de las imágenes adjuntas no es válida. Vuelve a subirla.');
  }

  const studentGuard = (req, res, next) =>
    req.user.role === 'student' ? next() : res.status(403).json({ error: 'Solo los estudiantes pueden responder.' });

  for (const [segment, kind] of Object.entries(KINDS)) {
    const base = `/:cid/${segment}/:tid`;

    /* ---------- Guardar avance ---------- */
    router.put(`${base}/answers`, studentGuard, async (req, res) => {
      const { course, questions, row } = await loadTarget(req, kind, { publishedOnly: true });
      const [existingRows] = await pool.execute(
        'SELECT * FROM submissions WHERE student_id = ? AND target_type = ? AND target_id = ?', [req.user.id, kind.type, row.id]);
      const existing = existingRows[0];
      if (!canSave(existing)) throw new HttpError(409, 'Esta entrega ya no se puede modificar.');

      const answers = Q.cleanAnswers(questions, req.body && req.body.answers);
      await verifyFiles(answers, course.id, req.user.id);
      const progress = Q.progressPct(questions, answers);
      const now = new Date();

      await pool.execute(
        `INSERT INTO submissions (id, course_id, student_id, target_type, target_id, answers, status, progress_pct,
                                  total_points, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE answers = VALUES(answers), progress_pct = VALUES(progress_pct), updated_at = VALUES(updated_at)`,
        [S.newId(), course.id, req.user.id, kind.type, row.id, JSON.stringify(answers), progress,
         Q.autoGrade(questions, answers).total, now, now]);
      res.json({ ok: true, progressPct: progress, status: existing ? existing.status : 'draft', savedAt: now });
    });

    /* ---------- Entregar ---------- */
    router.post(`${base}/submit`, studentGuard, async (req, res) => {
      const { course, questions, row } = await loadTarget(req, kind, { publishedOnly: true });
      const [existingRows] = await pool.execute(
        'SELECT * FROM submissions WHERE student_id = ? AND target_type = ? AND target_id = ?', [req.user.id, kind.type, row.id]);
      const existing = existingRows[0];
      if (!canSubmit(existing, kind.type, questions)) throw new HttpError(409, 'Esta entrega ya fue enviada.');

      const answers = Q.cleanAnswers(questions, req.body && req.body.answers);
      await verifyFiles(answers, course.id, req.user.id);

      const { total, auto, manualIds } = Q.autoGrade(questions, answers);
      const needsReview = manualIds.length > 0;
      const status = needsReview ? 'submitted' : 'graded';
      const score = needsReview ? null : Q.scorePct(total, auto);
      const now = new Date();
      // Entrega hecha SIN conexión: la app envía la hora real en que el estudiante la hizo, para que
      // llegar tarde por falta de señal no cuente como entrega tardía. Se acota: nunca en el futuro
      // y como máximo 30 días atrás (el reloj del dispositivo no es verificable; es el costo de
      // permitir entregar sin Internet).
      let submittedAt = now;
      const claimed = req.body && typeof req.body.clientSubmittedAt === 'string' ? new Date(req.body.clientSubmittedAt) : null;
      if (claimed && !Number.isNaN(claimed.getTime()) && claimed < now && claimed > new Date(now.getTime() - 30 * 86400000)) submittedAt = claimed;

      await pool.execute(
        `INSERT INTO submissions (id, course_id, student_id, target_type, target_id, answers, status, progress_pct,
                                  auto_points, manual_points, total_points, score_pct, attempts, submitted_at, graded_at,
                                  created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 100, ?, NULL, ?, ?, 1, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE answers = VALUES(answers), status = VALUES(status), progress_pct = 100,
           auto_points = VALUES(auto_points), manual_points = NULL, total_points = VALUES(total_points),
           score_pct = VALUES(score_pct), attempts = attempts + 1, submitted_at = VALUES(submitted_at),
           graded_at = VALUES(graded_at), updated_at = VALUES(updated_at)`,
        [S.newId(), course.id, req.user.id, kind.type, row.id, JSON.stringify(answers), status,
         auto, total, score, submittedAt, needsReview ? null : now, now, now]);

      const [saved] = await pool.execute(
        'SELECT * FROM submissions WHERE student_id = ? AND target_type = ? AND target_id = ?', [req.user.id, kind.type, row.id]);
      res.json({ ok: true, submission: { ...subSummary(saved[0]), review: Q.reviewOf(questions, answers),
        autoPoints: auto, totalPoints: total, needsReview } });
    });

    /* ---------- Entregas del curso (profesor) ---------- */
    router.get(`${base}/submissions`, async (req, res) => {
      const { course } = await access.loadCourse(req, { teacherOnly: true });
      const [items] = await pool.execute(`SELECT * FROM ${kind.table} WHERE id = ? AND course_id = ?`, [U.idParam(req.params.tid), course.id]);
      if (!items[0]) throw new HttpError(404, 'No encontrado');
      const questions = U.parseJson(items[0].questions, []);

      const [rows] = await pool.execute(
        `SELECT u.id AS student_id, u.name, u.email, s.*
           FROM enrollments e JOIN users u ON u.id = e.student_id
           LEFT JOIN submissions s ON s.student_id = u.id AND s.target_type = ? AND s.target_id = ? AND s.course_id = e.course_id
          WHERE e.course_id = ? ORDER BY u.name`, [kind.type, items[0].id, course.id]);

      res.json({
        target: { id: items[0].id, type: kind.type, title: items[0].title, questionCount: questions.length,
                  hasManual: questions.some(Q.isManual), dueAt: items[0].due_at || null },
        rows: rows.map(r => ({
          student: { id: r.student_id, name: r.name, email: r.email },
          submission: r.id ? { ...subSummary(r), late: Boolean(kind.type === 'assignment' && items[0].due_at && r.submitted_at && new Date(r.submitted_at) > new Date(items[0].due_at)) } : null
        }))
      });
    });
  }

  /* ---------- Subir una foto ---------- */
  router.post('/:cid/uploads', studentGuard, async (req, res) => {
    const { course } = await access.loadCourse(req, { studentOnly: true });
    const dataUrl = req.body && req.body.dataUrl;
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) throw new HttpError(400, 'Adjunta una imagen (JPG, PNG o WebP).');
    const comma = dataUrl.indexOf(',');
    if (comma < 0 || !dataUrl.slice(0, comma).endsWith(';base64')) throw new HttpError(400, 'Imagen inválida.');

    const buffer = Buffer.from(dataUrl.slice(comma + 1), 'base64');
    if (buffer.length > MAX_IMAGE_BYTES) throw new HttpError(413, 'La imagen pesa más de 3 MB.');
    const kind = sniffImage(buffer);
    if (!kind) throw new HttpError(400, 'Solo se permiten imágenes JPG, PNG o WebP.');

    const [[{ n }]] = await pool.execute('SELECT COUNT(*) AS n FROM files WHERE owner_id = ? AND course_id = ?', [req.user.id, course.id]);
    if (Number(n) >= MAX_FILES_PER_STUDENT_PER_COURSE) throw new HttpError(429, 'Llegaste al límite de imágenes de este curso.');

    const id = S.newId();
    await fsp.mkdir(uploadDir, { recursive: true });
    await fsp.writeFile(path.join(uploadDir, `${id}.${kind.ext}`), buffer, { flag: 'wx' });
    try {
      await pool.execute('INSERT INTO files (id, owner_id, course_id, mime, size, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        [id, req.user.id, course.id, kind.mime, buffer.length, new Date()]);
    } catch (err) {
      await fsp.unlink(path.join(uploadDir, `${id}.${kind.ext}`)).catch(() => {});
      throw err;
    }
    res.status(201).json({ id, url: `/api/files/${id}`, size: buffer.length });
  });

  return router;
};
module.exports.sniffImage = sniffImage;
