/* =====================================================================
 * AulaSink · routes/submissions.js   (montado en /api/submissions · profesores)
 * ---------------------------------------------------------------------
 *   GET  /:sid          entrega completa: preguntas con respuesta correcta, lo que respondió el estudiante, notas
 *   PUT  /:sid/grade    calificar preguntas de desarrollo / práctica a mano + comentario
 *   POST /:sid/return   devolver al estudiante para que la corrija
 * ===================================================================== */
'use strict';

const express = require('express');
const { HttpError } = require('../lib/http');
const U = require('../lib/util');
const Q = require('../lib/questions');

module.exports = function createSubmissionsRouter({ pool }) {
  const router = express.Router();

  router.use((req, res, next) =>
    req.user.role === 'teacher' ? next() : res.status(403).json({ error: 'Solo los profesores pueden revisar entregas.' }));

  /** Carga la entrega solo si pertenece a un curso de este profesor. */
  async function load(req) {
    const [rows] = await pool.execute(
      `SELECT s.*, c.name AS course_name, c.teacher_id, u.name AS student_name, u.email AS student_email
         FROM submissions s JOIN courses c ON c.id = s.course_id JOIN users u ON u.id = s.student_id
        WHERE s.id = ?`, [U.idParam(req.params.sid)]);
    const sub = rows[0];
    if (!sub || sub.teacher_id !== req.user.id) throw new HttpError(404, 'No encontrado');

    const table = sub.target_type === 'lesson' ? 'course_lessons' : 'assignments';
    const [items] = await pool.execute(`SELECT * FROM ${table} WHERE id = ?`, [sub.target_id]);
    if (!items[0]) throw new HttpError(404, 'La lección o tarea ya no existe.');
    return { sub, item: items[0], questions: U.parseJson(items[0].questions, []) };
  }

  const view = ({ sub, item, questions }) => ({
    submission: {
      id: sub.id, status: sub.status, progressPct: sub.progress_pct, scorePct: U.num(sub.score_pct),
      autoPoints: U.num(sub.auto_points), manualPoints: U.num(sub.manual_points), totalPoints: U.num(sub.total_points),
      teacherComment: sub.teacher_comment, attempts: sub.attempts, submittedAt: sub.submitted_at, gradedAt: sub.graded_at,
      answers: U.parseJson(sub.answers, {}), grading: U.parseJson(sub.grading, {})
    },
    student: { id: sub.student_id, name: sub.student_name, email: sub.student_email },
    course: { id: sub.course_id, name: sub.course_name },
    target: { type: sub.target_type, id: item.id, title: item.title,
              dueAt: item.due_at || null,
              description: sub.target_type === 'lesson' ? item.content : item.instructions },
    questions
  });

  router.get('/:sid', async (req, res) => {
    res.json(view(await load(req)));
  });

  router.put('/:sid/grade', async (req, res) => {
    const ctx = await load(req);
    const { sub, questions } = ctx;
    if (sub.status !== 'submitted' && sub.status !== 'graded') {
      throw new HttpError(409, 'Solo se pueden calificar entregas ya enviadas por el estudiante.');
    }
    const body = req.body || {};
    const answers = U.parseJson(sub.answers, {});
    const { total, auto, manualIds } = Q.autoGrade(questions, answers);

    // Se parte de lo calificado antes y se aplican los cambios de esta petición
    const grading = { ...U.parseJson(sub.grading, {}), ...Q.sanitizeGrades(questions, body.grades) };
    const comment = body.comment === undefined ? sub.teacher_comment : (U.str(body.comment, 1000) || null);

    const complete = Q.allManualGraded(manualIds, grading);
    const manual = complete ? Q.manualSum(manualIds, grading) : null;
    const score = complete ? Q.scorePct(total, auto + manual) : null;
    const now = new Date();

    await pool.execute(
      `UPDATE submissions SET grading = ?, teacher_comment = ?, manual_points = ?, auto_points = ?, total_points = ?,
              score_pct = ?, status = ?, graded_at = ?, updated_at = ? WHERE id = ?`,
      [JSON.stringify(grading), comment, manual, auto, total, score, complete ? 'graded' : 'submitted',
       complete ? now : null, now, sub.id]);

    res.json({ ok: true, status: complete ? 'graded' : 'submitted', scorePct: score, manualPoints: manual });
  });

  router.post('/:sid/return', async (req, res) => {
    const { sub } = await load(req);
    if (sub.status !== 'submitted' && sub.status !== 'graded') throw new HttpError(409, 'Solo se pueden devolver entregas ya enviadas.');
    const comment = U.str(req.body && req.body.comment, 1000) || null;
    await pool.execute(
      `UPDATE submissions SET status = 'returned', teacher_comment = COALESCE(?, teacher_comment),
              score_pct = NULL, manual_points = NULL, graded_at = NULL, updated_at = ? WHERE id = ?`,
      [comment, new Date(), sub.id]);
    res.json({ ok: true, status: 'returned' });
  });

  return router;
};
