/* =====================================================================
 * AulaSink · routes/auth.js
 * ---------------------------------------------------------------------
 *   POST /api/auth/register   crea una cuenta (student | teacher) e inicia sesión
 *   POST /api/auth/login      inicia sesión
 *   POST /api/auth/logout     cierra la sesión
 *   GET  /api/auth/me         usuario de la sesión actual
 *   POST /api/auth/password   cambia la contraseña (cierra las demás sesiones)
 *
 * La sesión es una cookie HttpOnly con un token aleatorio; en la base de datos
 * solo se guarda su hash (si se filtrara la tabla, los tokens no servirían).
 * ===================================================================== */
'use strict';

const express = require('express');
const { HttpError } = require('../lib/http');
const S = require('../lib/security');
const U = require('../lib/util');

const COOKIE = 'aulasink_sid';
const SESSION_DAYS = 30;

module.exports = function createAuth({ pool, env, authLimiter, loginLimiter }) {
  const router = express.Router();
  const crossSite = Boolean(env.CORS_ORIGIN);     // frontend en otro dominio → cookie SameSite=None

  function cookieOptions(req) {
    const secure = req.secure || env.COOKIE_SECURE === '1' || crossSite;
    return { httpOnly: true, sameSite: crossSite ? 'none' : 'lax', secure, path: '/' };
  }

  async function startSession(req, res, userId) {
    const token = S.newToken();
    const now = new Date();
    const expires = new Date(now.getTime() + SESSION_DAYS * 86400000);
    await pool.execute('DELETE FROM sessions WHERE expires_at < ?', [now]);   // limpieza oportunista
    await pool.execute('INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)',
      [S.sha256(token), userId, now, expires]);
    res.cookie(COOKIE, token, { ...cookieOptions(req), expires });
  }

  /** Middleware: llena req.user si hay una sesión válida (no obliga a tenerla). */
  async function attachUser(req, res, next) {
    req.user = null;
    const token = S.parseCookies(req.headers.cookie)[COOKIE];
    if (token) {
      const [rows] = await pool.execute(
        `SELECT u.id, u.name, u.email, u.role
           FROM sessions s JOIN users u ON u.id = s.user_id
          WHERE s.token_hash = ? AND s.expires_at > ?`,
        [S.sha256(token), new Date()]);
      req.user = rows[0] || null;
    }
    next();
  }

  const requireAuth = (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Inicia sesión para continuar.', code: 'unauthenticated' });
    next();
  };

  const requireRole = role => (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Inicia sesión para continuar.', code: 'unauthenticated' });
    if (req.user.role !== role) return res.status(403).json({ error: 'Esta acción no está disponible para tu tipo de cuenta.' });
    next();
  };

  /**
   * Crea la cuenta dentro de una transacción. Un estudiante también entra en la
   * tabla `students` (mismo id) y en los cursos a los que lo invitaron por correo.
   * `conn` ya debe estar en transacción.
   */
  async function createUser(conn, { name, email, password, role }) {
    const id = S.newId();
    const hash = await S.hashPassword(password);
    try {
      await conn.execute(
        'INSERT INTO users (id, email, name, role, password_hash, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        [id, email, name, role, hash, new Date()]);
    } catch (err) {
      if (err.code === 'ER_DUP_ENTRY') throw new HttpError(409, 'Ya existe una cuenta con ese correo.');
      throw err;
    }
    let enrolled = 0;
    if (role === 'student') {
      await conn.execute('INSERT INTO students (id, name) VALUES (?, ?)', [id, name]);
      const [invites] = await conn.execute('SELECT course_id FROM course_invites WHERE email = ?', [email]);
      for (const inv of invites) {
        await conn.execute('INSERT IGNORE INTO enrollments (course_id, student_id, joined_at) VALUES (?, ?, ?)',
          [inv.course_id, id, new Date()]);
        enrolled++;
      }
      if (invites.length) await conn.execute('DELETE FROM course_invites WHERE email = ?', [email]);
    }
    return { id, enrolled };
  }

  router.post('/register', authLimiter, async (req, res) => {
    const body = req.body || {};
    const name = U.requireText(body.name, 80, 'Escribe tu nombre.');
    const email = U.cleanEmail(body.email);
    const password = U.cleanPassword(body.password);
    const role = body.role;
    if (role !== 'student' && role !== 'teacher') throw new HttpError(400, 'Elige si eres estudiante o profesor.');

    if (role === 'teacher' && env.TEACHER_SIGNUP_CODE && body.teacherCode !== env.TEACHER_SIGNUP_CODE) {
      throw new HttpError(403, 'El código de profesor no es correcto.');
    }

    const conn = await pool.getConnection();
    let created;
    try {
      await conn.beginTransaction();
      created = await createUser(conn, { name, email, password, role });
      await conn.commit();
    } catch (err) {
      await conn.rollback().catch(() => {});
      throw err;
    } finally {
      conn.release();
    }

    await startSession(req, res, created.id);
    res.status(201).json({ user: { id: created.id, name, email, role }, enrolledCourses: created.enrolled });
  });

  router.post('/login', authLimiter, loginLimiter, async (req, res) => {
    const body = req.body || {};
    const email = typeof body.email === 'string' ? body.email.trim().toLowerCase().slice(0, 190) : '';
    const password = typeof body.password === 'string' ? body.password.slice(0, 200) : '';
    if (!email || !password) throw new HttpError(400, 'Escribe tu correo y tu contraseña.');

    const [rows] = await pool.execute(
      'SELECT id, name, email, role, password_hash FROM users WHERE email = ?', [email]);
    const user = rows[0];
    const ok = user ? await S.verifyPassword(password, user.password_hash) : (await S.dummyVerify(password), false);
    if (!ok) throw new HttpError(401, 'Correo o contraseña incorrectos.');

    await pool.execute('UPDATE users SET last_login_at = ? WHERE id = ?', [new Date(), user.id]);
    await startSession(req, res, user.id);
    res.json({ user: U.userView(user) });
  });

  router.post('/logout', async (req, res) => {
    const token = S.parseCookies(req.headers.cookie)[COOKIE];
    if (token) await pool.execute('DELETE FROM sessions WHERE token_hash = ?', [S.sha256(token)]);
    res.clearCookie(COOKIE, cookieOptions(req));
    res.json({ ok: true });
  });

  router.post('/password', authLimiter, requireAuth, async (req, res) => {
    const body = req.body || {};
    const [rows] = await pool.execute('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
    const ok = rows[0] && typeof body.current === 'string' && await S.verifyPassword(body.current.slice(0, 200), rows[0].password_hash);
    if (!ok) throw new HttpError(400, 'La contraseña actual no es correcta.');
    const next = U.cleanPassword(body.next);
    await pool.execute('UPDATE users SET password_hash = ? WHERE id = ?', [await S.hashPassword(next), req.user.id]);
    const current = S.parseCookies(req.headers.cookie)[COOKIE];
    await pool.execute('DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?', [req.user.id, S.sha256(current || '')]);
    res.json({ ok: true });
  });

  router.get('/me', (req, res) => {
    if (!req.user) return res.status(401).json({ error: 'No has iniciado sesión.', code: 'unauthenticated' });
    res.json({ user: U.userView(req.user) });
  });

  return { router, attachUser, requireAuth, requireRole, createUser };
};
