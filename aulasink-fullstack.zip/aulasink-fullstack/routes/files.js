/* =====================================================================
 * AulaSink · routes/files.js   (montado en /api/files)
 * Entrega una foto adjunta SOLO a quien la subió o al profesor de ese curso.
 * ===================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');
const express = require('express');
const { HttpError } = require('../lib/http');
const U = require('../lib/util');

const EXT = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' };

module.exports = function createFilesRouter({ pool, uploadDir }) {
  const router = express.Router();

  router.get('/:id', async (req, res) => {
    const [rows] = await pool.execute(
      `SELECT f.id, f.owner_id, f.mime, c.teacher_id FROM files f JOIN courses c ON c.id = f.course_id WHERE f.id = ?`,
      [U.idParam(req.params.id)]);
    const file = rows[0];
    if (!file || (file.owner_id !== req.user.id && file.teacher_id !== req.user.id)) throw new HttpError(404, 'No encontrado');

    const abs = path.resolve(uploadDir, `${file.id}.${EXT[file.mime]}`);
    if (!fs.existsSync(abs)) throw new HttpError(404, 'El archivo ya no está disponible.');
    res.set({ 'Content-Type': file.mime, 'Cache-Control': 'private, max-age=3600', 'Content-Disposition': 'inline' });
    res.sendFile(abs);
  });

  return router;
};
