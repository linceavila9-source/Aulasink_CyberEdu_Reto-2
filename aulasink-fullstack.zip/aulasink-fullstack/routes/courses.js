/* =====================================================================
 * AulaSink · routes/courses.js   (montado en /api/courses, ya con sesión)
 * ---------------------------------------------------------------------
 *  GET    /                         mis cursos (profesor: los que dicta · estudiante: en los que estoy)
 *  POST   /                         [profesor] crear curso
 *  POST   /join                     [estudiante] unirse con el código del curso
 *  GET    /:cid                     detalle del curso
 *  PATCH  /:cid                     [profesor] editar nombre, descripción, código activo…
 *  DELETE /:cid                     [profesor] eliminar el curso
 *  POST   /:cid/regenerate-code     [profesor] código nuevo
 *  GET    /:cid/members             integrantes: profesor + estudiantes
 *  POST   /:cid/students            [profesor] añadir estudiante (correo / cuenta nueva)
 *  DELETE /:cid/students/:sid       [profesor] quitar estudiante
 *  DELETE /:cid/invites?email=      [profesor] cancelar invitación
 *  PUT    /:cid/students/:sid/final [profesor] calificación final del estudiante
 *  GET    /:cid/gradebook           [profesor] avance y notas de todos
 *  GET    /:cid/me                  [estudiante] mi avance, notas y calificación final
 * ===================================================================== */
'use strict';

const express = require('express');
const { HttpError } = require('../lib/http');
const S = require('../lib/security');
const U = require('../lib/util');
const { courseStats } = require('../lib/stats');

module.exports = function createCoursesRouter({ pool, access, auth }) {
  const router = express.Router();
  const teacherOnly = (req, res, next) =>
    req.user.role === 'teacher' ? next() : res.status(403).json({ error: 'Solo los profesores pueden hacer esto.' });
  const studentOnly = (req, res, next) =>
    req.user.role === 'student' ? next() : res.status(403).json({ error: 'Solo los estudiantes pueden hacer esto.' });

  const courseView = (c, role) => ({
    id: c.id, name: c.name, subject: c.subject, description: c.description,
    teacherId: c.teacher_id, teacherName: c.teacher_name, joinEnabled: Boolean(c.join_enabled),
    createdAt: c.created_at, ...(role === 'teacher' ? { code: c.code } : {})
  });

  async function uniqueCode() {
    for (let i = 0; i < 10; i++) {
      const code = S.newCourseCode();
      const [rows] = await pool.execute('SELECT 1 FROM courses WHERE code = ?', [code]);
      if (!rows.length) return code;
    }
    throw new Error('No se pudo generar un código único');
  }

  /* ---------- Lista ---------- */
  router.get('/', async (req, res) => {
    if (req.user.role === 'teacher') {
      const [rows] = await pool.execute(
        `SELECT c.*, t.name AS teacher_name,
                (SELECT COUNT(*) FROM enrollments e WHERE e.course_id = c.id) AS students,
                (SELECT COUNT(*) FROM course_lessons l WHERE l.course_id = c.id) AS lessons,
                (SELECT COUNT(*) FROM assignments a WHERE a.course_id = c.id) AS assignments,
                (SELECT COUNT(*) FROM submissions s WHERE s.course_id = c.id AND s.status = 'submitted') AS pending
           FROM courses c JOIN users t ON t.id = c.teacher_id
          WHERE c.teacher_id = ? ORDER BY c.created_at DESC`, [req.user.id]);
      return res.json({ courses: rows.map(c => ({
        ...courseView(c, 'teacher'), students: c.students, lessons: c.lessons, assignments: c.assignments, pending: c.pending
      })) });
    }

    const [rows] = await pool.execute(
      `SELECT c.*, t.name AS teacher_name, e.final_grade
         FROM enrollments e JOIN courses c ON c.id = e.course_id JOIN users t ON t.id = c.teacher_id
        WHERE e.student_id = ? ORDER BY e.joined_at DESC`, [req.user.id]);
    const courses = [];
    for (const c of rows) {
      const stats = (await courseStats(pool, c.id, [req.user.id])).get(req.user.id);
      courses.push({ ...courseView(c, 'student'), finalGrade: U.num(c.final_grade), stats });
    }
    res.json({ courses });
  });

  /* ---------- Crear / unirse ---------- */
  router.post('/', teacherOnly, async (req, res) => {
    const body = req.body || {};
    const name = U.requireText(body.name, 120, 'Escribe el nombre del curso.');
    const id = S.newId();
    await pool.execute(
      `INSERT INTO courses (id, teacher_id, name, subject, description, code, join_enabled, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 1, ?)`,
      [id, req.user.id, name, U.str(body.subject, 60) || null, U.str(body.description, 500) || null, await uniqueCode(), new Date()]);
    res.status(201).json({ id });
  });

  router.post('/join', studentOnly, async (req, res) => {
    const code = U.str(req.body && req.body.code, 12).toUpperCase().replace(/\s+/g, '');
    if (!code) throw new HttpError(400, 'Escribe el código del curso.');
    const [rows] = await pool.execute('SELECT id, name, join_enabled FROM courses WHERE code = ?', [code]);
    const course = rows[0];
    if (!course) throw new HttpError(404, 'No existe ningún curso con ese código.');
    if (!course.join_enabled) throw new HttpError(403, 'Este curso no admite nuevos estudiantes por código. Pide al profesor que te añada.');
    const [result] = await pool.execute(
      'INSERT IGNORE INTO enrollments (course_id, student_id, joined_at) VALUES (?, ?, ?)', [course.id, req.user.id, new Date()]);
    res.json({ id: course.id, name: course.name, alreadyMember: result.affectedRows === 0 });
  });

  /* ---------- Detalle ---------- */
  router.get('/:cid', async (req, res) => {
    const { course, role } = await access.loadCourse(req);
    const out = { course: courseView(course, role), role };
    if (role === 'student') {
      const [rows] = await pool.execute(
        'SELECT final_grade, final_comment FROM enrollments WHERE course_id = ? AND student_id = ?', [course.id, req.user.id]);
      out.finalGrade = U.num(rows[0].final_grade);
      out.finalComment = rows[0].final_comment;
    }
    res.json(out);
  });

  router.patch('/:cid', async (req, res) => {
    const { course } = await access.loadCourse(req, { teacherOnly: true });
    const b = req.body || {};
    const name = b.name === undefined ? course.name : U.requireText(b.name, 120, 'El curso necesita un nombre.');
    const subject = b.subject === undefined ? course.subject : (U.str(b.subject, 60) || null);
    const description = b.description === undefined ? course.description : (U.str(b.description, 500) || null);
    const joinEnabled = b.joinEnabled === undefined ? course.join_enabled : (b.joinEnabled ? 1 : 0);
    await pool.execute('UPDATE courses SET name = ?, subject = ?, description = ?, join_enabled = ? WHERE id = ?',
      [name, subject, description, joinEnabled, course.id]);
    res.json({ ok: true });
  });

  router.post('/:cid/regenerate-code', async (req, res) => {
    const { course } = await access.loadCourse(req, { teacherOnly: true });
    const code = await uniqueCode();
    await pool.execute('UPDATE courses SET code = ? WHERE id = ?', [code, course.id]);
    res.json({ code });
  });

  router.delete('/:cid', async (req, res) => {
    const { course } = await access.loadCourse(req, { teacherOnly: true });
    await pool.execute('DELETE FROM courses WHERE id = ?', [course.id]);   // borra en cascada todo lo del curso
    res.json({ ok: true });
  });

  /* ---------- Integrantes ---------- */
  router.get('/:cid/members', async (req, res) => {
    const { course, role } = await access.loadCourse(req);
    const [students] = await pool.execute(
      `SELECT u.id, u.name, u.email, e.joined_at
         FROM enrollments e JOIN users u ON u.id = e.student_id
        WHERE e.course_id = ? ORDER BY u.name`, [course.id]);

    const members = [
      { id: course.teacher_id, name: course.teacher_name, role: 'teacher', ...(role === 'teacher' ? { email: course.teacher_email } : {}) },
      ...students.map(s => ({
        id: s.id, name: s.name, role: 'student', joinedAt: s.joined_at,
        // el correo solo lo ve el profesor; entre compañeros se muestra únicamente el nombre
        ...(role === 'teacher' ? { email: s.email } : {}),
        ...(s.id === req.user.id ? { isMe: true } : {})
      }))
    ];
    const out = { members };
    if (role === 'teacher') {
      const [invites] = await pool.execute('SELECT email, created_at FROM course_invites WHERE course_id = ? ORDER BY created_at', [course.id]);
      out.invites = invites.map(i => ({ email: i.email, createdAt: i.created_at }));
    }
    res.json(out);
  });

  /* ---------- Añadir / quitar estudiantes (profesor) ---------- */
  router.post('/:cid/students', async (req, res) => {
    const { course } = await access.loadCourse(req, { teacherOnly: true });
    const b = req.body || {};
    const email = U.cleanEmail(b.email);

    const [found] = await pool.execute('SELECT id, name, role FROM users WHERE email = ?', [email]);
    let student = found[0];
    let status;

    if (student) {
      if (student.role !== 'student') throw new HttpError(400, 'Ese correo pertenece a una cuenta de profesor.');
    } else if (b.password) {
      // "Registro": el profesor crea la cuenta del estudiante con una contraseña temporal
      const name = U.requireText(b.name, 80, 'Escribe el nombre del estudiante para crear su cuenta.');
      const password = U.cleanPassword(b.password);
      const conn = await pool.getConnection();
      try {
        await conn.beginTransaction();
        const created = await auth.createUser(conn, { name, email, password, role: 'student' });
        await conn.commit();
        student = { id: created.id, name };
        status = 'created';
      } catch (err) {
        await conn.rollback().catch(() => {});
        throw err;
      } finally {
        conn.release();
      }
    } else {
      // Aún no tiene cuenta: queda invitado y entra solo cuando se registre con ese correo
      const [r] = await pool.execute(
        'INSERT IGNORE INTO course_invites (course_id, email, created_at) VALUES (?, ?, ?)', [course.id, email, new Date()]);
      return res.status(r.affectedRows ? 201 : 200).json({ status: r.affectedRows ? 'invited' : 'already_invited', email });
    }

    const [r] = await pool.execute(
      'INSERT IGNORE INTO enrollments (course_id, student_id, joined_at) VALUES (?, ?, ?)', [course.id, student.id, new Date()]);
    if (!status) status = r.affectedRows ? 'enrolled' : 'already_member';
    res.status(status === 'already_member' ? 200 : 201).json({ status, student: { id: student.id, name: student.name, email } });
  });

  router.delete('/:cid/students/:sid', async (req, res) => {
    const { course } = await access.loadCourse(req, { teacherOnly: true });
    const [r] = await pool.execute('DELETE FROM enrollments WHERE course_id = ? AND student_id = ?', [course.id, U.idParam(req.params.sid)]);
    if (!r.affectedRows) throw new HttpError(404, 'Ese estudiante no está en el curso.');
    res.json({ ok: true });
  });

  router.delete('/:cid/invites', async (req, res) => {
    const { course } = await access.loadCourse(req, { teacherOnly: true });
    const email = U.str(req.query.email, 190).toLowerCase();
    await pool.execute('DELETE FROM course_invites WHERE course_id = ? AND email = ?', [course.id, email]);
    res.json({ ok: true });
  });

  /* ---------- Calificación final ---------- */
  router.put('/:cid/students/:sid/final', async (req, res) => {
    const { course } = await access.loadCourse(req, { teacherOnly: true });
    const b = req.body || {};
    let grade = null;
    if (b.grade !== null && b.grade !== undefined && b.grade !== '') {
      grade = Number(b.grade);
      if (!Number.isFinite(grade) || grade < 0 || grade > 100) throw new HttpError(400, 'La calificación final debe estar entre 0 y 100.');
      grade = Math.round(grade * 100) / 100;
    }
    const comment = U.str(b.comment, 500) || null;
    const [r] = await pool.execute(
      `UPDATE enrollments SET final_grade = ?, final_comment = ?, final_graded_at = ?
        WHERE course_id = ? AND student_id = ?`,
      [grade, comment, grade === null ? null : new Date(), course.id, U.idParam(req.params.sid)]);
    if (!r.affectedRows) throw new HttpError(404, 'Ese estudiante no está en el curso.');
    res.json({ ok: true, finalGrade: grade });
  });

  router.get('/:cid/gradebook', async (req, res) => {
    const { course } = await access.loadCourse(req, { teacherOnly: true });
    const [rows] = await pool.execute(
      `SELECT u.id, u.name, u.email, e.final_grade, e.final_comment
         FROM enrollments e JOIN users u ON u.id = e.student_id
        WHERE e.course_id = ? ORDER BY u.name`, [course.id]);
    const stats = await courseStats(pool, course.id, rows.map(r => r.id));
    res.json({ students: rows.map(r => ({
      id: r.id, name: r.name, email: r.email,
      finalGrade: U.num(r.final_grade), finalComment: r.final_comment, stats: stats.get(r.id)
    })) });
  });

  router.get('/:cid/me', studentOnly, async (req, res) => {
    const { course } = await access.loadCourse(req, { studentOnly: true });
    const [enr] = await pool.execute(
      'SELECT final_grade, final_comment FROM enrollments WHERE course_id = ? AND student_id = ?', [course.id, req.user.id]);
    const stats = (await courseStats(pool, course.id, [req.user.id])).get(req.user.id);
    res.json({ finalGrade: U.num(enr[0].final_grade), finalComment: enr[0].final_comment, stats });
  });

  return router;
};
