/* =====================================================================
 * AulaSink · routes/overview.js   (montado en /api/me)
 *   GET /overview   datos de la pantalla de inicio
 *     profesor   → totales y entregas pendientes de revisar
 *     estudiante → mis cursos con avance y tareas por hacer
 * ===================================================================== */
'use strict';

const express = require('express');
const U = require('../lib/util');
const { courseStats } = require('../lib/stats');

module.exports = function createOverviewRouter({ pool }) {
  const router = express.Router();

  router.get('/overview', async (req, res) => {
    if (req.user.role === 'teacher') {
      const [[totals]] = await pool.execute(
        `SELECT (SELECT COUNT(*) FROM courses WHERE teacher_id = ?) AS courses,
                (SELECT COUNT(DISTINCT e.student_id) FROM enrollments e JOIN courses c ON c.id = e.course_id WHERE c.teacher_id = ?) AS students,
                (SELECT COUNT(*) FROM submissions s JOIN courses c ON c.id = s.course_id WHERE c.teacher_id = ? AND s.status = 'submitted') AS pending`,
        [req.user.id, req.user.id, req.user.id]);

      const [pending] = await pool.query(
        `SELECT s.id, s.target_type, s.target_id, s.submitted_at, c.id AS course_id, c.name AS course_name, u.name AS student_name,
                COALESCE(l.title, a.title) AS title
           FROM submissions s
           JOIN courses c ON c.id = s.course_id
           JOIN users u ON u.id = s.student_id
           LEFT JOIN course_lessons l ON s.target_type = 'lesson' AND l.id = s.target_id
           LEFT JOIN assignments a ON s.target_type = 'assignment' AND a.id = s.target_id
          WHERE c.teacher_id = ? AND s.status = 'submitted'
          ORDER BY s.submitted_at ASC LIMIT 30`, [req.user.id]);

      return res.json({
        role: 'teacher',
        totals: { courses: Number(totals.courses), students: Number(totals.students), pending: Number(totals.pending) },
        pending: pending.map(p => ({
          id: p.id, courseId: p.course_id, courseName: p.course_name, studentName: p.student_name,
          type: p.target_type, title: p.title, submittedAt: p.submitted_at
        }))
      });
    }

    const [courses] = await pool.execute(
      `SELECT c.id, c.name, c.subject, t.name AS teacher_name, e.final_grade
         FROM enrollments e JOIN courses c ON c.id = e.course_id JOIN users t ON t.id = c.teacher_id
        WHERE e.student_id = ? ORDER BY e.joined_at DESC`, [req.user.id]);

    const [todo] = await pool.query(
      `SELECT a.id, a.title, a.due_at, c.id AS course_id, c.name AS course_name, s.status
         FROM enrollments e
         JOIN courses c ON c.id = e.course_id
         JOIN assignments a ON a.course_id = c.id AND a.published = 1
         LEFT JOIN submissions s ON s.student_id = e.student_id AND s.target_type = 'assignment' AND s.target_id = a.id
        WHERE e.student_id = ? AND (s.id IS NULL OR s.status IN ('draft', 'returned'))
        ORDER BY a.due_at IS NULL, a.due_at LIMIT 20`, [req.user.id]);

    const out = [];
    for (const c of courses) {
      const stats = (await courseStats(pool, c.id, [req.user.id])).get(req.user.id);
      out.push({ id: c.id, name: c.name, subject: c.subject, teacherName: c.teacher_name, finalGrade: U.num(c.final_grade), stats });
    }
    res.json({
      role: 'student', courses: out,
      todo: todo.map(t => ({ id: t.id, title: t.title, dueAt: t.due_at, courseId: t.course_id, courseName: t.course_name, status: t.status || 'new' }))
    });
  });

  return router;
};
