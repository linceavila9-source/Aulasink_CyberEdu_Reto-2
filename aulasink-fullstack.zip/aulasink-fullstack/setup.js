/* =====================================================================
 * AulaSink · setup.js
 * ---------------------------------------------------------------------
 * Lo ejecuta iniciar.bat ANTES de arrancar el servidor. Deja todo listo
 * sin que tengas que tocar archivos:
 *   1. Crea el archivo .env (a partir de .env.example) si no existe.
 *   2. Se conecta a MySQL; si está apagado intenta encenderlo (XAMPP o
 *      servicio de Windows) y espera a que responda.
 *   3. Si MySQL pide contraseña, la pregunta UNA vez y la guarda en .env.
 *   4. Crea la base de datos "aulasink" (schema.sql) si todavía no existe.
 *   5. Pregunta UNA vez la API Key de Groq para el tutor (puedes omitirla).
 * Las siguientes veces no pregunta nada: simplemente verifica y sigue.
 *
 * Termina con código 0 si todo está listo y 1 si algo impide continuar.
 * ===================================================================== */
'use strict';

const fs = require('fs');
const path = require('path');
const net = require('net');
const readline = require('readline');
const { spawn, execSync } = require('child_process');
const dotenv = require('dotenv');
const mysql = require('mysql2/promise');

const ROOT = __dirname;
const ENV_FILE = path.join(ROOT, '.env');
const ENV_EXAMPLE = path.join(ROOT, '.env.example');
const SCHEMA_FILE = path.join(ROOT, 'schema.sql');

/* ---------- Entrada por consola ---------- */
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

// Cola propia de líneas: así no se pierde nada aunque la entrada llegue antes
// de que hagamos la pregunta (el iterador asíncrono de readline sí las pierde).
const queue = [];
let inputClosed = false;
let wake = null;
rl.on('line', line => { queue.push(line); if (wake) wake(); });
rl.on('close', () => { inputClosed = true; if (wake) wake(); });

/** Pregunta algo y devuelve la respuesta ('' si no hay entrada). */
async function ask(question, { trim = true } = {}) {
  process.stdout.write(question);
  while (queue.length === 0) {
    if (inputClosed) return '';
    await new Promise(resolve => { wake = resolve; });
    wake = null;
  }
  const text = queue.shift().replace(/\r$/, '');
  return trim ? text.trim() : text;
}

const say = (msg = '') => console.log(msg);
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function fail(message) {
  say();
  say('[ERROR] ' + message);
  rl.close();
  process.exit(1);
}

/* ---------- Archivo .env ---------- */

/** Escribe valores con comillas para que símbolos como # o $ no rompan el .env. */
function quote(value) {
  if (value === '') return '';
  if (!value.includes('"')) return `"${value}"`;
  if (!value.includes("'")) return `'${value}'`;
  return '`' + value + '`';
}

/** Cambia (o añade) UNA clave del .env sin tocar el resto del archivo. */
function setEnvKey(key, value) {
  let text = fs.readFileSync(ENV_FILE, 'utf8');
  const line = `${key}=${quote(value)}`;
  const re = new RegExp(`^${key}=.*$`, 'm');
  text = re.test(text) ? text.replace(re, () => line) : text.replace(/\s*$/, '\n') + line + '\n';
  fs.writeFileSync(ENV_FILE, text);
}

function readEnv() {
  return dotenv.parse(fs.readFileSync(ENV_FILE));
}

function ensureEnvFile() {
  if (fs.existsSync(ENV_FILE)) return;
  say('Creando configuración inicial (.env)...');
  const base = fs.existsSync(ENV_EXAMPLE) ? fs.readFileSync(ENV_EXAMPLE, 'utf8') : '';
  fs.writeFileSync(ENV_FILE, base);
  // Valores por defecto de una instalación local típica (XAMPP / MySQL recién instalado)
  setEnvKey('DB_HOST', '127.0.0.1');
  setEnvKey('DB_PORT', '3306');
  setEnvKey('DB_USER', 'root');
  setEnvKey('DB_PASSWORD', '');
  setEnvKey('DB_NAME', 'aulasink');
  setEnvKey('GROQ_API_KEY', '');
}

/* ---------- MySQL: conexión y arranque ---------- */

function portOpen(host, port, timeoutMs = 1500) {
  return new Promise(resolve => {
    const socket = net.connect({ host, port });
    const done = ok => { socket.destroy(); resolve(ok); };
    socket.setTimeout(timeoutMs, () => done(false));
    socket.once('connect', () => done(true));
    socket.once('error', () => done(false));
  });
}

/** Intenta encender MySQL en Windows (servicio o XAMPP). Devuelve true si lanzó algo. */
function tryStartMySQL() {
  if (process.platform !== 'win32') return false;

  // 1) Servicios de Windows habituales (necesitan permisos de administrador; si fallan, se ignora)
  for (const name of ['MySQL80', 'MySQL', 'MySQL57', 'MariaDB']) {
    try {
      execSync(`net start ${name}`, { stdio: 'ignore', timeout: 20000 });
      say(`  Servicio de Windows "${name}" iniciado.`);
      return true;
    } catch { /* no existe o sin permisos */ }
  }

  // 2) XAMPP: se lanza mysqld en segundo plano (queda activo aunque cierres esta ventana)
  for (const base of ['C:\\xampp\\mysql\\bin', 'D:\\xampp\\mysql\\bin']) {
    const exe = path.join(base, 'mysqld.exe');
    if (!fs.existsSync(exe)) continue;
    const args = ['--standalone'];
    const ini = path.join(base, 'my.ini');
    if (fs.existsSync(ini)) args.unshift(`--defaults-file=${ini}`);
    try {
      const child = spawn(exe, args, { cwd: base, detached: true, stdio: 'ignore', windowsHide: true });
      child.unref();
      say('  MySQL de XAMPP iniciado en segundo plano.');
      return true;
    } catch { /* probar el siguiente */ }
  }
  return false;
}

async function waitForPort(host, port, seconds) {
  for (let i = 0; i < seconds; i++) {
    if (await portOpen(host, port)) return true;
    await sleep(1000);
  }
  return false;
}

/** Abre la conexión; si MySQL está apagado intenta encenderlo; si pide clave, la pregunta. */
async function connectToMySQL() {
  let env = readEnv();
  const host = env.DB_HOST || '127.0.0.1';
  const port = Number(env.DB_PORT) || 3306;
  let user = env.DB_USER || 'root';
  let password = env.DB_PASSWORD || '';
  let triedStart = false;
  let passwordTries = 0;

  for (;;) {
    try {
      return await mysql.createConnection({
        host, port, user, password,
        charset: 'utf8mb4', multipleStatements: true, connectTimeout: 5000
      });
    } catch (err) {
      const down = ['ECONNREFUSED', 'ETIMEDOUT', 'EHOSTUNREACH', 'ENOTFOUND'].includes(err.code);

      if (down) {
        if (triedStart) {
          fail(`No pude conectar con MySQL en ${host}:${port}.\n` +
               '  - Si usas XAMPP: ábrelo y pulsa "Start" en la fila de MySQL.\n' +
               '  - Si no tienes MySQL: instala XAMPP (https://www.apachefriends.org) o MySQL Community Server.\n' +
               '  Luego vuelve a abrir iniciar.bat.');
        }
        triedStart = true;
        say('MySQL no responde. Intentando iniciarlo...');
        tryStartMySQL();
        say('  Esperando a que MySQL esté listo (hasta 40 s)...');
        if (!(await waitForPort(host, port, 40))) continue; // el siguiente intento mostrará el error
        await sleep(1500);                                  // el puerto abre antes de aceptar clientes
        continue;
      }

      // MySQL devuelve el primer código; MariaDB, según el método de login, puede devolver el segundo
      if (err.code === 'ER_ACCESS_DENIED_ERROR' || err.code === 'ER_ACCESS_DENIED_NO_PASSWORD_ERROR') {
        if (++passwordTries > 3) fail('Usuario o contraseña de MySQL incorrectos tres veces. Revisa DB_USER y DB_PASSWORD en el archivo .env.');
        say();
        say(`MySQL rechazó el acceso del usuario "${user}" con esa contraseña.`);
        say('Escribe el usuario y la contraseña que usas para entrar a tu MySQL.');
        const typedUser = await ask(`Usuario de MySQL [${user}] (Enter para dejar "${user}"): `);
        if (typedUser) user = typedUser;
        password = await ask(`Contraseña de "${user}" (se guardará en .env): `, { trim: false });
        continue;
      }

      fail('Error al conectar con MySQL: ' + (err.code || err.message));
    }
  }
}

/* ---------- Base de datos ---------- */

// v1: 5 tablas · v2 (cuentas, cursos, tareas…): 9 más
const REQUIRED_TABLES = ['students', 'lessons', 'quiz_attempts', 'lesson_progress', 'sync_queue',
  'users', 'sessions', 'courses', 'enrollments', 'course_invites', 'course_lessons', 'assignments', 'submissions', 'files'];

async function ensureDatabase(conn, dbName) {
  const [rows] = await conn.query(
    `SELECT COUNT(*) AS n FROM information_schema.tables
      WHERE table_schema = ? AND table_name IN (${REQUIRED_TABLES.map(() => '?').join(',')})`,
    [dbName, ...REQUIRED_TABLES]
  );
  if (Number(rows[0].n) === REQUIRED_TABLES.length) {
    say('Base de datos lista.');
    return;
  }
  // Si falta alguna tabla (instalación nueva o una versión anterior) se ejecuta schema.sql:
  // usa IF NOT EXISTS, así que solo AÑADE lo que falta y no toca tus datos.
  say('Creando / actualizando la base de datos (schema.sql)...');
  if (!fs.existsSync(SCHEMA_FILE)) fail('No encuentro schema.sql junto a este archivo.');
  await conn.query(fs.readFileSync(SCHEMA_FILE, 'utf8'));
  say('Base de datos lista.');
}

/* ---------- Groq (tutor IA) ---------- */

async function ensureGroqKey() {
  const env = readEnv();
  const key = env.GROQ_API_KEY || '';
  const placeholder = key === '' || key.includes('pega_aqui');
  if (!placeholder) { say('Tutor IA: configurado.'); return; }
  if (env.GROQ_SKIPPED === '1') { say('Tutor IA: desactivado (sin API Key).'); return; }

  say();
  say('--- Tutor con IA (opcional) ---');
  say('Para activarlo necesitas una API Key gratuita de GroqCloud: https://console.groq.com/keys');
  say('Pégala aquí y pulsa Enter, o pulsa Enter sin escribir nada para omitirlo.');
  const answer = await ask('API Key de Groq: ');

  if (answer) {
    if (!answer.startsWith('gsk_')) say('  Aviso: las claves de Groq suelen empezar por "gsk_". La guardo igualmente.');
    setEnvKey('GROQ_API_KEY', answer);
    say('  Guardada en .env. Solo existe en este equipo; nunca llega al navegador.');
  } else {
    setEnvKey('GROQ_SKIPPED', '1');
    say('  Omitido. El resto de la app funciona igual. Para activarlo luego, pega la clave en GROQ_API_KEY dentro de .env.');
  }
}

/* ---------- Permisos: dar acceso al usuario de la app mediante un administrador ---------- */

// Errores que significan "entraste a MySQL, pero este usuario no puede crear/usar esa base de datos"
const NO_PERMISSION = ['ER_DBACCESS_DENIED_ERROR', 'ER_TABLEACCESS_DENIED_ERROR', 'ER_SPECIFIC_ACCESS_DENIED_ERROR'];

/**
 * Pide UNA vez un usuario administrador (normalmente root), crea la base de datos
 * y le da permisos al usuario de la app. Las credenciales del administrador NO se guardan.
 * Devuelve true si quedó listo, false si el usuario canceló o no se pudo.
 */
async function grantViaAdmin(appConn, dbName) {
  if (!/^[A-Za-z0-9_]+$/.test(dbName)) fail('DB_NAME solo puede contener letras, números y guion bajo.');

  // La cuenta exacta con la que entró la app, p. ej. cliente@localhost o cliente@%
  const [[row]] = await appConn.query('SELECT CURRENT_USER() AS account');
  const at = row.account.lastIndexOf('@');
  const appUser = row.account.slice(0, at);
  const appHost = row.account.slice(at + 1);

  const env = readEnv();
  const host = env.DB_HOST || '127.0.0.1';
  const port = Number(env.DB_PORT) || 3306;

  say();
  say(`El usuario "${appUser}" no tiene permiso para crear la base de datos "${dbName}".`);
  say('Puedo dárselo ahora si me indicas un usuario administrador de MySQL (normalmente "root").');
  say('Esos datos se usan solo en este momento y NO se guardan.');

  for (let attempt = 0; attempt < 3; attempt++) {
    const adminUser = (await ask('Usuario administrador [root] (escribe "no" para cancelar): ')) || 'root';
    if (adminUser.toLowerCase() === 'no') return false;
    const adminPass = await ask(`Contraseña de "${adminUser}" (Enter si no tiene): `, { trim: false });

    let admin;
    try {
      admin = await mysql.createConnection({ host, port, user: adminUser, password: adminPass, charset: 'utf8mb4', connectTimeout: 5000 });
    } catch (err) {
      say('  No pude entrar con ese usuario: ' + (err.code || err.message));
      continue;
    }
    try {
      await admin.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
      await admin.query(`GRANT ALL PRIVILEGES ON \`${dbName}\`.* TO ?@?`, [appUser, appHost]);
      await admin.query('FLUSH PRIVILEGES');
      say(`  Listo: "${appUser}" ahora tiene permisos sobre "${dbName}".`);
      return true;
    } catch (err) {
      say('  Ese usuario no pudo dar los permisos: ' + (err.code || err.message));
    } finally {
      await admin.end().catch(() => {});
    }
  }
  return false;
}

/* ---------- Programa principal ---------- */

(async () => {
  ensureEnvFile();

  let conn = await connectToMySQL();
  try {
    // Si hubo que pedir usuario/contraseña, se guardan para no volver a preguntarlos
    const env = readEnv();
    const currentUser = conn.config.user || 'root';
    const currentPassword = conn.config.password || '';
    if ((env.DB_USER || 'root') !== currentUser) setEnvKey('DB_USER', currentUser);
    if ((env.DB_PASSWORD || '') !== currentPassword) setEnvKey('DB_PASSWORD', currentPassword);

    const dbName = env.DB_NAME || 'aulasink';
    try {
      await ensureDatabase(conn, dbName);
    } catch (err) {
      if (!NO_PERMISSION.includes(err.code)) throw err;

      // El usuario entró, pero no puede crear la base: un administrador le da permiso (una sola vez)
      const granted = await grantViaAdmin(conn, dbName);
      if (!granted) {
        fail(`Sin permisos no puedo crear la base de datos "${dbName}".\n` +
             '  Entra a MySQL con un usuario administrador (root) y ejecuta:\n' +
             `    CREATE DATABASE IF NOT EXISTS ${dbName} CHARACTER SET utf8mb4;\n` +
             `    GRANT ALL PRIVILEGES ON ${dbName}.* TO '${currentUser}'@'localhost';\n` +
             '  Después vuelve a abrir iniciar.bat. (O usa el usuario root cuando te lo pregunte.)');
      }
      await conn.end().catch(() => {});
      conn = await connectToMySQL();          // reconecta para que apliquen los permisos nuevos
      await ensureDatabase(conn, dbName);
    }
  } catch (err) {
    fail('No se pudo preparar la base de datos: ' + (err.code || err.message));
  } finally {
    await conn.end().catch(() => {});
  }

  await ensureGroqKey();

  rl.close();
  process.exit(0);
})().catch(err => fail(err.message));
