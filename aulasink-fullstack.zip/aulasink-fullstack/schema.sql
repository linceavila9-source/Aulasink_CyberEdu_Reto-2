-- =====================================================================
-- AulaSink · schema.sql  (MySQL 8.x / MariaDB 10.5+)
-- ---------------------------------------------------------------------
-- Ejecutar con:   mysql -u root -p < schema.sql
-- (o importarlo desde phpMyAdmin / MySQL Workbench)
--
-- Modelo de datos:
--   students        → un registro por estudiante (su id lo genera el navegador)
--   lessons         → catálogo de lecciones (debe coincidir con LESSONS de app.js)
--   quiz_attempts   → cada intento de cuestionario (historial completo)
--   lesson_progress → resumen por estudiante y lección (mejor nota, intentos…)
--   (v2) users, sessions, courses, enrollments, course_invites, course_lessons,
--        assignments, submissions, files → ver la sección "v2" más abajo.
--   sync_queue      → bandeja de entrada de lo que llega desde IndexedDB.
--                     Su clave primaria es el "id" que el navegador generó para
--                     cada registro: si el mismo paquete llega dos veces
--                     (reintento por mala conexión), el segundo se detecta y
--                     NO se vuelve a contar. Eso es la idempotencia.
-- =====================================================================

-- Fuerza UTF-8 en esta sesión de importación. Sin esto, algunos clientes de
-- línea de comandos usan latin1 y los acentos (á, é, ñ…) se guardan corruptos.
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS aulasink
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE aulasink;

-- ---------------------------------------------------------------------
-- Usuario de la aplicación (recomendado: no usar root en producción).
-- Descomenta, cambia la contraseña y usa estos datos en tu archivo .env
-- ---------------------------------------------------------------------
-- CREATE USER IF NOT EXISTS 'aulasink_app'@'localhost' IDENTIFIED BY 'cambia_esta_clave';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON aulasink.* TO 'aulasink_app'@'localhost';
-- FLUSH PRIVILEGES;

-- ---------------------------------------------------------------------
-- 1. Estudiantes
--    id = UUID que el navegador guarda en localStorage (Profile.id).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
  id            VARCHAR(64)  NOT NULL,
  name          VARCHAR(80)  NULL,
  created_at    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_seen_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 2. Lecciones (catálogo)
--    Los ids deben ser los mismos que usa el frontend en app.js.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lessons (
  id          VARCHAR(40)        NOT NULL,
  subject     VARCHAR(60)        NOT NULL,
  title       VARCHAR(160)       NOT NULL,
  minutes     SMALLINT UNSIGNED  NOT NULL DEFAULT 5,
  created_at  TIMESTAMP          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

INSERT INTO lessons (id, subject, title, minutes) VALUES
  ('mate-01', 'Matemáticas', 'Fracciones: partes de un todo',            5),
  ('cien-01', 'Ciencias',    'El ciclo del agua',                        5),
  ('leng-01', 'Lenguaje',    'La oración: sujeto y predicado',           4),
  ('tec-01',  'Tecnología',  'Aprender sin conexión: ¿cómo funciona?',   4)
ON DUPLICATE KEY UPDATE
  subject = VALUES(subject),
  title   = VALUES(title),
  minutes = VALUES(minutes);

-- ---------------------------------------------------------------------
-- 3. Intentos de cuestionario (historial)
--    id = id único generado en el navegador para ese intento.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS quiz_attempts (
  id               VARCHAR(64)        NOT NULL,
  student_id       VARCHAR(64)        NOT NULL,
  lesson_id        VARCHAR(40)        NOT NULL,
  score            TINYINT UNSIGNED   NOT NULL,           -- 0 a 100
  correct_count    SMALLINT UNSIGNED  NOT NULL,
  total_questions  SMALLINT UNSIGNED  NOT NULL,
  answers          JSON               NOT NULL,           -- [{questionId, selected, correct}]
  attempted_at     DATETIME(3)        NOT NULL,           -- cuando respondió (reloj del dispositivo, en UTC)
  received_at      TIMESTAMP(3)       NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_attempts_student_lesson (student_id, lesson_id, attempted_at),
  CONSTRAINT fk_attempt_student FOREIGN KEY (student_id) REFERENCES students (id) ON DELETE CASCADE,
  CONSTRAINT fk_attempt_lesson  FOREIGN KEY (lesson_id)  REFERENCES lessons (id),
  CONSTRAINT chk_attempt_score  CHECK (score <= 100)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 4. Progreso por lección (resumen que alimenta el dashboard)
--    Se actualiza en la misma transacción que inserta el intento.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lesson_progress (
  student_id        VARCHAR(64)        NOT NULL,
  lesson_id         VARCHAR(40)        NOT NULL,
  best_score        TINYINT UNSIGNED   NOT NULL DEFAULT 0,
  last_score        TINYINT UNSIGNED   NOT NULL DEFAULT 0,
  attempts          INT UNSIGNED       NOT NULL DEFAULT 0,
  completed         TINYINT(1)         NOT NULL DEFAULT 0,
  first_attempt_at  DATETIME(3)        NOT NULL,
  last_attempt_at   DATETIME(3)        NOT NULL,
  PRIMARY KEY (student_id, lesson_id),
  CONSTRAINT fk_progress_student FOREIGN KEY (student_id) REFERENCES students (id) ON DELETE CASCADE,
  CONSTRAINT fk_progress_lesson  FOREIGN KEY (lesson_id)  REFERENCES lessons (id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- 5. Cola / bandeja de sincronización
--    Un registro por cada elemento de la "outbox" de IndexedDB.
--    status:
--      received  → llegó y se está procesando
--      processed → guardado correctamente (si vuelve a llegar, se ignora)
--      failed    → falló por un error temporal; el navegador lo reenviará
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sync_queue (
  id             VARCHAR(64)                                NOT NULL,   -- id del navegador = clave de idempotencia
  student_id     VARCHAR(64)                                NOT NULL,
  item_type      VARCHAR(40)                                NOT NULL DEFAULT 'quiz_attempt',
  payload        JSON                                       NOT NULL,   -- registro original tal como llegó
  status         ENUM('received', 'processed', 'failed')    NOT NULL DEFAULT 'received',
  attempts       SMALLINT UNSIGNED                          NOT NULL DEFAULT 1,
  error_message  VARCHAR(500)                               NULL,
  received_at    TIMESTAMP(3)                               NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  processed_at   TIMESTAMP(3)                               NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY idx_queue_status  (status, received_at),
  KEY idx_queue_student (student_id),
  CONSTRAINT fk_queue_student FOREIGN KEY (student_id) REFERENCES students (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- v2 · CUENTAS, ROLES, CURSOS, TAREAS Y CALIFICACIONES
-- ---------------------------------------------------------------------
-- Todo es idempotente (IF NOT EXISTS): puedes volver a ejecutar este archivo
-- sobre una base de datos v1 y solo añade lo que falta.
-- Las fechas de estas tablas son DATETIME(3) en UTC y las escribe la aplicación.
-- =====================================================================

-- 6. Usuarios (estudiantes y profesores).
--    Para un estudiante, users.id es el MISMO id que students.id (así la
--    sincronización offline de la v1 sigue funcionando sin cambios).
CREATE TABLE IF NOT EXISTS users (
  id             VARCHAR(64)   NOT NULL,
  email          VARCHAR(190)  NOT NULL,
  name           VARCHAR(80)   NOT NULL,
  role           ENUM('student', 'teacher') NOT NULL,
  password_hash  VARCHAR(255)  NOT NULL,
  created_at     DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  last_login_at  DATETIME(3)   NULL DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB;

-- 7. Sesiones (se guarda el HASH del token; la cookie lleva el token).
CREATE TABLE IF NOT EXISTS sessions (
  token_hash  CHAR(64)     NOT NULL,
  user_id     VARCHAR(64)  NOT NULL,
  created_at  DATETIME(3)  NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  expires_at  DATETIME(3)  NOT NULL,
  PRIMARY KEY (token_hash),
  KEY idx_sessions_user (user_id),
  KEY idx_sessions_expires (expires_at),
  CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 8. Cursos (los crea un profesor; los estudiantes entran con `code`).
CREATE TABLE IF NOT EXISTS courses (
  id           VARCHAR(64)   NOT NULL,
  teacher_id   VARCHAR(64)   NOT NULL,
  name         VARCHAR(120)  NOT NULL,
  subject      VARCHAR(60)   NULL,
  description  VARCHAR(500)  NULL,
  code         VARCHAR(12)   NOT NULL,
  join_enabled TINYINT(1)    NOT NULL DEFAULT 1,
  created_at   DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_courses_code (code),
  KEY idx_courses_teacher (teacher_id),
  CONSTRAINT fk_courses_teacher FOREIGN KEY (teacher_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 9. Matrícula: qué estudiantes están en qué curso + calificación final.
CREATE TABLE IF NOT EXISTS enrollments (
  course_id        VARCHAR(64)    NOT NULL,
  student_id       VARCHAR(64)    NOT NULL,
  joined_at        DATETIME(3)    NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  final_grade      DECIMAL(5,2)   NULL,            -- porcentaje final 0-100 asignado por el profesor
  final_comment    VARCHAR(500)   NULL,
  final_graded_at  DATETIME(3)    NULL,
  PRIMARY KEY (course_id, student_id),
  KEY idx_enrollments_student (student_id),
  CONSTRAINT fk_enroll_course  FOREIGN KEY (course_id)  REFERENCES courses (id) ON DELETE CASCADE,
  CONSTRAINT fk_enroll_student FOREIGN KEY (student_id) REFERENCES users (id)   ON DELETE CASCADE
) ENGINE=InnoDB;

-- 10. Invitaciones por correo: el estudiante aún no tiene cuenta; al registrarse
--     con ese correo entra solo al curso.
CREATE TABLE IF NOT EXISTS course_invites (
  course_id   VARCHAR(64)   NOT NULL,
  email       VARCHAR(190)  NOT NULL,
  created_at  DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (course_id, email),
  KEY idx_invites_email (email),
  CONSTRAINT fk_invites_course FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 11. Temario: lecciones del curso (ordenadas). `published` = habilitada para estudiantes.
--     questions = [{id, type: mcq|written|handwritten, prompt, points, options?, correct?, explanation?}]
CREATE TABLE IF NOT EXISTS course_lessons (
  id          VARCHAR(64)        NOT NULL,
  course_id   VARCHAR(64)        NOT NULL,
  position    INT                NOT NULL DEFAULT 0,
  title       VARCHAR(160)       NOT NULL,
  minutes     SMALLINT UNSIGNED  NOT NULL DEFAULT 5,
  content     TEXT               NOT NULL,           -- párrafos separados por una línea en blanco
  questions   JSON               NOT NULL,
  published   TINYINT(1)         NOT NULL DEFAULT 0,
  created_at  DATETIME(3)        NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at  DATETIME(3)        NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_clessons_course (course_id, position),
  CONSTRAINT fk_clessons_course FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 12. Tareas asignadas por el profesor (mismo formato de preguntas que las lecciones).
CREATE TABLE IF NOT EXISTS assignments (
  id            VARCHAR(64)   NOT NULL,
  course_id     VARCHAR(64)   NOT NULL,
  title         VARCHAR(160)  NOT NULL,
  instructions  TEXT          NOT NULL,
  questions     JSON          NOT NULL,
  due_at        DATETIME(3)   NULL,
  published     TINYINT(1)    NOT NULL DEFAULT 0,
  created_at    DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at    DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_assignments_course (course_id, due_at),
  CONSTRAINT fk_assignments_course FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 13. Entregas y avance (una por estudiante y lección/tarea).
--     answers = { questionId: {selected} | {text} | {text, files:[fileId]} }
--     grading = { questionId: {points, comment} }  (solo preguntas de calificación manual)
--     status: draft (avance guardado) · submitted (entregada, falta revisar) ·
--             graded (calificada) · returned (devuelta para corregir)
CREATE TABLE IF NOT EXISTS submissions (
  id               VARCHAR(64)                                   NOT NULL,
  course_id        VARCHAR(64)                                   NOT NULL,
  student_id       VARCHAR(64)                                   NOT NULL,
  target_type      ENUM('lesson', 'assignment')                  NOT NULL,
  target_id        VARCHAR(64)                                   NOT NULL,
  answers          JSON                                          NOT NULL,
  grading          JSON                                          NULL,
  status           ENUM('draft','submitted','graded','returned') NOT NULL DEFAULT 'draft',
  progress_pct     TINYINT UNSIGNED                              NOT NULL DEFAULT 0,   -- % de avance 0-100
  auto_points      DECIMAL(7,2)                                  NOT NULL DEFAULT 0,
  manual_points    DECIMAL(7,2)                                  NULL,
  total_points     DECIMAL(7,2)                                  NOT NULL DEFAULT 0,
  score_pct        DECIMAL(5,2)                                  NULL,                 -- nota final de la entrega
  teacher_comment  VARCHAR(1000)                                 NULL,
  attempts         INT UNSIGNED                                  NOT NULL DEFAULT 0,
  submitted_at     DATETIME(3)                                   NULL,
  graded_at        DATETIME(3)                                   NULL,
  created_at       DATETIME(3)                                   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  updated_at       DATETIME(3)                                   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  UNIQUE KEY uq_submission (student_id, target_type, target_id),
  KEY idx_submissions_target (course_id, target_type, target_id),
  KEY idx_submissions_status (course_id, status),
  CONSTRAINT fk_sub_course  FOREIGN KEY (course_id)  REFERENCES courses (id) ON DELETE CASCADE,
  CONSTRAINT fk_sub_student FOREIGN KEY (student_id) REFERENCES users (id)   ON DELETE CASCADE
) ENGINE=InnoDB;

-- 14. Archivos adjuntos (fotos de trabajos a mano). El archivo vive en UPLOAD_DIR.
CREATE TABLE IF NOT EXISTS files (
  id          VARCHAR(64)   NOT NULL,
  owner_id    VARCHAR(64)   NOT NULL,
  course_id   VARCHAR(64)   NOT NULL,
  mime        VARCHAR(40)   NOT NULL,
  size        INT UNSIGNED  NOT NULL,
  created_at  DATETIME(3)   NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (id),
  KEY idx_files_owner (owner_id, course_id),
  CONSTRAINT fk_files_owner  FOREIGN KEY (owner_id)  REFERENCES users (id)   ON DELETE CASCADE,
  CONSTRAINT fk_files_course FOREIGN KEY (course_id) REFERENCES courses (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Consultas útiles para revisar los datos:
--   SELECT * FROM sync_queue ORDER BY received_at DESC LIMIT 20;
--   SELECT s.name, p.lesson_id, p.best_score, p.attempts, p.completed
--     FROM lesson_progress p JOIN students s ON s.id = p.student_id;
-- ---------------------------------------------------------------------
