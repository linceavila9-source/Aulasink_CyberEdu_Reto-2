/* =====================================================================
 * AulaSink · api.js
 * ---------------------------------------------------------------------
 *  - Api   → cliente de la API (cookies de sesión, errores claros en español)
 *  - Auth  → quién ha iniciado sesión (estudiante o profesor)
 *
 * Se carga ANTES que app.js. Todo lo que usa de app.js (CONFIG, store, toast…)
 * se consulta al llamar a las funciones, nunca al cargar el archivo.
 * ===================================================================== */
'use strict';

class ApiError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;   // 0 = sin conexión con el servidor
    this.code = code;
  }
  get offline() { return this.status === 0; }
}

const Api = {
  async request(method, path, body, { timeout = 15000 } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    let response;
    try {
      response = await fetch(CONFIG.API_BASE + path, {
        method,
        credentials: 'include',                 // envía la cookie de sesión
        headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal
      });
    } catch (err) {
      throw new ApiError(0, err.name === 'AbortError'
        ? 'El servidor tardó demasiado en responder. Inténtalo de nuevo.'
        : 'No hay conexión con el servidor.', 'network');
    } finally {
      clearTimeout(timer);
    }

    let data = null;
    try { data = await response.json(); } catch { /* respuesta sin JSON */ }

    if (!response.ok) {
      if (response.status === 401 && data && data.code === 'unauthenticated') Auth.expired();
      throw new ApiError(response.status, (data && data.error) || `Error ${response.status}`, data && data.code);
    }
    // Un portal cautivo (WiFi público) puede devolver HTML con código 200
    if (data === null) throw new ApiError(0, 'Respuesta inesperada del servidor.', 'network');
    return data;
  },
  /**
   * Lectura con respaldo local: pide al servidor y guarda una copia; sin conexión
   * (o con señal mala) responde con la última copia guardada en este dispositivo.
   * Siempre se le suman encima los cambios pendientes de enviar (ver offline.js → Overlay).
   */
  async get(path) {
    const fromMirror = async () => {
      const hit = await Mirror.get(path);
      if (hit) { Offline.noteStale(hit.at); return Overlay.apply(path, hit.data); }
      const made = Overlay.synthesize(path);          // algo creado sin conexión que nunca se descargó
      if (made) return made;
      return null;
    };
    const noNetwork = !navigator.onLine || Link.state === 'offline';
    if (noNetwork) {
      const local = await fromMirror();
      if (local) return local;
      // Sin copia: se intenta igual (el aviso de “offline” puede ser falso)
    }
    try {
      const data = await Api.request('GET', path, undefined, { timeout: Link.state === 'good' ? 15000 : 7000 });
      Mirror.set(path, data);                         // copia exacta del servidor (se clona dentro)
      return Overlay.apply(path, data);
    } catch (err) {
      if (!err.offline) throw err;
      const local = await fromMirror();
      if (local) return local;
      throw err;
    }
  },
  post: (path, body, opts) => Api.request('POST', path, body === undefined ? {} : body, opts),
  put: (path, body) => Api.request('PUT', path, body === undefined ? {} : body),
  patch: (path, body) => Api.request('PATCH', path, body === undefined ? {} : body),
  del: path => Api.request('DELETE', path),
  fileUrl: id => `${CONFIG.API_BASE}/files/${id}`
};

const Auth = {
  user: null,
  offline: false,    // true: no se pudo verificar la sesión, se usa el usuario guardado en este dispositivo

  get isTeacher() { return Boolean(Auth.user && Auth.user.role === 'teacher'); },
  get isStudent() { return Boolean(Auth.user && Auth.user.role === 'student'); },

  /** Usuario recordado en este dispositivo: permite abrir la app y estudiar sin Internet. */
  remembered() {
    try { return JSON.parse(store.get('aulasink.user') || 'null'); } catch { return null; }
  },
  remember(user) { store.set('aulasink.user', user ? JSON.stringify(user) : ''); },

  /** Pregunta al servidor quién soy. Sin red, usa el usuario recordado. */
  async init() {
    try {
      const { user } = await Api.get('/auth/me');
      Auth.user = user;
      Auth.offline = false;
      Auth.remember(user);
    } catch (err) {
      Auth.user = null;
      Auth.offline = false;
      if (err.offline) {
        const saved = Auth.remembered();
        if (saved && saved.id && saved.role) { Auth.user = saved; Auth.offline = true; }
      } else {
        Auth.remember(null);
      }
    }
    return Auth.user;
  },

  /** Al volver la conexión: confirma que la sesión sigue siendo válida. */
  async revalidate() {
    if (!Auth.offline) return;
    await Auth.init();
    if (!Auth.user) { toast('Tu sesión terminó. Inicia sesión de nuevo.', 'warn'); location.hash = '#/login'; }
  },

  async login(email, password) {
    const { user } = await Api.post('/auth/login', { email, password });
    Auth.user = user; Auth.offline = false; Auth.remember(user);
    return user;
  },

  async register(data) {
    const res = await Api.post('/auth/register', data);
    Auth.user = res.user; Auth.offline = false; Auth.remember(res.user);
    return res;
  },

  async logout() {
    try { await Api.post('/auth/logout'); } catch { /* sin red: se cierra igualmente en este dispositivo */ }
    Auth.user = null; Auth.offline = false; Auth.remember(null);
  },

  /** El servidor dijo 401: la sesión caducó. */
  expired() {
    if (!Auth.user) return;
    Auth.user = null; Auth.offline = false; Auth.remember(null);
    toast('Tu sesión terminó. Inicia sesión de nuevo.', 'warn');
    location.hash = '#/login';
    if (typeof onAuthChanged === 'function') onAuthChanged();
  }
};

/* =====================================================================
 * CONEXIÓN INTELIGENTE
 * ---------------------------------------------------------------------
 *  Autosave → la pantalla actual (lección, tarea, editor, calificación) registra
 *             una función que guarda su trabajo. Se ejecuta SOLA cuando:
 *             la señal se vuelve inestable o se pierde, la pestaña se oculta,
 *             se cierra la página o el usuario cambia de pantalla.
 *  Link     → mide la calidad real de la conexión (no solo "hay WiFi"): un
 *             latido a /api/health cada 15 s + eventos del navegador.
 *             Estados: good · unstable · offline.
 *  Queue    → acciones (entregar, calificar, guardar una lección…) que se
 *             hicieron sin conexión. Se guardan en el dispositivo y se envían
 *             solas, en orden, al volver la señal.
 * ===================================================================== */
const Autosave = {
  fn: null,
  set(fn) { Autosave.fn = fn; },
  flush(reason) { try { if (Autosave.fn) Autosave.fn(reason); } catch (err) { console.warn('[AulaSink] autoguardado:', err); } }
};

const Link = {
  state: 'good',            // good | unstable | offline
  fails: 0,
  latency: null,
  timer: null,

  get slowType() {
    const c = navigator.connection;
    return Boolean(c && (['slow-2g', '2g'].includes(c.effectiveType) || c.saveData === true && c.effectiveType === '3g'));
  },

  set(state) {
    if (state === Link.state) return;
    const prev = Link.state;
    Link.state = state;
    Net.paint();
    if (prev === 'good' && state !== 'good') Link.degraded(state);
    else if (prev !== 'good' && state === 'good') Link.recovered();
    else if (state === 'offline') Autosave.flush('link');
  },

  /** La señal empeoró: se guarda TODO lo que esté a medias, antes de perderla. */
  degraded(state) {
    Autosave.flush('link');
    if (state === 'unstable') toast('📶 Señal inestable: guardamos tu trabajo por precaución.', 'warn');
    else if (navigator.onLine) toast('Sin conexión con el servidor. Tu trabajo está guardado en este dispositivo y se enviará solo.', 'warn');
  },

  recovered() {
    Queue.flush();
    if (typeof Sync !== 'undefined') Sync.flush();
    if (typeof Offline !== 'undefined') Offline.syncSoon(true);
  },

  async ping() {
    if (document.hidden) return;
    if (!navigator.onLine) { Link.fails = 2; return Link.set('offline'); }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    const t0 = performance.now();
    try {
      // Cualquier respuesta HTTP (incluso 503) significa que la red llega al servidor
      await fetch(CONFIG.API_BASE + '/health', { cache: 'no-store', signal: controller.signal });
      Link.fails = 0;
      Link.latency = Math.round(performance.now() - t0);
      Link.set(Link.latency > 2500 || Link.slowType ? 'unstable' : 'good');
    } catch {
      Link.fails += 1;
      Link.set(Link.fails >= 2 ? 'offline' : 'unstable');
      if (Link.fails === 1) setTimeout(() => Link.ping(), 3000);     // confirma rápido si fue un tropiezo
    } finally {
      clearTimeout(timer);
    }
  },

  start() {
    Link.ping();
    Link.timer = setInterval(() => Link.ping(), 15000);
    window.addEventListener('online', () => { Link.fails = 0; Link.ping(); });
    window.addEventListener('offline', () => { Link.fails = 2; Link.set('offline'); });
    if (navigator.connection && navigator.connection.addEventListener) navigator.connection.addEventListener('change', () => Link.ping());
    document.addEventListener('visibilitychange', () => { if (document.hidden) Autosave.flush('hidden'); else Link.ping(); });
    window.addEventListener('pagehide', () => Autosave.flush('hidden'));
  }
};

const Queue = {
  flushing: false,
  retryTimer: null,

  key() { return Auth.user ? `aulasink.queue.${Auth.user.id}` : null; },
  list() {
    const key = Queue.key();
    if (!key) return [];
    try { return JSON.parse(store.get(key) || '[]'); } catch { return []; }
  },
  write(list) {
    const key = Queue.key();
    if (!key) return false;
    try { localStorage.setItem(key, JSON.stringify(list)); return true; } catch { return false; }
  },
  count() { return Queue.list().length; },

  /** Guarda una acción para enviarla luego. Con `key`, la última versión reemplaza a la anterior. */
  add(action) {
    const list = Queue.list().filter(i => !(action.key && i.key === action.key));
    list.push({ id: uid(), createdAt: new Date().toISOString(), ...action });
    if (!Queue.write(list)) throw new ApiError(0, 'No hay espacio para guardar esto en el dispositivo.', 'storage');
    if (typeof updateBadge === 'function') updateBadge();
  },

  discard(id) {
    Queue.write(Queue.list().filter(i => i.id !== id));
    if (typeof updateBadge === 'function') updateBadge();
  },

  /** Envía las acciones guardadas, en orden. Se detiene si vuelve a faltar la red. */
  async flush({ manual = false } = {}) {
    if (Queue.flushing || !Auth.user) return;
    let list = Queue.list();
    if (!list.length) { if (manual) toast('No hay acciones pendientes.', 'ok'); return; }
    if (!Net.online) { if (manual) toast('Sin conexión: se enviarán solas al reconectar.', 'warn'); return; }

    Queue.flushing = true;
    let sent = 0, dropped = 0, retry = false;
    try {
      for (const item of list) {
        try {
          const body = await Photos.resolveBody(item.body, item.path);   // sube las fotos tomadas sin conexión
          await Api.request(item.method, item.path, body, { timeout: 30000 });
          sent++;
        } catch (err) {
          if (err.offline || err.status === 401 || err.status >= 500 || err.status === 429) { retry = true; break; }
          if (err.status === 409 && item.ok409) { sent++; }        // ya estaba hecho (reintento)
          else if (err.status === 404 && item.ok404) { sent++; }   // ya no existe: borrar de nuevo no hace falta
          else { dropped++; toast(`No se pudo enviar «${item.label || 'una acción'}»: ${err.message}`, 'warn'); }
        }
        Queue.write(Queue.list().filter(i => i.id !== item.id));   // se quita de la cola ya enviada o descartada
      }
    } finally {
      Queue.flushing = false;
    }
    if (sent) { toast(`✅ ${sent} acción(es) pendiente(s) enviada(s)`, 'ok'); if (typeof Offline !== 'undefined') Offline.syncSoon(true); }
    if (retry) { clearTimeout(Queue.retryTimer); Queue.retryTimer = setTimeout(() => Queue.flush(), 30000); }
    if (typeof updateBadge === 'function') await updateBadge();
    if (sent && typeof refreshView === 'function') refreshView();
    return { sent, dropped };
  }
};

/**
 * Como Api.request, pero si NO hay conexión la acción se guarda en la cola y se
 * envía sola después. Devuelve { queued: true } en ese caso.
 * Solo para acciones que se pueden repetir sin efectos dobles.
 *
 *  label     texto que ve el usuario en la pantalla de sincronización
 *  key       la última acción con la misma clave reemplaza a la anterior
 *  supersede claves de otras acciones que esta deja sin efecto (p. ej. una entrega anula su borrador)
 *  ok409     un 409 al reintentar significa “ya estaba hecho”
 *  ok404     un 404 al reintentar significa “ya no existe” (borrados)
 *  op        descriptor para mostrar el cambio de inmediato (offline.js → Overlay)
 */
Api.mutate = async function mutate(method, path, body, { label, key, ok409 = false, ok404 = false, op, supersede = [] } = {}) {
  const drop = k => { const l = Queue.list(); if (l.some(i => i.key === k)) Queue.write(l.filter(i => i.key !== k)); };
  const enqueue = () => {
    supersede.forEach(drop);
    Queue.add({ method, path, body, label, key, ok409, ok404, op });
    return { queued: true };
  };

  // Sin red conocida: directo a la cola (sin esperar un tiempo de espera inútil)
  if (!navigator.onLine) return enqueue();

  try {
    const sendBody = await Photos.resolveBody(body, path);       // fotos provisionales → reales
    const res = await Api.request(method, path, sendBody, { timeout: Link.state === 'good' ? 20000 : 8000 });
    // Si había una versión vieja de esta misma acción en la cola, ya no sirve: la nueva la reemplaza
    if (key) drop(key);
    supersede.forEach(drop);
    if (typeof Offline !== 'undefined') Offline.syncSoon();
    return res;
  } catch (err) {
    if (!err.offline) throw err;
    return enqueue();
  }
};
