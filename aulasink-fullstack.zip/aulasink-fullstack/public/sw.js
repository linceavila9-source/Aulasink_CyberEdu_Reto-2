/* =====================================================================
 * AulaSink · sw.js  (Service Worker)
 * ---------------------------------------------------------------------
 * Estrategia: CACHE-FIRST con precaché versionado.
 *
 *  1. install  → descarga y guarda TODOS los recursos de la app
 *                (HTML, CSS, JS, manifest, iconos) en Cache Storage.
 *  2. activate → borra cachés de versiones anteriores.
 *  3. fetch    → responde desde la caché; solo va a la red si el recurso
 *                no está guardado. Sin red y sin caché → respuesta 503.
 *  4. sync     → (Background Sync) avisa a la app para que envíe su cola.
 *
 * ⚠️ AL PUBLICAR CAMBIOS: sube el número de VERSION. Es lo que hace que el
 *    navegador detecte un SW nuevo, vuelva a precachear y descarte lo viejo.
 *    En desarrollo: DevTools → Application → Service Workers →
 *    marca "Update on reload" (o "Bypass for network").
 * ===================================================================== */
'use strict';

const VERSION = 'v3.1.2';   // v3.1.0: tutor sin conexión; v3.0.0: toda la plataforma sin conexión (copia local de cursos/tareas/entregas + fotos); v2.1.0: cola y conexión inteligente
const PRECACHE = `aulasink-precache-${VERSION}`;   // recursos de la app (fijos por versión)
const RUNTIME = `aulasink-runtime-${VERSION}`;     // otros GET del mismo origen que se vayan usando
const FILES = 'aulasink-files';                        // fotos de entregas: NO cambia con la versión (así no se re-descargan)
const BG_SYNC_TAG = 'aulasink-sync';               // debe coincidir con CONFIG.BG_SYNC_TAG de app.js

// Rutas RELATIVAS al sw.js: funcionan en la raíz y en subcarpetas (GitHub Pages).
// Si añades archivos nuevos a la app (imágenes, fuentes, otros .js), agrégalos aquí.
const PRECACHE_URLS = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './api.js',
  './offline.js',
  './tutor-local.js',
  './ui.js',
  './views-auth.js',
  './views-student.js',
  './views-teacher.js',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './img/icon-1.png', './img/icon-2.png', './img/icon-3.png', './img/icon-4.png', './img/icon-5.png',
  './img/card-bg-2.png', './img/card-bg-3.png', './img/card-bg-4.png', './img/card-bg-5.png'
];

/* ---------- 1. INSTALL: precaché ---------- */
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(PRECACHE).then(cache =>
      // cache:'reload' evita que la caché HTTP del navegador nos entregue archivos viejos
      cache.addAll(PRECACHE_URLS.map(url => new Request(url, { cache: 'reload' })))
    )
    // OJO: no llamamos a skipWaiting() aquí. La versión nueva espera a que el
    // usuario pulse "Actualizar" (mensaje SKIP_WAITING) para no cambiar la app
    // a mitad de un cuestionario.
  );
});

/* ---------- 2. ACTIVATE: limpiar versiones antiguas ---------- */
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keep = new Set([PRECACHE, RUNTIME, FILES]);
    const names = await caches.keys();
    await Promise.all(
      names
        .filter(name => name.startsWith('aulasink-') && !keep.has(name))
        .map(name => caches.delete(name))
    );
    // Toma el control de las pestañas abiertas sin esperar a recargar
    await self.clients.claim();
  })());
});

/* ---------- 3. FETCH: responder offline ---------- */
self.addEventListener('fetch', event => {
  const request = event.request;

  // Solo interceptamos GET. Los POST (envío de respuestas al servidor) pasan
  // directo a la red; si fallan, la app los deja en su cola de IndexedDB.
  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Ignoramos otros orígenes (analytics, CDNs…)
  if (url.origin !== self.location.origin) return;

  // Fotos de las entregas (/api/files/ID): una foto nunca cambia, así que se guarda al verla
  // (o al descargar los datos) y se sirve sin red. Se borra al cerrar sesión (offline.js → wipe).
  if (url.pathname.includes('/api/files/')) {
    event.respondWith(cachedFile(request));
    return;
  }

  // El resto de la API nunca se sirve desde esta caché: la app guarda sus propias copias
  // de los datos en IndexedDB (offline.js) y así controla qué es actual y qué está pendiente.
  if (url.pathname.includes('/api/')) return;

  // Navegación (el usuario abre/recarga la app): devolvemos el "app shell".
  // Como el router usa hash (#/lessons), siempre es el mismo index.html.
  if (request.mode === 'navigate') {
    event.respondWith(appShell(request));
    return;
  }

  // Resto de recursos (css, js, imágenes…): cache-first
  event.respondWith(cacheFirst(request));
});

async function appShell(request) {
  const cached = await caches.match('./index.html');
  if (cached) return cached;
  try {
    return await fetch(request);            // primera visita, aún sin precaché
  } catch {
    return offlineResponse();
  }
}

async function cacheFirst(request) {
  // ignoreSearch: "styles.css?v=2" también encuentra "styles.css"
  const cached = await caches.match(request, { ignoreSearch: true });
  if (cached) return cached;

  try {
    const response = await fetch(request);
    // Guardamos en caché dinámica lo que se descargue bien (respuestas "basic" = mismo origen)
    if (response.ok && response.type === 'basic') {
      const cache = await caches.open(RUNTIME);
      cache.put(request, response.clone());
    }
    return response;
  } catch {
    return offlineResponse();
  }
}

async function cachedFile(request) {
  const cache = await caches.open(FILES);
  const hit = await cache.match(request.url);
  if (hit) return hit;
  try {
    const response = await fetch(request);
    if (response.ok) cache.put(request.url, response.clone());
    return response;
  } catch {
    return offlineResponse();
  }
}

function offlineResponse() {
  return new Response('Sin conexión y este recurso aún no está guardado.', {
    status: 503,
    statusText: 'Service Unavailable',
    headers: { 'Content-Type': 'text/plain; charset=utf-8' }
  });
}

/* ---------- 4. MENSAJES desde la app ---------- */
self.addEventListener('message', event => {
  // La app pide activar de inmediato la versión nueva (botón "Actualizar")
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

/* ---------- 5. BACKGROUND SYNC (Chromium) ----------
 * Cuando el navegador recupera la conexión, dispara este evento aunque la
 * app no esté en primer plano. El SW no toca IndexedDB: solo avisa a las
 * ventanas abiertas, y app.js (Sync.flush) hace el envío real.
 * Si no hay ninguna ventana abierta, el envío ocurrirá la próxima vez que
 * se abra la app (Sync.flush() se ejecuta al arrancar) o al evento "online".
 */
self.addEventListener('sync', event => {
  if (event.tag === BG_SYNC_TAG) {
    event.waitUntil((async () => {
      const windows = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      windows.forEach(client => client.postMessage({ type: 'SYNC_REQUESTED' }));
    })());
  }
});
