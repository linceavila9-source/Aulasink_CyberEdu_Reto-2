/* =====================================================================
 * AulaSink · tutor-local.js
 * ---------------------------------------------------------------------
 * Tutor SIN conexión. Responde con preguntas predeterminadas que el
 * estudiante solo toca, y también entiende preguntas escritas buscando en
 * el contenido de la lección que ya está guardado en el dispositivo.
 *
 * No usa IA: todo se arma con el texto de la lección + respuestas
 * redactadas a mano. Por eso:
 *   · funciona sin Internet y responde al instante;
 *   · NUNCA da la respuesta de un ejercicio: las «pistas» solo señalan el
 *     fragmento de la lección que hay que releer (igual que el tutor con IA).
 *
 * Se carga antes de app.js. No depende de nada más.
 * ===================================================================== */
'use strict';

const TutorLocal = (() => {
  /* ---------- Texto: normalizar y comparar ---------- */
  const STOP = new Set(('el la los las un una unos unas de del al a en y o u que es son se por para con sin su sus lo le les me mi tu ' +
    'te yo si no mas muy como cual cuales cuando donde quien esto esta este estos estas eso esa ese hay ser fue era sobre entre ' +
    'pregunta leccion explicame dime dame puedes puede puedo hago hacer quiero necesito ayuda ayudame favor').split(' '));

  const norm = s => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const tokens = s => norm(s).split(/[^a-z0-9]+/).filter(w => w.length > 2 && !STOP.has(w));
  const stem = w => (w.length > 5 ? w.slice(0, 5) : w);          // «fracciones» ≈ «fraccion» ≈ «fracc»
  const stems = s => new Set(tokens(s).map(stem));

  function overlap(aSet, bSet) {
    let n = 0;
    for (const w of aSet) if (bSet.has(w)) n++;
    return n;
  }

  const clip = (s, n = 420) => (s.length > n ? s.slice(0, n).replace(/\s+\S*$/, '') + '…' : s);
  const firstSentence = p => { const m = /^(.+?[.!?])(\s|$)/.exec(p); return (m ? m[1] : p).trim(); };

  /* ---------- Respuestas de la app (siempre disponibles) ---------- */
  const APP_HELP = [
    { q: '📴 ¿Puedo usar AulaSink sin Internet?', k: 'internet conexion offline sin red senal wifi funciona',
      a: 'Sí. Si abriste la app con conexión al menos una vez, tus cursos, lecciones y tareas quedan guardados en tu dispositivo. Puedes verlos, responder y entregar sin Internet. Cuando vuelva la señal, todo se envía solo.' },
    { q: '📬 ¿Cómo entrego una tarea sin conexión?', k: 'entregar entrega tarea enviar subir offline',
      a: 'Responde la tarea y toca «Entregar». Verás «Entrega guardada en este dispositivo». No cierres sesión: se enviará sola al volver la señal, con la hora a la que la hiciste. Tu nota aparecerá después de que se envíe.' },
    { q: '📷 ¿Puedo adjuntar fotos sin conexión?', k: 'foto fotos imagen camara adjuntar mano',
      a: 'Sí. La foto se guarda en tu dispositivo (se marca con ⏳) y se sube sola antes de enviar tu entrega. Haz la foto con buena luz y que se lea bien.' },
    { q: '🔄 ¿Cómo sé qué falta por enviar?', k: 'pendiente pendientes sincronizar sincronizacion enviar falta',
      a: 'Mira el número rojo en «Sincronizar» (menú) o abre esa pantalla: ahí aparece todo lo pendiente y puedes tocar «Sincronizar ahora» cuando tengas señal.' }
  ];

  const STUDY_TIPS = [
    { q: '🧠 Consejos para estudiar mejor', k: 'estudiar consejos tips aprender memorizar tecnica',
      a: 'Prueba esto:\n• Lee la lección una vez completa y luego explícala con tus palabras, sin mirar.\n• Estudia en bloques de 20–25 minutos con pausas cortas.\n• Intenta el cuestionario sin mirar y repasa solo lo que fallaste.\n• Repite al día siguiente: recordar con espacio funciona mejor que repasar todo de golpe.' },
    { q: '😕 No entiendo la lección, ¿qué hago?', k: 'entiendo entender confuso dificil ayuda atascado perdido',
      a: 'Vamos paso a paso:\n1. Relee solo el primer párrafo y dime con tus palabras qué dice.\n2. Si no se entiende, anota la palabra que te frena.\n3. Busca un ejemplo concreto de tu vida.\n4. Si sigues atascado, pregunta a tu profesor o, con Internet, escríbeme tu duda y la pensamos juntos.' }
  ];

  /* ---------- Respuestas redactadas a mano para las lecciones incluidas ---------- */
  const FAQ = {
    'mate-01': [
      { q: '¿Cómo sé si dos fracciones son equivalentes?', k: 'equivalente equivalentes iguales misma cantidad simplificar',
        a: 'Dos fracciones son equivalentes si valen lo mismo. Para comprobarlo, multiplica (o divide) el numerador y el denominador por el MISMO número. Ejemplo: 1/2 → ×2 → 2/4 → ×2 → 4/8. Todas valen lo mismo.' },
      { q: '¿Cómo se lee una fracción como 3/8?', k: 'leer lee fraccion tres octavos numerador denominador',
        a: 'Se lee primero el número de arriba y luego el de abajo con su nombre: 3/8 = «tres octavos». Quiere decir que el todo se dividió en 8 partes iguales y tomaste 3.' },
      { q: '¿Para qué sirven las fracciones en la vida diaria?', k: 'sirven vida diaria usar cocina receta repartir',
        a: 'Para repartir y medir: media pizza, un cuarto de litro, tres cuartos de hora… Siempre que dividas algo en partes iguales, estás usando fracciones.' }
    ],
    'cien-01': [
      { q: '¿Cuál es la diferencia entre evaporación y condensación?', k: 'diferencia evaporacion condensacion contrario opuesto',
        a: 'Son procesos opuestos. En la evaporación el agua líquida se convierte en vapor al calentarse. En la condensación el vapor se enfría y vuelve a ser gotitas de agua líquida (así se forman las nubes).' },
      { q: '¿Por qué las nubes no se caen?', k: 'nubes caen flotan porque ligeras gotas',
        a: 'Las gotitas de una nube son tan pequeñas y livianas que el aire que sube las mantiene suspendidas. Cuando se juntan y crecen, pesan demasiado y caen como lluvia.' },
      { q: '¿Qué pasa con el agua cuando cae al suelo?', k: 'agua cae suelo rios filtra mar despues luego',
        a: 'Corre por los ríos hacia el mar o se filtra bajo la tierra. Después el Sol vuelve a evaporarla y el ciclo continúa: por eso se llama «ciclo».' }
    ],
    'leng-01': [
      { q: '¿Cómo encuentro el sujeto de una oración?', k: 'encuentro encontrar sujeto identificar quien realiza accion',
        a: 'Pregúntate: «¿quién realiza la acción?» o «¿de quién se habla?». En «Los niños juegan en el parque», pregunta ¿quién juega? → «Los niños»: ese es el sujeto.' },
      { q: '¿Qué es el predicado?', k: 'predicado verbo que se dice nucleo',
        a: 'Es todo lo que se dice del sujeto. Siempre incluye el verbo, que es su núcleo. En «Los niños juegan en el parque», el predicado es «juegan en el parque».' },
      { q: '¿Cómo reconozco el verbo?', k: 'reconozco reconocer verbo accion conjugar',
        a: 'El verbo expresa una acción o un estado y cambia según quién lo hace y cuándo: juego, juegas, jugaron. Prueba a cambiar la oración al pasado: la palabra que cambia suele ser el verbo.' }
    ],
    'tec-01': [
      { q: '¿Qué es un Service Worker?', k: 'service worker serviceworker que es cache archivos',
        a: 'Es un programa del navegador que guarda los archivos de la app en una memoria llamada caché. Así la app abre aunque no haya Internet.' },
      { q: '¿Qué es IndexedDB?', k: 'indexeddb base datos local guarda respuestas',
        a: 'Es una base de datos que vive dentro de tu navegador. AulaSink la usa para guardar tus respuestas, tus cursos y tus tareas en tu dispositivo.' },
      { q: '¿Qué significa sincronizar?', k: 'sincronizar sincronizacion enviar volver conexion pendiente',
        a: 'Es enviar al servidor lo que hiciste sin conexión cuando vuelve la señal, y a la vez descargar lo nuevo. AulaSink lo hace sola y en orden.' }
    ]
  };

  /* ---------- Preguntas generadas con el contenido de CUALQUIER lección ---------- */
  function fromContent({ title, paragraphs = [], questions = [] }) {
    const out = [];
    const paras = paragraphs.map(p => String(p).trim()).filter(Boolean);

    if (paras.length) {
      out.push({ q: '📖 ¿De qué trata esta lección?', k: 'trata tema resumen resume lección explica general que',
        a: `La lección «${title}» trata de esto:\n\n${clip(paras[0], 500)}` + (paras.length > 1 ? `\n\nTiene ${paras.length} partes. Pídeme «los puntos clave» para verlas resumidas.` : '') });

      const points = paras.map(p => '• ' + clip(firstSentence(p), 160)).slice(0, 7);
      out.push({ q: '🔑 Dame los puntos clave', k: 'puntos clave importante resumen repasar esencial ideas principales',
        a: 'Lo más importante de la lección:\n' + points.join('\n') });

      const withExample = paras.filter(p => /ejemplo|por ejemplo|ej\./i.test(p));
      out.push({ q: '💡 Muéstrame un ejemplo', k: 'ejemplo ejemplos ilustra muestra caso',
        a: withExample.length ? 'Así lo explica la lección:\n\n' + withExample.map(p => clip(p, 400)).join('\n\n')
          : 'Esta lección no trae un ejemplo escrito. Inténtalo tú: inventa uno con tus palabras y compáralo con el primer párrafo. Si se parecen, ¡vas muy bien!' });

      const terms = [];
      for (const p of paras) {
        const m = /^([^:.]{2,40}):\s+(.+)$/s.exec(p);
        if (m) terms.push(`• ${m[1].trim()}: ${clip(m[2].trim(), 200)}`);
      }
      if (terms.length) out.push({ q: '📚 ¿Qué significan las palabras importantes?', k: 'palabras significan significado vocabulario definicion definiciones termino terminos que es',
        a: 'Las palabras clave de esta lección:\n' + terms.join('\n') });
    }

    if (questions.length) {
      out.push({ q: '📝 ¿Cómo me preparo para el cuestionario?', k: 'preparo preparar cuestionario examen prueba quiz evaluacion practicar',
        a: `Hay ${questions.length} pregunta(s). Para prepararte:\n1. Lee la lección completa una vez.\n2. Explica cada parte con tus palabras, sin mirar.\n3. Haz el cuestionario y, si fallas, relee el fragmento relacionado.\nSi quieres, pídeme una «pista» de cualquier pregunta: te diré qué fragmento releer, sin darte la respuesta.` });

      questions.slice(0, 6).forEach((q, i) => {
        const text = String(q.q || q.prompt || '');
        if (!text) return;
        const qs = stems(text);
        let best = null, bestScore = 0;
        for (const p of paras) { const s = overlap(qs, stems(p)); if (s > bestScore) { bestScore = s; best = p; } }
        out.push({ q: `🔎 Una pista para la pregunta ${i + 1}`, k: `pista pregunta ${i + 1} ayuda ${text}`,
          a: best && bestScore > 0
            ? `Pregunta ${i + 1}: «${clip(text, 140)}»\n\nNo te doy la respuesta, pero relee este fragmento de la lección:\n\n«${clip(best, 380)}»\n\nBusca ahí la idea que responde a la pregunta y descarta las opciones que no encajan.`
            : `Pregunta ${i + 1}: «${clip(text, 140)}»\n\nNo te doy la respuesta, pero te sugiero releer la lección completa con esta pregunta en mente y subrayar las palabras que aparezcan en ella.` });
      });
    }
    return out;
  }

  /* ---------- Conjunto de preguntas para una pantalla ---------- */
  /**
   * lesson: { id?, title, paragraphs?, questions? } o null (tutor general).
   * Devuelve [{ q, a, k, kind }] ya en el orden en que se muestran.
   */
  function entries(lesson) {
    const list = [];
    if (lesson) {
      list.push(...fromContent(lesson).map(e => ({ ...e, kind: 'lesson' })));
      if (lesson.id && FAQ[lesson.id]) list.push(...FAQ[lesson.id].map(e => ({ ...e, kind: 'lesson' })));
    }
    list.push(...STUDY_TIPS.map(e => ({ ...e, kind: 'general' })));
    list.push(...APP_HELP.map(e => ({ ...e, kind: 'app' })));
    return list;
  }

  /* ---------- Responder una pregunta escrita ---------- */
  /**
   * Busca la mejor respuesta guardada; si no hay, el fragmento de la lección que más se parece.
   * Devuelve { answer } o null si no sabe.
   */
  function answerFree(text, lesson, list) {
    const qs = [...stems(text)];
    if (!qs.length) return null;

    // Peso de cada palabra: las raras (p. ej. «entregar») pesan más que las comunes (p. ej. «internet»)
    const docs = list.map(e => ({ e, qSet: stems(e.q), kSet: stems(e.k || '') }));
    const df = w => docs.filter(d => d.qSet.has(w) || d.kSet.has(w)).length;
    const idf = w => Math.log(1 + (docs.length + 1) / (1 + df(w)));
    const total = qs.reduce((n, w) => n + idf(w), 0) || 1;

    // Cobertura: qué parte (ponderada) de la pregunta del estudiante queda cubierta
    let best = null, bestScore = 0;
    for (const d of docs) {
      const got = qs.reduce((n, w) => n + idf(w) * (d.qSet.has(w) ? 1 : d.kSet.has(w) ? 0.6 : 0), 0);
      if (got / total > bestScore) { bestScore = got / total; best = d.e; }
    }

    // También se compara con los párrafos de la lección (un poco menos prioritarios que una respuesta redactada)
    let para = null, paraScore = 0;
    if (lesson && lesson.paragraphs) {
      for (const p of lesson.paragraphs) {
        const ps = stems(p);
        const s = (qs.reduce((n, w) => n + (ps.has(w) ? idf(w) : 0), 0) / total) * 0.95;
        if (s > paraScore) { paraScore = s; para = p; }
      }
    }

    if (best && bestScore >= 0.5 && bestScore >= paraScore) return { answer: best.a, matched: best.q };
    if (para && paraScore >= 0.5) {
      return { answer: `Esto dice la lección sobre eso:\n\n«${clip(para, 420)}»\n\nSin conexión no puedo explicártelo con más detalle. Con Internet, el tutor con IA te lo explica paso a paso.`, matched: null };
    }
    return null;
  }

  return { entries, answerFree, norm };
})();
