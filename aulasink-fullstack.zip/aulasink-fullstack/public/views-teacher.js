/* =====================================================================
 * AulaSink · views-teacher.js
 * Panel docente: cursos, estudiantes, temario, tareas, revisión de
 * entregas, calificaciones y calificación final.
 * ===================================================================== */
'use strict';

/** #/course/:cid/:tab — decide la vista según el rol dentro de ESE curso. */
async function viewCourse(cid, tab) {
  let detail;
  try { detail = await Api.get(`/courses/${cid}`); } catch (err) { return errorView(err, () => render()); }
  return detail.role === 'teacher' ? viewTeacherCourse(cid, tab, detail) : viewStudentCourse(cid, tab, detail);
}

const reloadView = () => render();

/* ---------- Inicio del profesor ---------- */
async function viewTeacherHome() {
  let data, courses;
  try { [data, { courses }] = await Promise.all([Api.get('/me/overview'), Api.get('/courses')]); }
  catch (err) { return errorView(err, () => render()); }

  const stat = (value, label) => el('div', { class: 'card stat' }, el('div', { class: 'stat__value' }, String(value)), el('div', { class: 'stat__label' }, label));
  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, `Panel docente · ${Auth.user.name}`),
    el('p', { class: 'view__subtitle' }, 'Gestiona tus cursos, asigna tareas y califica a tus estudiantes.'),
    el('div', { class: 'grid grid--stats' },
      stat(data.totals.courses, 'Cursos'), stat(data.totals.students, 'Estudiantes'), stat(data.totals.pending, 'Por revisar')),
    el('h2', {}, 'Entregas por revisar'),
    data.pending.length
      ? el('div', { class: 'card' }, el('ul', { class: 'todo' }, data.pending.map(p => el('li', {},
          el('a', { href: `#/grade/${p.id}` }, `${p.studentName} · ${p.title}`),
          el('span', { class: 'muted' }, `${p.courseName} · ${p.type === 'lesson' ? 'Lección' : 'Tarea'} · ${formatDate(p.submittedAt)}`)))))
      : emptyState('No tienes entregas pendientes. 🎉'),
    el('h2', {}, 'Mis cursos'),
    courses.length ? el('div', { class: 'grid grid--lessons' }, courses.map(teacherCourseCard)) : emptyState('Aún no tienes cursos.'),
    el('div', { class: 'actions' }, el('a', { class: 'btn', href: '#/courses' }, '+ Crear curso')));
}

function teacherCourseCard(c) {
  return el('a', { class: 'card course-card', href: `#/course/${c.id}` },
    el('div', { class: 'course-card__top' }, el('span', { class: 'chip' }, c.subject || 'Curso'),
      c.pending > 0 && el('span', { class: 'chip chip--warn' }, `${c.pending} por revisar`)),
    el('h3', {}, c.name),
    el('p', { class: 'muted' }, `👥 ${c.students} estudiante(s) · 📖 ${c.lessons} lección(es) · 📝 ${c.assignments} tarea(s)`),
    el('p', { class: 'muted' }, 'Código: ', el('strong', { class: 'code' }, c.code)));
}

/* ---------- #/courses (profesor): lista + crear ---------- */
async function viewTeacherCourses() {
  let courses;
  try { ({ courses } = await Api.get('/courses')); } catch (err) { return errorView(err, () => render()); }

  const name = el('input', { class: 'input', type: 'text', maxlength: '120', required: true, placeholder: 'Ej.: Matemáticas 7° A' });
  const subject = el('input', { class: 'input', type: 'text', maxlength: '60', placeholder: 'Ej.: Matemáticas' });
  const description = el('textarea', { class: 'textarea', rows: '2', maxlength: '500', placeholder: 'Descripción breve (opcional)' });
  const btn = el('button', { class: 'btn', type: 'submit' }, 'Crear curso');

  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, 'Mis cursos'),
    el('form', { class: 'card auth__form', onsubmit: async event => {
      event.preventDefault();
      await withBusy(btn, async () => {
        const { id } = await Api.post('/courses', { name: name.value, subject: subject.value, description: description.value });
        toast('Curso creado. Comparte el código con tus estudiantes.', 'ok');
        location.hash = `#/course/${id}/people`;
      });
    } }, el('h2', {}, 'Nuevo curso'), field('Nombre', name), field('Materia', subject), field('Descripción', description), btn),
    courses.length ? el('div', { class: 'grid grid--lessons' }, courses.map(teacherCourseCard)) : emptyState('Aún no tienes cursos. Crea el primero arriba.'));
}

/* ---------- Curso (profesor) ---------- */
const TEACHER_TABS = [['lessons', 'Temario'], ['tasks', 'Tareas'], ['people', 'Estudiantes'], ['grades', 'Calificaciones'], ['settings', 'Ajustes']];

async function viewTeacherCourse(cid, tab, detail) {
  const { course } = detail;
  const active = TEACHER_TABS.some(t => t[0] === tab) ? tab : 'lessons';
  let content;
  try {
    if (active === 'lessons') content = await teacherItemsTab(cid, 'lesson');
    else if (active === 'tasks') content = await teacherItemsTab(cid, 'assignment');
    else if (active === 'people') content = await teacherPeopleTab(course);
    else if (active === 'grades') content = await teacherGradesTab(cid);
    else content = teacherSettingsTab(course);
  } catch (err) { content = el('div', { class: 'card' }, el('p', {}, err.message)); }

  return el('section', { class: 'view' },
    el('a', { class: 'back-link', href: '#/courses' }, '← Mis cursos'),
    el('div', { class: 'card course-head' },
      el('span', { class: 'chip' }, course.subject || 'Curso'),
      el('h1', { class: 'view__title', tabindex: '-1' }, course.name),
      course.description && el('p', { class: 'muted' }, course.description),
      codeCard(course)),
    tabBar(TEACHER_TABS, active, key => `#/course/${cid}/${key}`),
    content);
}

function codeCard(course) {
  return el('div', { class: 'code-card' },
    el('span', { class: 'muted' }, 'Código de acceso:'),
    el('strong', { class: 'code' }, course.code),
    el('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: async () => {
      try { await navigator.clipboard.writeText(course.code); toast('Código copiado.', 'ok'); }
      catch { toast(`Código: ${course.code}`); }
    } }, 'Copiar'),
    !course.joinEnabled && el('span', { class: 'chip chip--warn' }, 'Ingreso por código desactivado'));
}

/* ---------- Temario / Tareas (gestión) ---------- */
async function teacherItemsTab(cid, type) {
  const isLesson = type === 'lesson';
  const seg = isLesson ? 'lessons' : 'assignments';
  const { items } = await Api.get(`/courses/${cid}/${seg}`);

  const newBtn = el('a', { class: 'btn', href: `#/${isLesson ? 'edit-lesson' : 'edit-task'}/${cid}/new` }, isLesson ? '+ Nueva lección' : '+ Nueva tarea');
  if (!items.length) return el('div', {}, emptyState(isLesson
    ? 'El temario está vacío. Crea lecciones con contenido y preguntas para tus estudiantes.' : 'No has asignado tareas todavía.'), el('div', { class: 'actions' }, newBtn));

  async function togglePublish(item, button) {
    await withBusy(button, async () => {
      const { item: full } = await Api.get(`/courses/${cid}/${seg}/${item.id}`);
      const res = await Offline.saveItem(cid, seg, { ...full, published: !item.published },
        { label: `${isLesson ? 'Lección' : 'Tarea'}: ${item.title}` });
      if (res.queued) toast('Sin conexión: el cambio se enviará al reconectar.', 'warn');
      else toast(item.published ? 'Ocultada para los estudiantes.' : 'Habilitada para los estudiantes.', 'ok');
      reloadView();
    });
  }
  async function move(index, delta, button) {
    const ids = items.map(i => i.id);
    [ids[index], ids[index + delta]] = [ids[index + delta], ids[index]];
    await withBusy(button, async () => {
      const res = await Offline.reorder(cid, ids);
      if (res.queued) toast('Sin conexión: el nuevo orden se enviará al reconectar.', 'warn');
      reloadView();
    });
  }
  async function remove(item, button) {
    if (!confirm(`¿Eliminar «${item.title}»? También se borrarán las entregas de los estudiantes.`)) return;
    await withBusy(button, async () => {
      const res = await Offline.removeItem(cid, seg, item.id, `Eliminar: ${item.title}`);
      toast(res.queued ? 'Sin conexión: se eliminará al reconectar.' : 'Eliminada.', res.queued ? 'warn' : undefined);
      reloadView();
    });
  }

  return el('div', {},
    el('div', { class: 'actions' }, newBtn),
    el('div', { class: 'stack' }, items.map((item, i) => {
      const c = item.counts || {};
      const total = Object.values(c).reduce((a, b) => a + b, 0);
      return el('div', { class: 'card item-manage' },
        el('div', { class: 'item-manage__top' },
          el('div', {},
            el('h3', {}, isLesson ? `${i + 1}. ${item.title}` : item.title),
            el('p', { class: 'muted' }, (isLesson ? `${item.minutes} min · ` : `${fmtDue(item.dueAt)} · `) + `${item.questionCount} pregunta(s)`)),
          el('span', { class: 'chip ' + (item.published ? 'chip--ok' : 'chip--warn') }, item.published ? 'Habilitada' : 'Oculta')),
        el('p', { class: 'muted' }, `${total} entrega(s)` + (c.submitted ? ` · ${c.submitted} por revisar` : '') + (c.graded ? ` · ${c.graded} calificada(s)` : '')),
        el('div', { class: 'actions' },
          el('a', { class: 'btn btn--small', href: `#/subs/${cid}/${type}/${item.id}` }, c.submitted ? `Revisar (${c.submitted})` : 'Respuestas'),
          el('a', { class: 'btn btn--ghost btn--small', href: `#/${isLesson ? 'edit-lesson' : 'edit-task'}/${cid}/${item.id}` }, 'Editar'),
          el('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: e => togglePublish(item, e.currentTarget) }, item.published ? 'Ocultar' : 'Habilitar'),
          isLesson && el('button', { class: 'btn btn--ghost btn--small', type: 'button', disabled: i === 0, 'aria-label': 'Subir', onclick: e => move(i, -1, e.currentTarget) }, '↑'),
          isLesson && el('button', { class: 'btn btn--ghost btn--small', type: 'button', disabled: i === items.length - 1, 'aria-label': 'Bajar', onclick: e => move(i, 1, e.currentTarget) }, '↓'),
          el('button', { class: 'btn btn--danger btn--small', type: 'button', onclick: e => remove(item, e.currentTarget) }, 'Eliminar')));
    })));
}

/* ---------- Estudiantes ---------- */
async function teacherPeopleTab(course) {
  const cid = course.id;
  const [{ members, invites }, { students: book }] = await Promise.all([Api.get(`/courses/${cid}/members`), Api.get(`/courses/${cid}/gradebook`)]);

  // Formulario: añadir por correo (invita si no tiene cuenta) o crear la cuenta directamente
  const email = el('input', { class: 'input', type: 'email', required: true, placeholder: 'correo@estudiante.com', 'aria-label': 'Correo del estudiante' });
  const createBox = el('div', { class: 'create-box', hidden: true });
  const name = el('input', { class: 'input', type: 'text', maxlength: '80', placeholder: 'Nombre del estudiante' });
  const pass = el('input', { class: 'input', type: 'text', minlength: '8', placeholder: 'Contraseña temporal (mín. 8)', autocomplete: 'off' });
  createBox.append(field('Nombre', name), field('Contraseña temporal', pass, 'Compártela con el estudiante; podrá cambiarla desde su perfil.'));
  const toggle = el('input', { type: 'checkbox', id: 'create-acc' });
  toggle.addEventListener('change', () => { createBox.hidden = !toggle.checked; });
  const addBtn = el('button', { class: 'btn', type: 'submit' }, 'Añadir al curso');

  const messages = { enrolled: 'Estudiante añadido al curso.', created: 'Cuenta creada y estudiante añadido.', already_member: 'Ese estudiante ya está en el curso.',
    invited: 'Aún no tiene cuenta: quedó invitado y entrará solo cuando se registre con ese correo.', already_invited: 'Ya estaba invitado.' };

  const addForm = el('form', { class: 'card auth__form', onsubmit: async event => {
    event.preventDefault();
    await withBusy(addBtn, async () => {
      const body = { email: email.value };
      if (toggle.checked) { body.name = name.value; body.password = pass.value; }
      const res = await Api.post(`/courses/${cid}/students`, body);
      toast(messages[res.status] || 'Listo.', 'ok');
      reloadView();
    });
  } },
    el('h2', {}, 'Añadir estudiantes'),
    el('p', { class: 'muted' }, 'Por correo: si ya tiene cuenta entra al curso; si no, queda invitado. También pueden unirse solos con el código del curso.'),
    field('Correo electrónico', email),
    el('label', { class: 'check', for: 'create-acc' }, toggle, ' Crear su cuenta ahora (registro directo)'),
    createBox, addBtn);

  const rows = book.map(s => {
    const st = s.stats;
    return el('tr', {},
      el('td', {}, el('strong', {}, s.name), el('br'), el('small', { class: 'muted' }, s.email)),
      el('td', {}, st.progress === null ? '—' : `${st.progress}%`),
      el('td', {}, `${st.assignmentsSubmitted}/${st.assignmentsTotal}`),
      el('td', {}, s.finalGrade !== null ? pctText(s.finalGrade) : '—'),
      el('td', {}, el('button', { class: 'btn btn--danger btn--small', type: 'button', onclick: async e => {
        if (!confirm(`¿Quitar a ${s.name} del curso?`)) return;
        await withBusy(e.currentTarget, async () => { await Api.del(`/courses/${cid}/students/${s.id}`); toast('Estudiante quitado.'); reloadView(); });
      } }, 'Quitar')));
  });

  return el('div', {},
    addForm,
    el('div', { class: 'card' },
      el('h2', {}, `Estudiantes (${book.length})`),
      book.length ? el('div', { class: 'table-wrap' }, el('table', { class: 'table' },
        el('thead', {}, el('tr', {}, ['Estudiante', 'Avance', 'Tareas', 'Nota final', ''].map(h => el('th', {}, h)))),
        el('tbody', {}, rows))) : el('p', { class: 'muted' }, 'Aún no hay estudiantes. Comparte el código o añádelos por correo.')),
    invites.length ? el('div', { class: 'card' },
      el('h2', {}, 'Invitaciones pendientes'),
      el('ul', { class: 'todo' }, invites.map(i => el('li', {}, el('span', {}, i.email),
        el('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: async e => {
          await withBusy(e.currentTarget, async () => { await Api.del(`/courses/${cid}/invites?email=${encodeURIComponent(i.email)}`); reloadView(); });
        } }, 'Cancelar'))))) : null,
    el('div', { class: 'card' }, el('h2', {}, 'Integrantes'), membersList(members)));
}

/* ---------- Calificaciones y nota final ---------- */
async function teacherGradesTab(cid) {
  const { students } = await Api.get(`/courses/${cid}/gradebook`);
  if (!students.length) return emptyState('Aún no hay estudiantes en el curso.');

  const rows = students.map(s => {
    const st = s.stats;
    const grade = el('input', { class: 'input input--short', type: 'number', min: '0', max: '100', step: '0.1', 'aria-label': `Nota final de ${s.name}`, placeholder: '0-100' });
    grade.value = s.finalGrade ?? '';
    const comment = el('input', { class: 'input', type: 'text', maxlength: '500', 'aria-label': `Comentario para ${s.name}`, placeholder: 'Comentario (opcional)' });
    comment.value = s.finalComment || '';
    const save = el('button', { class: 'btn btn--small', type: 'button' }, 'Guardar');
    save.addEventListener('click', () => withBusy(save, async () => {
      const res = await Api.mutate('PUT', `/courses/${cid}/students/${s.id}/final`, { grade: grade.value === '' ? null : grade.value, comment: comment.value },
        { label: `Nota final de ${s.name}`, key: `final:${cid}:${s.id}`,
          op: { k: 'final', cid, studentId: s.id, grade: grade.value === '' ? null : Number(grade.value), comment: comment.value } });
      toast(res.queued ? `Sin conexión: la nota final de ${s.name} se enviará al reconectar.` : `Nota final de ${s.name} guardada.`, res.queued ? 'warn' : 'ok');
    }));
    const suggest = st.suggestedFinal === null ? null : el('button', { class: 'btn btn--ghost btn--small', type: 'button', title: 'Usar el promedio de sus entregas calificadas',
      onclick: () => { grade.value = st.suggestedFinal; } }, `Usar ${st.suggestedFinal}`);
    return el('tr', {},
      el('td', {}, el('strong', {}, s.name)),
      el('td', {}, st.progress === null ? '—' : `${st.progress}%`),
      el('td', {}, `${st.assignmentsGraded}/${st.assignmentsTotal}`),
      el('td', {}, pctText(st.average)),
      el('td', { class: 'nowrap' }, grade, ' ', suggest),
      el('td', {}, comment), el('td', {}, save));
  });

  return el('div', { class: 'card' },
    el('h2', {}, 'Calificación final por estudiante'),
    el('p', { class: 'muted' }, 'El promedio sale de las entregas ya calificadas (lecciones y tareas). La nota final la decides tú: puedes usar el promedio o escribir otro porcentaje.'),
    el('div', { class: 'table-wrap' }, el('table', { class: 'table' },
      el('thead', {}, el('tr', {}, ['Estudiante', 'Avance', 'Tareas calif.', 'Promedio', 'Nota final (%)', 'Comentario', ''].map(h => el('th', {}, h)))),
      el('tbody', {}, rows))));
}

/* ---------- Ajustes del curso ---------- */
function teacherSettingsTab(course) {
  const name = el('input', { class: 'input', type: 'text', maxlength: '120', required: true });
  name.value = course.name;
  const subject = el('input', { class: 'input', type: 'text', maxlength: '60' });
  subject.value = course.subject || '';
  const description = el('textarea', { class: 'textarea', rows: '3', maxlength: '500' });
  description.value = course.description || '';
  const join = el('input', { type: 'checkbox', id: 'join-enabled' });
  join.checked = course.joinEnabled;
  const save = el('button', { class: 'btn', type: 'submit' }, 'Guardar cambios');

  return el('div', {},
    el('form', { class: 'card auth__form', onsubmit: async event => {
      event.preventDefault();
      await withBusy(save, async () => {
        await Api.patch(`/courses/${course.id}`, { name: name.value, subject: subject.value, description: description.value, joinEnabled: join.checked });
        toast('Curso actualizado.', 'ok'); reloadView();
      });
    } }, el('h2', {}, 'Datos del curso'), field('Nombre', name), field('Materia', subject), field('Descripción', description),
      el('label', { class: 'check', for: 'join-enabled' }, join, ' Permitir que los estudiantes se unan con el código'), save),
    el('div', { class: 'card' },
      el('h2', {}, 'Código de acceso'),
      el('p', { class: 'muted' }, 'Si lo compartiste con quien no debías, genera uno nuevo. Los estudiantes que ya están no se ven afectados.'),
      codeCard(course),
      el('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: async e => {
        if (!confirm('¿Generar un código nuevo? El anterior dejará de funcionar.')) return;
        await withBusy(e.currentTarget, async () => { await Api.post(`/courses/${course.id}/regenerate-code`); toast('Código nuevo generado.', 'ok'); reloadView(); });
      } }, 'Generar código nuevo')),
    el('div', { class: 'card' },
      el('h2', {}, 'Zona de peligro'),
      el('p', { class: 'muted' }, 'Eliminar el curso borra sus lecciones, tareas, entregas y calificaciones. No se puede deshacer.'),
      el('button', { class: 'btn btn--danger btn--small', type: 'button', onclick: async e => {
        if (!confirm(`¿Eliminar el curso «${course.name}» y todo su contenido?`)) return;
        if (prompt('Para confirmar, escribe el nombre del curso:') !== course.name) { toast('El nombre no coincide. No se eliminó nada.', 'warn'); return; }
        await withBusy(e.currentTarget, async () => { await Api.del(`/courses/${course.id}`); toast('Curso eliminado.'); location.hash = '#/courses'; });
      } }, 'Eliminar curso')));
}

/* =====================================================================
 * Editor de lección / tarea
 * ===================================================================== */
async function viewItemEditor(type, cid, id) {
  const isLesson = type === 'lesson';
  const seg = isLesson ? 'lessons' : 'assignments';
  const isNew = id === 'new';
  const itemId = isNew ? uid() : id;               // id propio: guardar dos veces (o desde la cola) nunca duplica
  const draftKey = `aulasink.tdraft.${Auth.user.id}.${type}.${cid}.${itemId === id ? id : 'new'}`;
  let item = { title: '', content: '', instructions: '', minutes: 5, dueAt: null, published: false, questions: [] };
  if (!isNew) {
    try { ({ item } = await Api.get(`/courses/${cid}/${seg}/${id}`)); } catch (err) { return errorView(err, () => render()); }
  }

  // ¿Quedó un borrador sin guardar en este dispositivo?
  let recovered = null;
  try { recovered = JSON.parse(store.get(draftKey) || 'null'); } catch { /* borrador ilegible */ }
  if (recovered && recovered.payload) {
    const d = recovered.payload;
    item = { ...item, title: d.title ?? item.title, published: Boolean(d.published), questions: d.questions || item.questions,
      ...(isLesson ? { content: d.content ?? item.content, minutes: d.minutes ?? item.minutes }
                   : { instructions: d.instructions ?? item.instructions, dueAt: d.dueAt ?? item.dueAt }) };
  }

  const title = el('input', { class: 'input', type: 'text', maxlength: '160', required: true, placeholder: isLesson ? 'Ej.: Fracciones: partes de un todo' : 'Ej.: Tarea 1 · Ejercicios de fracciones' });
  title.value = item.title;
  const body = el('textarea', { class: 'textarea', rows: isLesson ? '10' : '5', maxlength: isLesson ? '20000' : '10000',
    placeholder: isLesson ? 'Escribe el contenido de estudio. Deja una línea en blanco entre párrafos.' : 'Instrucciones para los estudiantes…' });
  body.value = isLesson ? item.content : item.instructions;
  const minutes = el('input', { class: 'input input--short', type: 'number', min: '1', max: '240' });
  minutes.value = item.minutes || 5;
  const due = el('input', { class: 'input', type: 'datetime-local' });
  if (item.dueAt) {
    const d = new Date(item.dueAt);
    due.value = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  }
  const published = el('input', { type: 'checkbox', id: 'pub' });
  published.checked = item.published;
  const builder = questionBuilder(item.questions);
  const save = el('button', { class: 'btn', type: 'submit' }, isNew ? 'Crear' : 'Guardar cambios');
  const back = `#/course/${cid}/${isLesson ? 'lessons' : 'tasks'}`;
  const draftStatus = el('small', { class: 'muted', role: 'status' });

  const collect = () => {
    const payload = { id: itemId, title: title.value, published: published.checked, questions: builder.value() };
    if (isLesson) { payload.content = body.value; payload.minutes = minutes.value; }
    else { payload.instructions = body.value; payload.dueAt = due.value ? new Date(due.value).toISOString() : null; }
    return payload;
  };

  // Borrador automático: ante cualquier cambio y SIEMPRE que la señal falle o se cambie de pantalla
  let draftTimer = null, saved = false;
  const saveDraft = () => {
    if (saved) return;
    store.set(draftKey, JSON.stringify({ payload: collect(), at: Date.now() }));
    draftStatus.textContent = '💾 Borrador guardado en este dispositivo';
  };
  const scheduleDraft = () => { clearTimeout(draftTimer); draftTimer = setTimeout(saveDraft, 800); };
  Autosave.set(() => { clearTimeout(draftTimer); saveDraft(); });

  const form = el('form', { class: 'editor', onsubmit: async event => {
    event.preventDefault();
    const payload = collect();
    await withBusy(save, async () => {
      const res = await Offline.saveItem(cid, seg, payload, { isNew, label: `${isLesson ? 'Lección' : 'Tarea'}: ${payload.title}` });
      saved = true; clearTimeout(draftTimer); store.set(draftKey, '');
      if (res.queued) {
        saved = false;
        notice.hidden = false;
        draftStatus.textContent = '';
        toast('Sin conexión: se guardó en este dispositivo y se enviará al reconectar.', 'warn');
        return;
      }
      toast('Guardado.', 'ok');
      location.hash = back;
    });
  } },
    el('div', { class: 'card auth__form' },
      field('Título', title),
      field(isLesson ? 'Contenido de estudio' : 'Instrucciones', body),
      isLesson ? field('Duración estimada (minutos)', minutes) : field('Fecha límite (opcional)', due),
      el('label', { class: 'check', for: 'pub' }, published, isLesson ? ' Habilitar esta lección para los estudiantes' : ' Publicar esta tarea para los estudiantes')),
    assistantPanel({ isLesson, title, body, builder, onChange: scheduleDraft }),
    el('h2', {}, 'Preguntas'),
    el('p', { class: 'muted' }, 'Combina tipos: opción múltiple (se califica sola), desarrollo escrito y práctica a mano con foto (las calificas tú).'
      + (isLesson ? '' : ' Si no añades preguntas, el estudiante podrá responder con texto y fotos.')),
    builder.node,
    el('div', { class: 'actions' }, save, el('a', { class: 'btn btn--ghost', href: back }, 'Cancelar'), draftStatus));

  ['input', 'change', 'click'].forEach(evt => form.addEventListener(evt, scheduleDraft));

  const notice = el('div', { class: 'card notice', hidden: true },
    el('strong', {}, '📬 Guardado en cola'),
    el('p', {}, 'Tus cambios están en este dispositivo y se enviarán solos cuando vuelva la señal. Puedes seguir editando: la última versión reemplaza a la anterior.'));

  return el('section', { class: 'view' },
    el('a', { class: 'back-link', href: back }, '← Volver al curso'),
    el('h1', { class: 'view__title', tabindex: '-1' }, `${isNew ? 'Nueva' : 'Editar'} ${isLesson ? 'lección' : 'tarea'}`),
    recovered && el('div', { class: 'card notice' },
      el('strong', {}, '📝 Recuperamos un borrador sin guardar'),
      el('p', {}, `Última edición: ${formatDate(new Date(recovered.at).toISOString())}.`),
      el('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: () => { saved = true; store.set(draftKey, ''); render(); } }, 'Descartar borrador')),
    notice,
    form);
}

/* ---------- Asistente de IA dentro del editor ---------- */
function assistantPanel({ isLesson, title, body, builder, onChange }) {
  const level = el('input', { class: 'input', type: 'text', maxlength: '80', placeholder: 'Nivel o curso (ej.: 7.º grado)', 'aria-label': 'Nivel o curso' });
  const count = el('input', { class: 'input input--short', type: 'number', min: '1', max: '10', value: '5', 'aria-label': 'Cantidad de preguntas' });
  const types = ['mcq', 'written', 'handwritten'].map(t => {
    const box = el('input', { type: 'checkbox', value: t, checked: t !== 'handwritten' });
    return { box, node: el('label', { class: 'check check--inline' }, box, ` ${TYPE_ICON[t]} ${TYPE_LABEL[t]}`) };
  });
  const status = el('small', { class: 'muted', role: 'status' });
  const genQ = el('button', { class: 'btn btn--small', type: 'button' }, '✨ Generar preguntas');
  const genC = isLesson ? el('button', { class: 'btn btn--ghost btn--small', type: 'button' }, '✨ Redactar contenido') : null;

  const topic = () => title.value.trim();
  const need = () => { if (!topic()) { toast('Escribe primero el título: el asistente lo usa como tema.', 'warn'); title.focus(); return false; } return true; };

  genQ.addEventListener('click', async () => {
    if (!need()) return;
    const chosen = types.filter(t => t.box.checked).map(t => t.box.value);
    if (!chosen.length) { toast('Elige al menos un tipo de pregunta.', 'warn'); return; }
    status.textContent = 'Pensando…';
    await withBusy(genQ, async () => {
      try {
        const { questions } = await Api.post('/assistant/questions',
          { topic: topic(), level: level.value, count: Number(count.value) || 5, types: chosen, content: body.value }, { timeout: 90000 });
        questions.forEach(q => builder.add(q));
        status.textContent = `Se añadieron ${questions.length} pregunta(s). Revísalas antes de guardar: tú tienes la última palabra.`;
        onChange();
      } catch (err) { status.textContent = ''; throw err; }
    });
  });
  if (genC) genC.addEventListener('click', async () => {
    if (!need()) return;
    if (body.value.trim() && !confirm('Ya hay texto en el contenido. ¿Añadir el borrador de la IA al final?')) return;
    status.textContent = 'Redactando…';
    await withBusy(genC, async () => {
      try {
        const { text } = await Api.post('/assistant/content', { topic: topic(), level: level.value }, { timeout: 90000 });
        body.value = (body.value.trim() ? body.value.trim() + '\n\n' : '') + text;
        status.textContent = 'Borrador añadido. Edítalo a tu gusto.';
        onChange();
      } catch (err) { status.textContent = ''; throw err; }
    });
  });

  return el('details', { class: 'card assistant-panel' },
    el('summary', {}, el('strong', {}, '✨ Asistente de IA'), el('span', { class: 'muted' }, ' · genera preguntas y borradores a partir del título')),
    el('div', { class: 'assistant-panel__body' },
      el('p', { class: 'muted' }, 'La IA sugiere; tú revisas y corriges antes de guardar. Necesita conexión.'),
      field('Nivel / curso (opcional)', level),
      el('div', { class: 'assistant-panel__row' }, el('label', { class: 'inline-label' }, 'Cantidad ', count), types.map(t => t.node)),
      el('div', { class: 'actions' }, genQ, genC),
      status));
}

/* ---------- Asistente: chat para el profesor ---------- */
let assistantChat = { messages: [] };
const ASSISTANT_IDEAS = [
  'Dame 3 actividades para enseñar fracciones en 7.º grado',
  'Crea una rúbrica de 4 criterios para un ensayo corto',
  'Explícame cómo adaptar una lección para estudiantes que van más lento',
  'Ayúdame a redactar un comentario de retroalimentación amable pero claro'
];

function viewAssistant() {
  const log = el('div', { class: 'chat__log', role: 'log', 'aria-live': 'polite' });
  log.append(chatBubble('assistant', `¡Hola, ${Auth.user.name.split(' ')[0]}! Soy tu asistente docente. Puedo ayudarte a planificar clases, crear actividades y rúbricas, o redactar retroalimentación. ¿Qué necesitas?`));
  assistantChat.messages.forEach(m => log.append(chatBubble(m.role, m.content)));
  requestAnimationFrame(() => { log.scrollTop = log.scrollHeight; });

  const input = el('textarea', { rows: '2', maxlength: '1500', 'aria-label': 'Escribe tu consulta', placeholder: 'Escribe tu consulta… (Enter para enviar)' });
  const button = el('button', { class: 'btn', type: 'submit' }, 'Enviar');
  const form = el('form', { class: 'chat__form', onsubmit: event => { event.preventDefault(); askAssistant(input, button, log); } }, input, button);
  input.addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); form.requestSubmit(); } });

  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, '✨ Asistente docente'),
    el('p', { class: 'view__subtitle' }, 'Tu apoyo con IA para planificar, evaluar y retroalimentar. Sugiere; tú decides. Necesita conexión.'),
    !Net.online && el('div', { class: 'card' }, '🟠 Sin conexión: el asistente volverá a responder cuando tengas Internet.'),
    el('div', { class: 'chips' }, ASSISTANT_IDEAS.map(text => el('button', { class: 'chip chip--button', type: 'button',
      onclick: () => { input.value = text; input.focus(); } }, text))),
    el('div', { class: 'card chat' }, log, form));
}

async function askAssistant(input, button, log) {
  const text = input.value.trim();
  if (!text) return;
  if (!Net.online) { toast('El asistente necesita Internet.', 'warn'); return; }
  const chat = assistantChat;
  const history = chat.messages.slice(-8);
  chat.messages.push({ role: 'user', content: text });
  log.append(chatBubble('user', text));
  input.value = '';
  const waiting = chatBubble('assistant', 'Pensando…', 'is-waiting');
  log.append(waiting);
  log.scrollTop = log.scrollHeight;
  input.disabled = true; button.disabled = true;
  try {
    const { reply } = await Api.post('/assistant/chat', { message: text, history }, { timeout: 60000 });
    chat.messages.push({ role: 'assistant', content: reply });
    waiting.textContent = reply;
    waiting.classList.remove('is-waiting');
  } catch (err) {
    chat.messages.pop();
    waiting.textContent = '⚠️ ' + err.message;
    waiting.classList.remove('is-waiting'); waiting.classList.add('is-error');
    input.value = text;
  } finally {
    input.disabled = false; button.disabled = false; input.focus();
    log.scrollTop = log.scrollHeight;
  }
}

/* =====================================================================
 * Entregas de una lección / tarea
 * ===================================================================== */
async function viewSubmissions(cid, type, tid) {
  const seg = type === 'lesson' ? 'lessons' : 'assignments';
  let data;
  try { data = await Api.get(`/courses/${cid}/${seg}/${tid}/submissions`); } catch (err) { return errorView(err, () => render()); }
  const rows = data.rows.map(r => el('tr', {},
    el('td', {}, el('strong', {}, r.student.name), el('br'), el('small', { class: 'muted' }, r.student.email)),
    el('td', {}, statusChip(r.submission, { lesson: type === 'lesson' }), r.submission && r.submission.late && el('small', { class: 'is-overdue' }, ' ⏰ tardía')),
    el('td', {}, r.submission ? `${r.submission.progressPct}%` : '—'),
    el('td', {}, r.submission && r.submission.submittedAt ? formatDate(r.submission.submittedAt) : '—'),
    el('td', {}, r.submission && r.submission.status !== 'draft'
      ? el('a', { class: 'btn btn--small', href: `#/grade/${r.submission.id}` }, r.submission.status === 'submitted' ? 'Revisar' : 'Ver / editar nota') : null)));

  return el('section', { class: 'view' },
    el('a', { class: 'back-link', href: `#/course/${cid}/${type === 'lesson' ? 'lessons' : 'tasks'}` }, '← Volver al curso'),
    el('h1', { class: 'view__title', tabindex: '-1' }, data.target.title),
    el('p', { class: 'view__subtitle' }, `${type === 'lesson' ? 'Lección' : 'Tarea'} · ${data.target.questionCount} pregunta(s)` + (type === 'assignment' ? ` · ${fmtDue(data.target.dueAt)}` : '')),
    data.rows.length ? el('div', { class: 'card table-wrap' }, el('table', { class: 'table' },
      el('thead', {}, el('tr', {}, ['Estudiante', 'Estado', 'Avance', 'Entregada', ''].map(h => el('th', {}, h)))), el('tbody', {}, rows)))
      : emptyState('No hay estudiantes en el curso.'));
}

/* =====================================================================
 * Calificar una entrega
 * ===================================================================== */
async function viewGrade(sid) {
  let data;
  try { data = await Api.get(`/submissions/${sid}`); } catch (err) { return errorView(err, () => render()); }
  const { submission: sub, student, target, questions, course } = data;
  const back = `#/subs/${course.id}/${target.type}/${target.id}`;
  const inputs = {};                                    // qid → { points, comment }
  const gkey = `aulasink.gdraft.${Auth.user.id}.${sid}`;
  let gdraft = {};
  try { gdraft = JSON.parse(store.get(gkey) || '{}'); } catch { /* borrador ilegible */ }
  let finished = false;

  const cards = questions.map((q, i) => {
    const a = sub.answers[q.id];
    const g = sub.grading[q.id] || {};
    const card = el('article', { class: 'card qcard' },
      el('div', { class: 'qcard__head' }, el('span', { class: 'chip' }, `${TYPE_ICON[q.type]} ${TYPE_LABEL[q.type]}`), el('span', { class: 'muted' }, `${q.points} pt`)),
      el('h3', { class: 'qcard__prompt' }, `${i + 1}. ${q.prompt}`));

    if (q.type === 'mcq') {
      const ok = a && a.selected === q.correct;
      card.append(el('div', { class: 'feedback ' + (ok ? 'is-ok' : 'is-bad') },
        el('p', {}, el('strong', {}, 'Respondió: '), a && a.selected !== undefined ? `${'ABCDEF'[a.selected]}. ${q.options[a.selected]}` : 'Sin responder'),
        !ok && el('p', {}, el('strong', {}, 'Correcta: '), `${'ABCDEF'[q.correct]}. ${q.options[q.correct]}`),
        el('p', { class: 'muted' }, ok ? `+${q.points} pt (automático)` : '0 pt (automático)')));
    } else {
      card.append(el('div', { class: 'answer-box' }, answerView(q, a)));
      const points = el('input', { class: 'input input--short', type: 'number', min: '0', max: String(q.points), step: '0.5', 'aria-label': `Puntaje de la pregunta ${i + 1}` });
      const d = (gdraft.grades && gdraft.grades[q.id]) || {};
      points.value = d.points ?? g.points ?? '';
      const comment = el('input', { class: 'input', type: 'text', maxlength: '500', placeholder: 'Comentario para el estudiante (opcional)', 'aria-label': `Comentario de la pregunta ${i + 1}` });
      comment.value = d.comment ?? g.comment ?? '';
      inputs[q.id] = { points, comment };

      // Sugerencia de la IA (solo respuestas escritas): el profesor decide
      const hint = el('small', { class: 'muted', role: 'status' });
      const suggest = a && a.text && a.text.trim()
        ? el('button', { class: 'btn btn--ghost btn--small', type: 'button' }, '💡 Sugerir comentario') : null;
      if (suggest) suggest.addEventListener('click', () => withBusy(suggest, async () => {
        hint.textContent = 'Pensando…';
        try {
          const r = await Api.post('/assistant/feedback', { question: q.prompt, answer: a.text, maxPoints: q.points }, { timeout: 60000 });
          comment.value = r.comment;
          hint.textContent = r.suggestedPoints === null ? 'Comentario sugerido.' : `Sugerencia de la IA: ${r.suggestedPoints} / ${q.points} pt (tú decides el puntaje).`;
          scheduleGradeDraft();
        } catch (err) { hint.textContent = ''; throw err; }
      }));
      card.append(el('div', { class: 'grade-row' }, el('label', { class: 'inline-label' }, 'Puntaje ', points, ` / ${q.points}`), comment, suggest), hint);
    }
    return card;
  });

  const overall = el('textarea', { class: 'textarea', rows: '3', maxlength: '1000', placeholder: 'Comentario general (lo verá el estudiante)' });
  overall.value = gdraft.comment ?? sub.teacherComment ?? '';
  const saveBtn = el('button', { class: 'btn', type: 'button' }, 'Guardar calificación');
  const returnBtn = el('button', { class: 'btn btn--ghost', type: 'button' }, '↩️ Devolver para corregir');
  const actionsBox = el('div', { class: 'actions' }, saveBtn, returnBtn);

  const collect = () => {
    const grades = {};
    for (const [qid, f] of Object.entries(inputs)) grades[qid] = { points: f.points.value === '' ? null : f.points.value, comment: f.comment.value };
    return grades;
  };
  // Borrador local de la calificación: si se va la señal o se cambia de pantalla no se pierde
  let gtimer = null;
  const saveGradeDraft = () => {
    if (finished) return;
    store.set(gkey, JSON.stringify({ grades: collect(), comment: overall.value, at: Date.now() }));
  };
  function scheduleGradeDraft() { clearTimeout(gtimer); gtimer = setTimeout(saveGradeDraft, 600); }
  Autosave.set(() => { clearTimeout(gtimer); saveGradeDraft(); });
  Object.values(inputs).forEach(f => [f.points, f.comment].forEach(n => n.addEventListener('input', scheduleGradeDraft)));
  overall.addEventListener('input', scheduleGradeDraft);

  const queuedNotice = () => {
    finished = true; store.set(gkey, '');
    actionsBox.replaceChildren(el('div', { class: 'notice' }, el('strong', {}, '📬 Calificación guardada en este dispositivo'),
      el('p', {}, 'No hay conexión ahora. Se enviará automáticamente cuando vuelva la señal.'),
      el('a', { class: 'btn btn--ghost btn--small', href: '#/dashboard' }, 'Ir al panel')));
    toast('Sin conexión: la calificación se enviará al reconectar.', 'warn');
  };

  /** Misma regla que el servidor, para mostrar el resultado ya mismo si se califica sin conexión. */
  function localOutcome(grades) {
    let total = 0, auto = 0, manual = 0, complete = true;
    for (const q of questions) {
      const max = Number(q.points) || 0;
      total += max;
      if (q.type === 'mcq') { const a = sub.answers[q.id]; if (a && a.selected === q.correct) auto += max; continue; }
      const g = grades[q.id] || {};
      let p = g.points !== null && g.points !== '' && g.points !== undefined ? Number(g.points) : (sub.grading[q.id] && sub.grading[q.id].points);
      if (p === undefined || p === null || Number.isNaN(Number(p))) complete = false;
      else manual += Math.min(Math.max(Number(p), 0), max);
    }
    return { status: complete ? 'graded' : 'submitted', scorePct: complete && total > 0 ? Math.round(((auto + manual) / total) * 10000) / 100 : null, manualPoints: complete ? manual : null };
  }

  saveBtn.addEventListener('click', () => withBusy(saveBtn, async () => {
    const grades = collect();
    const res = await Api.mutate('PUT', `/submissions/${sid}/grade`, { grades, comment: overall.value },
      { label: `Calificación de ${student.name} · ${target.title}`, key: `grade:${sid}`, supersede: [`return:${sid}`],
        op: { k: 'grade', sid, grades, comment: overall.value, ...localOutcome(grades) } });
    if (res.queued) return queuedNotice();
    finished = true; store.set(gkey, '');
    if (res.status === 'graded') { toast(`Calificada: ${pctText(res.scorePct)}`, 'ok'); location.hash = back; }
    else { toast('Guardado. Faltan preguntas por puntuar para cerrar la calificación.', 'warn'); reloadView(); }
  }));
  returnBtn.addEventListener('click', () => {
    if (!confirm('¿Devolver la entrega al estudiante para que la corrija?')) return;
    withBusy(returnBtn, async () => {
      const res = await Api.mutate('POST', `/submissions/${sid}/return`, { comment: overall.value },
        { label: `Devolver a ${student.name} · ${target.title}`, key: `return:${sid}`, ok409: true, supersede: [`grade:${sid}`],
          op: { k: 'return', sid, comment: overall.value } });
      if (res.queued) return queuedNotice();
      finished = true; store.set(gkey, '');
      toast('Devuelta al estudiante.', 'ok'); location.hash = back;
    });
  });

  return el('section', { class: 'view' },
    el('a', { class: 'back-link', href: back }, '← Volver a las entregas'),
    el('h1', { class: 'view__title', tabindex: '-1' }, student.name),
    el('p', { class: 'view__subtitle' }, `${course.name} · ${target.title} · enviada ${formatDate(sub.submittedAt)}`),
    el('div', { class: 'card grade-summary' },
      statusChip({ status: sub.status, scorePct: sub.scorePct, progressPct: sub.progressPct, pendingSync: sub.pendingSync }),
      el('span', {}, `Automático: ${sub.autoPoints} / ${sub.totalPoints} pt`),
      sub.attempts > 1 && el('span', { class: 'muted' }, `Intento ${sub.attempts}`)),
    cards,
    el('div', { class: 'card' }, el('h2', {}, 'Comentario general'), overall,
      actionsBox));
}
