/* =====================================================================
 * AulaSink · ui.js
 * Componentes compartidos por las vistas de estudiante y profesor:
 * etiquetas de estado, pestañas, errores, subida de fotos, formulario de
 * preguntas (3 tipos) y constructor de preguntas para el profesor.
 * ===================================================================== */
'use strict';

const TYPE_LABEL = { mcq: 'Opción múltiple', written: 'Desarrollo escrito', handwritten: 'Práctica a mano' };
const TYPE_ICON = { mcq: '🔘', written: '✍️', handwritten: '📷' };
const MAX_FILES = 5;

/* ---------- Pequeños ayudantes ---------- */
const pctText = n => (n === null || n === undefined ? '—' : `${Math.round(n * 10) / 10}%`);

function fmtDue(iso) {
  if (!iso) return 'Sin fecha límite';
  return 'Vence ' + new Date(iso).toLocaleString('es', { dateStyle: 'medium', timeStyle: 'short' });
}

/** Etiqueta de estado de una entrega (o "Sin empezar" si no existe). */
function statusChip(sub, { lesson = false } = {}) {
  if (!sub) return el('span', { class: 'chip chip--warn' }, 'Sin empezar');
  if (sub.pendingSync && sub.status === 'submitted') return el('span', { class: 'chip chip--warn' }, '📬 Entrega por enviar');
  if (sub.pendingSync && sub.status === 'graded') return el('span', { class: 'chip chip--warn' }, '📬 Nota por enviar');
  switch (sub.status) {
    case 'draft': return el('span', { class: 'chip chip--warn' }, `En curso · ${sub.progressPct}%`);
    case 'submitted': return el('span', { class: 'chip' }, 'Enviada · por revisar');
    case 'returned': return el('span', { class: 'chip chip--bad' }, 'Devuelta para corregir');
    default:
      return el('span', { class: 'chip chip--ok' }, sub.scorePct === null || sub.scorePct === undefined
        ? (lesson ? 'Completada' : 'Calificada') : `Calificada · ${pctText(sub.scorePct)}`);
  }
}

function initials(name) {
  return String(name || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

const roleLabel = role => (role === 'teacher' ? 'Profesor/a' : 'Estudiante');

function emptyState(text, action) {
  return el('div', { class: 'card empty' }, el('p', { class: 'muted' }, text), action || null);
}

/** Barra de pestañas con enlaces (#/course/ID/tab). */
function tabBar(tabs, active, hrefFor) {
  return el('nav', { class: 'tabs', 'aria-label': 'Secciones del curso' },
    tabs.map(([key, label]) => el('a', { href: hrefFor(key), class: 'tab', 'aria-current': key === active ? 'page' : null }, label)));
}

/** Pantalla de error amigable (sin conexión, sin permiso, no existe…). */
function errorView(err, retry) {
  const offline = err && err.offline;
  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, offline ? 'Aún no está en este dispositivo' : 'No se pudo abrir'),
    el('div', { class: 'card' },
      el('p', {}, offline
        ? 'Esta pantalla todavía no se ha descargado. Ábrela una vez con conexión y quedará disponible sin Internet. Mientras tanto puedes usar lo que ya descargaste y las lecciones de práctica.'
        : (err && err.message) || 'Ocurrió un error inesperado.'),
      el('div', { class: 'actions' },
        retry && el('button', { class: 'btn', type: 'button', onclick: retry }, 'Reintentar'),
        el('a', { class: 'btn btn--ghost', href: '#/dashboard' }, 'Ir al inicio'))));
}

/** Ejecuta una acción asíncrona deshabilitando el botón y mostrando el error si falla. */
async function withBusy(button, fn) {
  if (button) button.disabled = true;
  try { return await fn(); }
  catch (err) {
    toast(err.offline ? 'Esta acción necesita conexión a Internet. Entregar, calificar y editar sí se guardan sin conexión.' : (err.message || 'Algo salió mal.'), 'warn');
  }
  finally { if (button) button.disabled = false; }
}

/* ---------- Imágenes: reducir antes de subir ---------- */
async function imageToDataUrl(file, maxSide = 1600, quality = 0.82) {
  if (!file || !file.type.startsWith('image/')) throw new Error('Elige un archivo de imagen.');
  // FileReader + data: (la política de seguridad de la app no permite imágenes blob:)
  const source = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('No se pudo leer la imagen.'));
    reader.onload = () => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('No se pudo abrir la imagen. Prueba con una foto JPG o PNG.'));
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
  const bitmapSource = source;
  const scale = Math.min(1, maxSide / Math.max(bitmapSource.width, bitmapSource.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bitmapSource.width * scale);
  canvas.height = Math.round(bitmapSource.height * scale);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff';                      // fondo blanco para PNG con transparencia
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bitmapSource, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL('image/jpeg', quality);
}

function photoThumb(id, onRemove) {
  if (Photos.isLocal(id)) {          // foto tomada sin conexión: vive en el dispositivo hasta subirse
    const img = el('img', { alt: 'Foto del trabajo (pendiente de subir)' });
    Photos.dataUrl(id).then(url => { if (url) img.src = url; });
    return el('div', { class: 'thumb' }, img,
      el('span', { class: 'thumb__pending', title: 'Se subirá al volver la conexión' }, '⏳'),
      onRemove && el('button', { type: 'button', class: 'thumb__remove', 'aria-label': 'Quitar imagen', onclick: onRemove }, '×'));
  }
  return el('div', { class: 'thumb' },
    el('a', { href: Api.fileUrl(id), target: '_blank', rel: 'noopener', title: 'Abrir imagen completa' },
      el('img', { src: Api.fileUrl(id), alt: 'Foto del trabajo', loading: 'lazy' })),
    onRemove && el('button', { type: 'button', class: 'thumb__remove', 'aria-label': 'Quitar imagen', onclick: onRemove }, '×'));
}

/* ---------- Respuesta de un estudiante (solo lectura) ---------- */
function answerView(question, answer) {
  if (!answer) return el('p', { class: 'muted' }, 'Sin respuesta.');
  if (question.type === 'mcq') {
    return el('p', {}, answer.selected === undefined ? 'Sin respuesta.' : `${'ABCDEF'[answer.selected]}. ${question.options[answer.selected]}`);
  }
  return el('div', {},
    answer.text && el('p', { class: 'answer-text' }, answer.text),
    answer.files && answer.files.length ? el('div', { class: 'thumbs' }, answer.files.map(id => photoThumb(id))) : null,
    !answer.text && !(answer.files && answer.files.length) ? el('p', { class: 'muted' }, 'Sin respuesta.') : null);
}

/* =====================================================================
 * Formulario de preguntas del ESTUDIANTE
 * ---------------------------------------------------------------------
 * opts: { questions, answers (se modifica), courseId, editable, review?, grading?, onChange }
 * Con editable=false muestra las respuestas, lo correcto (review) y las
 * notas y comentarios del profesor (grading).
 * ===================================================================== */
function questionForm({ questions, answers, courseId, editable, review, grading, onChange }) {
  const changed = () => { if (onChange) onChange(); };

  const cards = questions.map((q, index) => {
    const head = el('div', { class: 'qcard__head' },
      el('span', { class: 'chip' }, `${TYPE_ICON[q.type]} ${TYPE_LABEL[q.type]}`),
      el('span', { class: 'muted' }, `${q.points} ${q.points === 1 ? 'punto' : 'puntos'}`));
    const title = el('h3', { class: 'qcard__prompt' }, `${index + 1}. ${q.prompt}`);
    const body = el('div', { class: 'qcard__body' });
    const card = el('article', { class: 'card qcard' }, head, title, body);

    if (q.type === 'mcq') {
      const info = review && review[q.id];
      const buttons = q.options.map((text, i) => {
        const chosen = answers[q.id] && answers[q.id].selected === i;
        let cls = 'option' + (chosen ? ' is-selected' : '');
        if (info) {
          if (i === info.correct) cls += ' is-correct';
          else if (chosen) cls += ' is-wrong';
        }
        const btn = el('button', { type: 'button', class: cls, disabled: !editable, 'aria-pressed': chosen ? 'true' : 'false' },
          el('span', { class: 'option__letter', 'aria-hidden': 'true' }, 'ABCDEF'[i]), el('span', {}, text));
        btn.addEventListener('click', () => {
          answers[q.id] = { selected: i };
          buttons.forEach((b, j) => { b.classList.toggle('is-selected', j === i); b.setAttribute('aria-pressed', j === i ? 'true' : 'false'); });
          changed();
        });
        return btn;
      });
      body.append(el('div', { class: 'options' }, buttons));
      if (info) {
        body.append(el('div', { class: 'feedback ' + (info.isCorrect ? 'is-ok' : 'is-bad'), role: 'status' },
          el('strong', {}, info.isCorrect ? '¡Correcto! 🎉' : 'Casi… 🤔'),
          info.explanation && el('p', {}, info.explanation)));
      }
    } else if (q.type === 'written') {
      if (editable) {
        const area = el('textarea', { class: 'textarea', rows: '6', maxlength: '8000', 'aria-label': `Respuesta a la pregunta ${index + 1}`,
          placeholder: 'Escribe aquí tu desarrollo…' });
        area.value = (answers[q.id] && answers[q.id].text) || '';
        const counter = el('small', { class: 'muted' }, `${area.value.length} caracteres`);
        area.addEventListener('input', () => {
          if (area.value.trim()) answers[q.id] = { text: area.value }; else delete answers[q.id];
          counter.textContent = `${area.value.length} caracteres`;
          changed();
        });
        body.append(area, counter);
      } else {
        body.append(answerView(q, answers[q.id]));
      }
    } else {   // handwritten
      if (editable) body.append(handwrittenInput(q, answers, courseId, changed));
      else body.append(answerView(q, answers[q.id]));
    }

    // Nota y comentario del profesor (preguntas de calificación manual)
    const g = grading && grading[q.id];
    if (g && (g.points !== undefined || g.comment)) {
      body.append(el('div', { class: 'teacher-note' },
        g.points !== undefined && el('strong', {}, `Puntaje: ${g.points} / ${q.points}`),
        g.comment && el('p', {}, '💬 ' + g.comment)));
    }
    return card;
  });
  return el('div', { class: 'qlist' }, cards);
}

/** Zona para adjuntar fotos del trabajo hecho a mano (+ nota opcional). */
function handwrittenInput(q, answers, courseId, changed) {
  const entry = () => (answers[q.id] = answers[q.id] || {});
  const clean = () => {
    const a = answers[q.id];
    if (a && !(a.files && a.files.length) && !(a.text && a.text.trim())) delete answers[q.id];
  };

  const thumbs = el('div', { class: 'thumbs' });
  const status = el('small', { class: 'muted', role: 'status' });
  const input = el('input', { type: 'file', accept: 'image/*', class: 'file-input', id: `file-${q.id}`, hidden: true });
  const addBtn = el('label', { class: 'btn btn--ghost btn--small', for: `file-${q.id}` }, '📷 Añadir foto');

  function paint() {
    const files = (answers[q.id] && answers[q.id].files) || [];
    thumbs.replaceChildren(...files.map(id => photoThumb(id, () => {
      entry().files = files.filter(f => f !== id);
      if (!entry().files.length) delete entry().files;
      clean(); paint(); changed();
    })));
    addBtn.hidden = files.length >= MAX_FILES;
  }

  input.addEventListener('change', async () => {
    const file = input.files && input.files[0];
    input.value = '';
    if (!file) return;
    status.textContent = Net.online ? 'Subiendo foto…' : 'Guardando foto en el dispositivo…';
    try {
      const dataUrl = await imageToDataUrl(file);
      let id;
      if (Net.online) {
        try { ({ id } = await Api.post(`/courses/${courseId}/uploads`, { dataUrl }, { timeout: 45000 })); }
        catch (err) { if (!err.offline) throw err; }
      }
      if (!id) {                                  // sin señal: la foto queda aquí y se sube sola después
        id = await Photos.save(courseId, dataUrl);
        toast('📷 Foto guardada en este dispositivo. Se subirá sola cuando vuelva la conexión.', 'warn');
      }
      const files = entry().files || [];
      entry().files = [...files, id].slice(0, MAX_FILES);
      status.textContent = '';
      paint(); changed();
    } catch (err) {
      status.textContent = '';
      toast(err.message || 'No se pudo subir la foto.', 'warn');
    }
  });

  const note = el('textarea', { class: 'textarea', rows: '2', maxlength: '2000', 'aria-label': 'Nota opcional',
    placeholder: 'Nota opcional para tu profesor…' });
  note.value = (answers[q.id] && answers[q.id].text) || '';
  note.addEventListener('input', () => {
    if (note.value.trim()) entry().text = note.value; else if (answers[q.id]) delete answers[q.id].text;
    clean(); changed();
  });

  paint();
  return el('div', { class: 'handwritten' },
    el('p', { class: 'muted' }, 'Resuélvelo en una hoja, toma una foto clara (con buena luz) y adjúntala. Hasta 5 fotos.'),
    thumbs, el('div', { class: 'actions' }, addBtn, input), status, note);
}

/** % de preguntas respondidas (misma regla que el servidor). */
function answeredCount(questions, answers) {
  return questions.filter(q => {
    const a = answers[q.id];
    if (!a) return false;
    if (q.type === 'mcq') return Number.isInteger(a.selected);
    if (q.type === 'written') return Boolean(a.text && a.text.trim());
    return Boolean((a.files && a.files.length) || (a.text && a.text.trim()));
  }).length;
}

/* =====================================================================
 * Constructor de preguntas del PROFESOR
 * Devuelve { node, value() } — value() lee el formulario y arma la lista.
 * ===================================================================== */
function questionBuilder(initial = []) {
  const blocks = [];                            // { id, type, root, get() }
  const list = el('div', { class: 'qb__list' });
  const hint = el('p', { class: 'muted' }, 'Aún no hay preguntas. Añade la primera con los botones de abajo.');

  function repaint() {
    list.replaceChildren(...blocks.map((b, i) => {
      b.number.textContent = `Pregunta ${i + 1}`;
      b.up.disabled = i === 0;
      b.down.disabled = i === blocks.length - 1;
      return b.root;
    }));
    hint.hidden = blocks.length > 0;
  }

  function addBlock(q) {
    const block = { id: q.id || null, type: q.type };
    const number = el('strong', {});
    const up = el('button', { type: 'button', class: 'btn btn--ghost btn--small', 'aria-label': 'Subir pregunta' }, '↑');
    const down = el('button', { type: 'button', class: 'btn btn--ghost btn--small', 'aria-label': 'Bajar pregunta' }, '↓');
    const remove = el('button', { type: 'button', class: 'btn btn--danger btn--small', 'aria-label': 'Eliminar pregunta' }, 'Eliminar');
    const prompt = el('textarea', { class: 'textarea', rows: '2', maxlength: '1000', placeholder: 'Escribe el enunciado…', 'aria-label': 'Enunciado' });
    prompt.value = q.prompt || '';
    const points = el('input', { type: 'number', class: 'input input--short', min: '0.5', max: '100', step: '0.5', 'aria-label': 'Puntos' });
    points.value = q.points ?? (q.type === 'mcq' ? 1 : 5);

    const extra = el('div', {});
    let readExtra = () => ({});

    if (q.type === 'mcq') {
      const group = `correct-${Math.random().toString(36).slice(2)}`;
      const rows = el('div', { class: 'opt-rows' });
      const optionRows = [];
      const addOption = (text = '', checked = false) => {
        const radio = el('input', { type: 'radio', name: group, 'aria-label': 'Es la opción correcta' });
        radio.checked = checked;
        const input = el('input', { type: 'text', class: 'input', maxlength: '200', placeholder: 'Texto de la opción', 'aria-label': 'Opción' });
        input.value = text;
        const del = el('button', { type: 'button', class: 'btn btn--ghost btn--small', 'aria-label': 'Quitar opción' }, '×');
        const row = el('div', { class: 'opt-row' }, radio, input, del);
        const entry = { radio, input, row };
        del.addEventListener('click', () => {
          if (optionRows.length <= 2) { toast('Una pregunta de opción múltiple necesita al menos 2 opciones.', 'warn'); return; }
          optionRows.splice(optionRows.indexOf(entry), 1); row.remove();
        });
        optionRows.push(entry); rows.append(row);
      };
      const opts = q.options && q.options.length ? q.options : ['', ''];
      opts.forEach((t, i) => addOption(t, q.correct === i));
      const addBtn = el('button', { type: 'button', class: 'btn btn--ghost btn--small' }, '+ Añadir opción');
      addBtn.addEventListener('click', () => {
        if (optionRows.length >= 6) { toast('Máximo 6 opciones.', 'warn'); return; }
        addOption();
      });
      const explanation = el('input', { type: 'text', class: 'input', maxlength: '500', placeholder: 'Explicación que verá el estudiante al entregar (opcional)', 'aria-label': 'Explicación' });
      explanation.value = q.explanation || '';
      extra.append(el('p', { class: 'muted' }, 'Marca con el círculo la opción correcta.'), rows, addBtn, explanation);
      readExtra = () => ({
        options: optionRows.map(r => r.input.value),
        correct: optionRows.findIndex(r => r.radio.checked),
        explanation: explanation.value
      });
    } else {
      extra.append(el('p', { class: 'muted' }, q.type === 'written'
        ? 'El estudiante responderá con texto libre. Tú la calificarás.'
        : 'El estudiante resolverá en una hoja y adjuntará fotos. Tú las calificarás.'));
    }

    block.root = el('article', { class: 'card qb__item' },
      el('div', { class: 'qcard__head' },
        el('span', {}, number, ' ', el('span', { class: 'chip' }, `${TYPE_ICON[q.type]} ${TYPE_LABEL[q.type]}`)),
        el('span', { class: 'qb__tools' }, up, down, remove)),
      prompt, el('label', { class: 'inline-label' }, 'Puntos ', points), extra);
    block.number = number; block.up = up; block.down = down;
    block.get = () => ({ ...(block.id ? { id: block.id } : {}), type: q.type, prompt: prompt.value,
      points: Number(points.value) || 1, ...readExtra() });

    up.addEventListener('click', () => { const i = blocks.indexOf(block); if (i > 0) { blocks.splice(i, 1); blocks.splice(i - 1, 0, block); repaint(); } });
    down.addEventListener('click', () => { const i = blocks.indexOf(block); if (i < blocks.length - 1) { blocks.splice(i, 1); blocks.splice(i + 1, 0, block); repaint(); } });
    remove.addEventListener('click', () => { if (confirm('¿Eliminar esta pregunta?')) { blocks.splice(blocks.indexOf(block), 1); repaint(); } });

    blocks.push(block);
    repaint();
    return block;
  }

  initial.forEach(addBlock);

  const adders = el('div', { class: 'actions' },
    ['mcq', 'written', 'handwritten'].map(type =>
      el('button', { type: 'button', class: 'btn btn--ghost btn--small', onclick: () => {
        const b = addBlock({ type });
        b.root.querySelector('textarea').focus();
      } }, `+ ${TYPE_ICON[type]} ${TYPE_LABEL[type]}`)));

  return {
    node: el('div', { class: 'qb' }, hint, list, adders),
    value: () => blocks.map(b => b.get()),
    add: q => addBlock(q),                  // lo usa el asistente de IA para insertar preguntas
    count: () => blocks.length
  };
}
