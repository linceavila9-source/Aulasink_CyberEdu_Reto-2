/* =====================================================================
 * AulaSink · offline.js
 * ---------------------------------------------------------------------
 * Hace que TODA la plataforma (cursos, lecciones, tareas, entregas,
 * calificaciones…) se pueda usar sin Internet.
 *
 *  Mirror  → copia local (IndexedDB) de cada respuesta de la API. Se
 *            actualiza sola cada vez que hay conexión.
 *  Overlay → encima de esa copia se “pintan” los cambios que el usuario
 *            hizo sin conexión y siguen en la cola de envío. Así lo que
 *            entregó o calificó se ve de inmediato, aunque aún no llegue
 *            al servidor. La copia NUNCA se modifica: es siempre lo que
 *            dijo el servidor; la cola es la fuente de lo pendiente.
 *  Photos  → fotos de “práctica a mano” tomadas sin conexión. Se guardan
 *            en el dispositivo y se suben solas al volver la señal.
 *  Offline → descarga automática de todo lo del usuario (cursos, temario,
 *            tareas, integrantes, entregas…) y utilidades de la interfaz.
 *
 * Se carga DESPUÉS de api.js y ANTES de app.js. Lo que usa de otros
 * archivos (Api, Queue, Auth, Net, store, toast, el, uid…) se consulta al
 * llamar a las funciones, nunca al cargar el archivo.
 * ===================================================================== */
'use strict';

/* =====================================================================
 * MIRROR · copia local de la API (una base por cuenta)
 * ===================================================================== */
const Mirror = (() => {
  const BASE = 'aulasink-offline';
  let name = BASE;
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(name, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('api')) db.createObjectStore('api', { keyPath: 'path' });
        if (!db.objectStoreNames.contains('photos')) db.createObjectStore('photos', { keyPath: 'id' });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => { dbPromise = null; reject(req.error); };
      req.onblocked = () => { dbPromise = null; reject(new Error('IndexedDB bloqueada')); };
    });
    return dbPromise;
  }

  async function tx(store, mode, fn) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const t = db.transaction(store, mode);
      const request = fn(t.objectStore(store));
      let result;
      if (request) request.onsuccess = () => { result = request.result; };
      t.oncomplete = () => resolve(result);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error);
    });
  }

  return {
    /** Cambia a la copia local de esta cuenta (iniciar sesión / cambiar de usuario). */
    use(userId) {
      const next = userId ? `${BASE}-${userId}` : BASE;
      if (next === name) return;
      if (dbPromise) dbPromise.then(db => db.close()).catch(() => {});
      name = next;
      dbPromise = null;
    },

    async get(path) { try { return (await tx('api', 'readonly', s => s.get(path))) || null; } catch { return null; } },

    /** Guarda una copia (se clona AHORA, antes de que nadie modifique el objeto). */
    async set(path, data) {
      let copy;
      try { copy = JSON.parse(JSON.stringify(data)); } catch { return; }
      try { await tx('api', 'readwrite', s => s.put({ path, data: copy, at: Date.now() })); } catch { /* sin espacio: se ignora */ }
    },

    async count() { try { return await tx('api', 'readonly', s => s.count()); } catch { return 0; } },

    getPhoto: id => tx('photos', 'readonly', s => s.get(id)).catch(() => null),
    putPhoto: rec => tx('photos', 'readwrite', s => s.put(rec)),
    deletePhoto: id => tx('photos', 'readwrite', s => s.delete(id)).catch(() => {}),
    allPhotos: () => tx('photos', 'readonly', s => s.getAll()).catch(() => []),

    /** Borra por completo la copia local de la cuenta actual. */
    async wipe() {
      const current = name;
      try { if (dbPromise) (await dbPromise).close(); } catch { /* ya cerrada */ }
      dbPromise = null;
      await new Promise(resolve => {
        const req = indexedDB.deleteDatabase(current);
        req.onsuccess = req.onerror = req.onblocked = () => resolve();
      });
    }
  };
})();

/* =====================================================================
 * PHOTOS · fotos tomadas sin conexión
 * ===================================================================== */
const Photos = {
  isLocal: id => typeof id === 'string' && id.startsWith('local-'),

  /** Guarda la foto en el dispositivo y devuelve un id provisional (“local-…”). */
  async save(courseId, dataUrl) {
    const id = 'local-' + uid();
    await Mirror.putPhoto({ id, courseId, dataUrl, at: Date.now(), remoteId: null });
    return id;
  },

  async dataUrl(id) {
    const rec = await Mirror.getPhoto(id);
    return rec ? rec.dataUrl : null;
  },

  /**
   * Antes de enviar un cuerpo con respuestas: sube las fotos provisionales y
   * cambia sus ids por los reales. Sin conexión lanza el error de red (la acción
   * se queda en cola); una foto inválida se omite con un aviso.
   */
  async resolveBody(body, path) {
    if (!body || !body.answers || !JSON.stringify(body.answers).includes('"local-')) return body;
    const m = /^\/courses\/([^/]+)\//.exec(path);
    const courseId = m && m[1];
    const copy = JSON.parse(JSON.stringify(body));
    for (const answer of Object.values(copy.answers)) {
      if (!answer || !Array.isArray(answer.files)) continue;
      const out = [];
      for (const id of answer.files) {
        if (!Photos.isLocal(id)) { out.push(id); continue; }
        const rec = await Mirror.getPhoto(id);
        if (!rec) continue;                                            // la foto se perdió del dispositivo
        if (!rec.remoteId) {
          try {
            const res = await Api.request('POST', `/courses/${courseId}/uploads`, { dataUrl: rec.dataUrl }, { timeout: 45000 });
            rec.remoteId = res.id;
            await Mirror.putPhoto(rec);
          } catch (err) {
            if (err.offline || err.status === 401 || err.status >= 500 || err.status === 429) throw err;
            toast('Una foto no se pudo subir y se omitió: ' + err.message, 'warn');
            continue;
          }
        }
        out.push(rec.remoteId);
      }
      if (out.length) answer.files = out; else delete answer.files;
    }
    return copy;
  },

  /** Libera espacio: quita las fotos ya subidas hace más de una semana. */
  async prune() {
    const limit = Date.now() - 7 * 86400000;
    for (const rec of await Mirror.allPhotos()) if (rec.remoteId && rec.at < limit) await Mirror.deletePhoto(rec.id);
  }
};

/* =====================================================================
 * OVERLAY · cambios pendientes encima de la copia del servidor
 * ---------------------------------------------------------------------
 * Cada acción en cola lleva un descriptor `op`:
 *   draft   { cid, seg, tid, answers, progress }   avance de una lección/tarea
 *   submit  { cid, seg, tid, answers }             entrega
 *   save    { cid, seg, id, isNew, payload }       profesor: crear/editar/publicar
 *   delete  { cid, seg, id }                       profesor: eliminar
 *   order   { cid, ids }                           profesor: reordenar temario
 *   grade   { sid, grades, comment, status, scorePct, manualPoints }
 *   return  { sid, comment }
 *   final   { cid, studentId, grade, comment }
 * (seg = 'lessons' | 'assignments')
 * ===================================================================== */
const Overlay = {
  ops() { return Queue.list().map(i => i.op).filter(Boolean); },

  apply(path, data) {
    if (!data) return data;
    const ops = Overlay.ops();
    if (!ops.length) return data;
    try {
      let m;
      if ((m = /^\/courses\/([^/]+)\/(lessons|assignments)$/.exec(path))) return Overlay.list(ops, m[1], m[2], data);
      if ((m = /^\/courses\/([^/]+)\/(lessons|assignments)\/([^/]+)$/.exec(path))) return Overlay.detail(ops, m[1], m[2], m[3], data);
      if ((m = /^\/courses\/([^/]+)\/(lessons|assignments)\/([^/]+)\/submissions$/.exec(path))) return Overlay.submissionRows(ops, data);
      if ((m = /^\/courses\/([^/]+)\/gradebook$/.exec(path))) return Overlay.gradebook(ops, m[1], data);
      if ((m = /^\/submissions\/([^/]+)$/.exec(path))) return Overlay.submission(ops, m[1], data);
      if (path === '/me/overview') return Overlay.overview(ops, data);
    } catch (err) { console.warn('[AulaSink] no se pudo aplicar lo pendiente a', path, err); }
    return data;
  },

  /** Un elemento creado sin conexión que nunca se descargó: se arma con lo que se guardó. */
  synthesize(path) {
    const m = /^\/courses\/([^/]+)\/(lessons|assignments)\/([^/]+)$/.exec(path);
    if (!m) return null;
    const [, cid, seg, id] = m;
    if (!Overlay.ops().some(o => o.k === 'save' && o.cid === cid && o.seg === seg && o.id === id)) return null;
    const base = { id, courseId: cid, title: '', published: false, questions: [], updatedAt: null,
      ...(seg === 'lessons' ? { minutes: 5, position: 0, content: '' } : { instructions: '', dueAt: null }) };
    return Overlay.apply(path, { role: 'teacher', item: base });
  },

  /* ---- ayudantes ---- */
  fields(seg, p) {
    const out = { title: p.title, published: Boolean(p.published), questions: p.questions || [] };
    if (seg === 'lessons') { out.content = p.content || ''; out.minutes = Math.min(240, Math.max(1, parseInt(p.minutes, 10) || 5)); }
    else { out.instructions = p.instructions || ''; out.dueAt = p.dueAt || null; }
    return out;
  },

  studentSub(prev, op) {
    const submitted = op.k === 'submit';
    const sub = { id: null, attempts: 0, scorePct: null, autoPoints: 0, manualPoints: null, totalPoints: null, late: false, ...(prev || {}) };
    sub.answers = op.answers;
    sub.status = submitted ? 'submitted' : (sub.status === 'returned' ? 'returned' : 'draft');
    sub.progressPct = submitted ? 100 : (op.progress ?? sub.progressPct ?? 0);
    sub.pendingSync = true;
    return sub;
  },

  /* ---- listas de lecciones / tareas ---- */
  list(ops, cid, seg, data) {
    for (const op of ops) {
      if (op.cid !== cid || op.seg !== seg) continue;
      if (op.k === 'draft' || op.k === 'submit') {
        const it = data.items.find(i => i.id === op.tid);
        if (it) {
          const sub = Overlay.studentSub(it.submission, op);
          it.submission = { id: sub.id, status: sub.status, progressPct: sub.progressPct, scorePct: sub.scorePct, attempts: sub.attempts, pendingSync: true };
        }
      } else if (op.k === 'save') {
        const f = Overlay.fields(seg, op.payload);
        const summary = { title: f.title, published: f.published, questionCount: Math.max(f.questions.length, seg === 'assignments' ? 1 : 0),
          hasManual: f.questions.some(q => q.type && q.type !== 'mcq') || (seg === 'assignments' && !f.questions.length) };
        if (seg === 'lessons') summary.minutes = f.minutes; else summary.dueAt = f.dueAt;
        const it = data.items.find(i => i.id === op.id);
        if (it) Object.assign(it, summary);
        else data.items.push({ id: op.id, counts: {}, ...(seg === 'lessons' ? { position: data.items.length + 1 } : {}), ...summary, pendingSync: true });
      } else if (op.k === 'delete') {
        data.items = data.items.filter(i => i.id !== op.id);
      } else if (op.k === 'order' && seg === 'lessons') {
        const pos = new Map(op.ids.map((id, i) => [id, i]));
        data.items.sort((a, b) => (pos.has(a.id) ? pos.get(a.id) : 1e6) - (pos.has(b.id) ? pos.get(b.id) : 1e6));
      }
    }
    return data;
  },

  /* ---- detalle de una lección / tarea ---- */
  detail(ops, cid, seg, tid, data) {
    const item = data.item;
    if (!item) return data;
    for (const op of ops) {
      if (op.cid !== cid || op.seg !== seg) continue;
      if (data.role === 'teacher') {
        if (op.k === 'save' && op.id === tid) Object.assign(item, Overlay.fields(seg, op.payload));
      } else if ((op.k === 'draft' || op.k === 'submit') && op.tid === tid) {
        item.submission = Overlay.studentSub(item.submission, op);
        delete item.submission.review;
        const submitted = op.k === 'submit';
        item.canSave = !submitted;
        item.canSubmit = !submitted;
      }
    }
    return data;
  },

  /* ---- entregas de una tarea (profesor) ---- */
  submissionRows(ops, data) {
    for (const op of ops) {
      if (op.k !== 'grade' && op.k !== 'return') continue;
      const row = data.rows.find(r => r.submission && r.submission.id === op.sid);
      if (!row) continue;
      if (op.k === 'grade') Object.assign(row.submission, { status: op.status, scorePct: op.scorePct, pendingSync: true });
      else Object.assign(row.submission, { status: 'returned', scorePct: null, pendingSync: true });
    }
    return data;
  },

  /* ---- entrega completa (profesor) ---- */
  submission(ops, sid, data) {
    const sub = data.submission;
    for (const op of ops) {
      if (op.sid !== sid) continue;
      if (op.k === 'grade') {
        for (const [qid, g] of Object.entries(op.grades || {})) {
          const cur = { ...(sub.grading[qid] || {}) };
          if (g.points !== null && g.points !== '' && g.points !== undefined && !Number.isNaN(Number(g.points))) cur.points = Number(g.points);
          if (g.comment !== undefined) cur.comment = g.comment;
          sub.grading[qid] = cur;
        }
        if (op.comment !== undefined && op.comment !== '') sub.teacherComment = op.comment;
        Object.assign(sub, { status: op.status, scorePct: op.scorePct, manualPoints: op.manualPoints, pendingSync: true });
      } else if (op.k === 'return') {
        if (op.comment) sub.teacherComment = op.comment;
        Object.assign(sub, { status: 'returned', scorePct: null, manualPoints: null, pendingSync: true });
      }
    }
    return data;
  },

  /* ---- libro de calificaciones (profesor) ---- */
  gradebook(ops, cid, data) {
    for (const op of ops) {
      if (op.k !== 'final' || op.cid !== cid) continue;
      const s = data.students.find(x => x.id === op.studentId);
      if (s) { s.finalGrade = op.grade; s.finalComment = op.comment || null; }
    }
    return data;
  },

  /* ---- inicio ---- */
  overview(ops, data) {
    for (const op of ops) {
      if (data.role === 'student' && (op.k === 'submit' || op.k === 'draft') && op.seg === 'assignments') {
        if (op.k === 'submit') data.todo = data.todo.filter(t => t.id !== op.tid);
        else data.todo.forEach(t => { if (t.id === op.tid && t.status !== 'returned') t.status = 'draft'; });
      } else if (data.role === 'teacher' && (op.k === 'return' || (op.k === 'grade' && op.status === 'graded'))) {
        const before = data.pending.length;
        data.pending = data.pending.filter(p => p.id !== op.sid);
        if (data.pending.length < before) data.totals.pending = Math.max(0, data.totals.pending - 1);
      }
    }
    return data;
  }
};

/* =====================================================================
 * OFFLINE · descarga automática + utilidades de interfaz
 * ===================================================================== */
const Offline = {
  running: false,
  lastRun: 0,
  timer: null,
  stale: null,          // fecha (ms) de la copia más antigua usada en la pantalla actual

  statusKey: () => (Auth.user ? `aulasink.offline.${Auth.user.id}` : null),
  status() {
    const key = Offline.statusKey();
    if (!key) return null;
    try { return JSON.parse(store.get(key) || 'null'); } catch { return null; }
  },

  /** Programa una descarga (con pausa para agrupar varios cambios seguidos). */
  syncSoon(urgent = false) {
    clearTimeout(Offline.timer);
    Offline.timer = setTimeout(() => Offline.prefetch(), urgent ? 1500 : 6000);
  },

  /** Cuándo se descargó cada cosa, para avisar “estás viendo la copia guardada”. */
  noteStale(at) { Offline.stale = Offline.stale === null ? at : Math.min(Offline.stale, at); },

  noteNode() {
    const when = new Date(Offline.stale).toLocaleString('es', { dateStyle: 'medium', timeStyle: 'short' });
    return el('p', { class: 'offline-note', role: 'status' },
      `📴 Estás viendo la copia guardada en este dispositivo (actualizada: ${when}). Se actualiza sola al volver la conexión.`);
  },

  /** Ids de fotos dentro de las respuestas de una entrega: se piden una vez para que queden en caché. */
  warmFiles(data) {
    const answers = (data && data.item && data.item.submission && data.item.submission.answers) ||
                    (data && data.submission && data.submission.answers);
    if (!answers) return;
    for (const a of Object.values(answers)) {
      for (const id of (a && Array.isArray(a.files) ? a.files : [])) {
        if (!Photos.isLocal(id)) fetch(Api.fileUrl(id), { credentials: 'include' }).catch(() => {});
      }
    }
  },

  /**
   * Descarga todo lo del usuario (cursos, temario, tareas, integrantes, notas,
   * entregas…) a la copia local. Estudiante y profesor usan el mismo recorrido.
   */
  async prefetch({ manual = false } = {}) {
    if (Offline.running) return;
    if (!Auth.user || Auth.offline || !Net.online) {
      if (manual) toast('Conéctate a Internet para descargar tus datos.', 'warn');
      return;
    }
    if (!manual && Date.now() - Offline.lastRun < 20000) return;
    Offline.running = true;
    Offline.lastRun = Date.now();

    const stats = { courses: 0, items: 0, requests: 0, failed: 0 };
    const BUDGET = 700;                                   // tope de peticiones por descarga
    const sids = [];

    const grab = async (path, countAs) => {
      if (stats.requests >= BUDGET) return null;
      stats.requests++;
      try {
        const data = await Api.request('GET', path);
        await Mirror.set(path, data);
        Offline.warmFiles(data);
        if (countAs === 'item') stats.items++;
        return data;
      } catch (err) {
        if (err.offline || err.status === 401) throw err; // se cortó la señal: se termina aquí
        stats.failed++;
        return null;
      }
    };
    const pool = async (tasks, size = 4) => {
      let next = 0;
      await Promise.all(Array.from({ length: Math.min(size, tasks.length) }, async () => {
        while (next < tasks.length) await tasks[next++]();
      }));
    };

    try {
      await grab('/me/overview');
      const list = await grab('/courses');
      const courses = (list && list.courses) || [];
      stats.courses = courses.length;

      for (const c of courses) {
        const base = `/courses/${c.id}`;
        const detail = await grab(base);
        const teacher = Boolean(detail && detail.role === 'teacher');
        const [lessons, tasks] = await Promise.all([grab(`${base}/lessons`), grab(`${base}/assignments`)]);

        const jobs = [() => grab(`${base}/members`), () => (teacher ? grab(`${base}/gradebook`) : grab(`${base}/me`))];
        for (const [seg, res] of [['lessons', lessons], ['assignments', tasks]]) {
          for (const item of (res && res.items) || []) {
            jobs.push(() => grab(`${base}/${seg}/${item.id}`, 'item'));
            if (teacher) {
              jobs.push(async () => {
                const subs = await grab(`${base}/${seg}/${item.id}/submissions`);
                for (const r of (subs && subs.rows) || []) {
                  if (r.submission && r.submission.id && r.submission.status !== 'draft') sids.push(r.submission.id);
                }
              });
            }
          }
        }
        await pool(jobs);
      }
      await pool(sids.map(sid => () => grab(`/submissions/${sid}`)));

      const key = Offline.statusKey();
      if (key) store.set(key, JSON.stringify({ at: new Date().toISOString(), courses: stats.courses, items: stats.items, failed: stats.failed }));
      Photos.prune().catch(() => {});
      if (manual) toast(`✅ Listo: ${stats.courses} curso(s) y ${stats.items} actividad(es) disponibles sin conexión.`, 'ok');
    } catch (err) {
      if (manual) toast('Se cortó la conexión durante la descarga. Lo ya descargado quedó guardado.', 'warn');
    } finally {
      Offline.running = false;
      if (typeof refreshStatusCard === 'function') refreshStatusCard();
    }
  },

  /** Borra la copia local de la cuenta (al cerrar sesión). Conserva lo pendiente de enviar. */
  async wipe() {
    if (!Auth.user) return;
    if (Queue.count() > 0) return;                        // hay trabajo sin enviar: no se pierde nada
    const key = Offline.statusKey();
    if (key) store.set(key, '');
    await Mirror.wipe();
    try { if (window.caches) await caches.delete('aulasink-files'); } catch { /* sin Cache Storage */ }
  },

  /* ---- operaciones del profesor con soporte sin conexión ---- */
  saveItem(cid, seg, payload, { isNew = false, label } = {}) {
    const type = seg === 'lessons' ? 'lesson' : 'assignment';
    const key = `edit:${type}:${payload.id}`;
    // Si la creación sigue en cola, cualquier cambio posterior debe seguir siendo “crear”
    const creating = isNew || Queue.list().some(i => i.key === key && i.op && i.op.isNew);
    return Api.mutate(creating ? 'POST' : 'PUT', creating ? `/courses/${cid}/${seg}` : `/courses/${cid}/${seg}/${payload.id}`, payload,
      { label, key, op: { k: 'save', cid, seg, id: payload.id, isNew: creating, payload } });
  },

  removeItem(cid, seg, id, label) {
    const type = seg === 'lessons' ? 'lesson' : 'assignment';
    return Api.mutate('DELETE', `/courses/${cid}/${seg}/${id}`, undefined,
      { label, key: `delete:${type}:${id}`, ok404: true, supersede: [`edit:${type}:${id}`], op: { k: 'delete', cid, seg, id } });
  },

  reorder(cid, ids) {
    return Api.mutate('PUT', `/courses/${cid}/lessons/order`, { ids },
      { label: 'Orden del temario', key: `order:${cid}`, op: { k: 'order', cid, ids } });
  },

  init() {
    // Al volver a la app después de un rato, se refresca la copia
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && Date.now() - Offline.lastRun > 10 * 60000) Offline.syncSoon();
    });
    window.addEventListener('online', () => Offline.syncSoon(true));
    // Cada 15 minutos mientras la app esté abierta y con señal
    setInterval(() => { if (!document.hidden) Offline.syncSoon(); }, 15 * 60000);
  }
};
