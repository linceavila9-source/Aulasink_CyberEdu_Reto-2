/* =====================================================================
 * AulaSink · app.js
 * ---------------------------------------------------------------------
 * Plataforma educativa OFFLINE-FIRST (JavaScript vainilla, sin librerías).
 *
 * Secciones:
 *   0. Configuración
 *   1. Utilidades (helpers de DOM, toasts, ids)
 *   2. Contenido (lecciones y cuestionarios incluidos en la app)
 *   3. Perfil del estudiante (localStorage)
 *   4. DB  → almacenamiento local con IndexedDB (progreso + cola de envío)
 *   5. Net → indicador de estado de red
 *   6. Sync → sincronización automática al volver la conexión
 *   7. Vistas y router (dashboard, lecciones, cuestionario, sincronización)
 *   8. PWA → registro del Service Worker, actualizaciones e instalación
 *   9. Arranque
 *
 * Flujo offline-first:
 *   El estudiante responde → se guarda SIEMPRE en IndexedDB (progreso + una
 *   entrada en la cola "outbox") → si hay red, Sync.flush() la envía; si no,
 *   queda en la cola hasta que el evento "online" dispare el envío.
 * ===================================================================== */
'use strict';

/* =====================================================================
 * 0. CONFIGURACIÓN
 * ===================================================================== */
const CONFIG = {
  // ── Conexión con el backend (server.js: Node + Express + MySQL) ──────────
  // Si el frontend lo sirve el MISMO servidor Express (carpeta /public), usa
  // rutas relativas, como abajo: no hace falta CORS.
  // Si el frontend vive en otro dominio (GitHub Pages / Vercel), pon la URL
  // completa, p. ej. 'https://api.tudominio.com/api/sync', y añade ese dominio
  // en CORS_ORIGIN del archivo .env del servidor.
  // Con SYNC_ENDPOINT: null la app vuelve al MODO DEMO (envío simulado).
  API_BASE: '/api',               // API de cuentas, cursos, tareas… (api.js)
  SYNC_ENDPOINT: '/api/sync',     // POST: sincroniza la cola de IndexedDB con MySQL
  TUTOR_ENDPOINT: '/api/tutor',   // POST: tutor con IA (GroqCloud, vía el servidor)

  SYNC_TIMEOUT_MS: 10000,   // tiempo máximo de espera del servidor
  RETRY_DELAY_MS: 30000,    // reintento automático tras un fallo de envío
  PASS_SCORE: 60,           // % mínimo para marcar una lección como completada
  BG_SYNC_TAG: 'aulasink-sync' // etiqueta de Background Sync (debe coincidir con sw.js)
};

/* =====================================================================
 * 1. UTILIDADES
 * ===================================================================== */
const $ = (sel, root = document) => root.querySelector(sel);

/**
 * Mini "hyperscript": crea elementos DOM de forma segura.
 * Los textos se insertan como nodos de texto (nunca como HTML), lo que evita
 * inyección de código (XSS) con datos como el nombre del estudiante.
 *   el('button', { class: 'btn', onclick: fn }, 'Texto', otroNodo)
 */
function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key.startsWith('on') && typeof value === 'function') node.addEventListener(key.slice(2).toLowerCase(), value);
    else node.setAttribute(key, value === true ? '' : value);
  }
  for (const child of children.flat()) {
    if (child === null || child === undefined || child === false) continue;
    node.append(child.nodeType ? child : document.createTextNode(String(child)));
  }
  return node;
}

/** Identificador único (los ids permiten que el servidor ignore duplicados). */
function uid() {
  return (crypto.randomUUID && crypto.randomUUID()) ||
    'id-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
}

/** localStorage "a prueba de fallos" (puede estar bloqueado en modo privado). */
const store = {
  get(key) { try { return localStorage.getItem(key); } catch { return null; } },
  set(key, value) { try { localStorage.setItem(key, value); } catch { /* sin almacenamiento */ } }
};

function formatDate(iso) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('es', { dateStyle: 'short', timeStyle: 'short' });
}

/** Notificación flotante. type: 'ok' | 'warn' | undefined */
function toast(message, type) {
  const node = el('div', { class: 'toast' + (type ? ' toast--' + type : '') }, message);
  $('#toasts').append(node);
  setTimeout(() => node.remove(), 4500);
}

/** Barra de progreso accesible. */
function bar(pct, label = 'Progreso') {
  return el('div', {
    class: 'progress', role: 'progressbar',
    'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': pct, 'aria-label': label
  }, el('div', { class: 'progress__fill', style: `width:${pct}%` }));
}

/* =====================================================================
 * 2. CONTENIDO
 * Las lecciones viven dentro de la app para que estén disponibles offline.
 * En un proyecto real puedes cargarlas desde un JSON (fetch a /api/lessons)
 * y guardarlas en IndexedDB o en la Cache Storage para actualizarlas.
 * ===================================================================== */
const LESSONS = [
  {
    id: 'mate-01', iconImg: 'img/icon-2.png', cardBg: 'img/card-bg-2.png', subject: 'Matemáticas', icon: '➗', minutes: 5,
    title: 'Fracciones: partes de un todo',
    content: [
      'Una fracción representa una o varias partes de un todo que se ha dividido en partes iguales.',
      'El número de abajo (denominador) indica en cuántas partes iguales se divide el todo. El de arriba (numerador) indica cuántas de esas partes tomamos.',
      'Ejemplo: si una pizza se corta en 8 porciones iguales y comes 3, comiste 3/8 de la pizza.',
      'Dos fracciones son equivalentes cuando representan la misma cantidad: 1/2 = 2/4 = 4/8.'
    ],
    quiz: [
      { q: '¿Qué indica el denominador en la fracción 3/8?',
        options: ['Cuántas partes se toman', 'En cuántas partes iguales se divide el todo', 'El resultado de dividir', 'El tamaño de cada parte en centímetros'],
        answer: 1, explain: 'El denominador (8) dice en cuántas partes iguales se dividió el todo.' },
      { q: 'Si comes 2 de 5 porciones iguales, ¿qué fracción comiste?',
        options: ['5/2', '2/5', '2/7', '7/2'],
        answer: 1, explain: 'Se escribe primero lo que tomas (2) y abajo el total de partes (5): 2/5.' },
      { q: '¿Cuál de estas fracciones es equivalente a 1/2?',
        options: ['2/3', '3/5', '4/8', '1/4'],
        answer: 2, explain: '4/8 se simplifica dividiendo arriba y abajo entre 4, y da 1/2.' }
    ]
  },
  {
    id: 'cien-01', iconImg: 'img/icon-3.png', cardBg: 'img/card-bg-3.png', subject: 'Ciencias', icon: '💧', minutes: 5,
    title: 'El ciclo del agua',
    content: [
      'El agua de la Tierra se mueve constantemente entre los océanos, el aire y la tierra. A ese recorrido lo llamamos ciclo del agua.',
      'Evaporación: el calor del Sol convierte el agua líquida en vapor, que sube a la atmósfera.',
      'Condensación: al subir, el vapor se enfría y forma diminutas gotas que producen las nubes.',
      'Precipitación: cuando las gotas pesan demasiado, caen como lluvia, granizo o nieve. Luego el agua corre por los ríos o se filtra en el suelo y el ciclo vuelve a empezar.'
    ],
    quiz: [
      { q: '¿Qué fuente de energía impulsa la evaporación del agua?',
        options: ['La Luna', 'El viento', 'El Sol', 'Los volcanes'],
        answer: 2, explain: 'El calor del Sol evapora el agua de mares, ríos y lagos.' },
      { q: '¿Cómo se llama el proceso en el que el vapor se enfría y forma las nubes?',
        options: ['Precipitación', 'Condensación', 'Evaporación', 'Filtración'],
        answer: 1, explain: 'Condensación: el vapor pasa a gotas de agua líquida.' },
      { q: 'La lluvia, el granizo y la nieve son formas de…',
        options: ['Evaporación', 'Condensación', 'Precipitación', 'Sublimación'],
        answer: 2, explain: 'Precipitación es toda agua que cae de las nubes hacia la superficie.' }
    ]
  },
  {
    id: 'leng-01', iconImg: 'img/icon-4.png', cardBg: 'img/card-bg-4.png', subject: 'Lenguaje', icon: '✍️', minutes: 4,
    title: 'La oración: sujeto y predicado',
    content: [
      'Una oración es un conjunto de palabras con sentido completo que comunica una idea.',
      'Tiene dos partes principales: el sujeto (quién realiza la acción o de quién se habla) y el predicado (lo que se dice del sujeto, e incluye el verbo).',
      'Ejemplo: «Los estudiantes leen un cuento». Sujeto: «Los estudiantes». Predicado: «leen un cuento».'
    ],
    quiz: [
      { q: 'En «La maestra explica la lección», ¿cuál es el sujeto?',
        options: ['explica la lección', 'La maestra', 'la lección', 'explica'],
        answer: 1, explain: 'El sujeto es quien realiza la acción: «La maestra».' },
      { q: '¿Qué tipo de palabra es el núcleo del predicado?',
        options: ['El sustantivo', 'El artículo', 'El verbo', 'El adjetivo'],
        answer: 2, explain: 'El verbo es el núcleo del predicado: expresa la acción.' },
      { q: 'Una oración debe tener…',
        options: ['Solo una palabra', 'Sentido completo', 'Más de diez palabras', 'Signos de exclamación'],
        answer: 1, explain: 'Lo esencial es que exprese una idea con sentido completo.' }
    ]
  },
  {
    id: 'tec-01', iconImg: 'img/icon-5.png', cardBg: 'img/card-bg-5.png', subject: 'Tecnología', icon: '📡', minutes: 4,
    title: 'Aprender sin conexión: ¿cómo funciona?',
    content: [
      'Una aplicación «offline-first» guarda su contenido en tu dispositivo para funcionar aunque no haya Internet.',
      'Un Service Worker guarda los archivos de la app en una memoria llamada caché, y una base de datos local (IndexedDB) guarda tus respuestas y tu progreso.',
      'Cuando vuelve la conexión, la app envía automáticamente lo que quedó pendiente. A eso se le llama sincronización.'
    ],
    quiz: [
      { q: '¿Qué tecnología del navegador guarda tus respuestas en el dispositivo?',
        options: ['IndexedDB', 'Un correo electrónico', 'Una impresora', 'El router'],
        answer: 0, explain: 'IndexedDB es una base de datos dentro del navegador.' },
      { q: '¿Qué ocurre cuando la app recupera la conexión?',
        options: ['Se borra tu progreso', 'Envía lo que estaba pendiente', 'Deja de funcionar', 'No pasa nada'],
        answer: 1, explain: 'La app sincroniza: envía al servidor las respuestas guardadas.' },
      { q: '¿Qué significa «offline-first»?',
        options: ['Funciona primero sin depender de Internet', 'Solo funciona con Internet', 'Es un tipo de juego', 'Es un navegador'],
        answer: 0, explain: 'La app está pensada para funcionar sin red, y la conexión es un extra.' }
    ]
  }
];

// Asigna un id estable a cada pregunta: "mate-01-q1", "mate-01-q2"…
LESSONS.forEach(l => l.quiz.forEach((q, i) => { q.id = `${l.id}-q${i + 1}`; }));

const getLesson = id => LESSONS.find(l => l.id === id);

/* =====================================================================
 * 3. PERFIL DEL ESTUDIANTE
 * Nombre e id de la cuenta que inició sesión. El servidor identifica al
 * estudiante por su sesión al sincronizar.
 * ===================================================================== */
const Profile = {
  // v2: la identidad viene de la cuenta (api.js → Auth), ya no se inventa en el navegador
  get id() { return Auth.user ? Auth.user.id : ''; },
  get name() { return Auth.user ? Auth.user.name : ''; }
};

/* =====================================================================
 * 4. DB · ALMACENAMIENTO LOCAL (IndexedDB)
 * ---------------------------------------------------------------------
 * Base "aulasink-db" con dos almacenes:
 *   - progress : un registro por lección (mejor nota, intentos, completada)
 *   - outbox   : COLA de envíos pendientes al servidor (una por intento)
 * Guardar progreso + cola se hace en UNA transacción: o se guardan ambos
 * o ninguno, así nunca se pierde un envío pendiente.
 * ===================================================================== */
const DB = (() => {
  const BASE_NAME = 'aulasink-db';
  const VERSION = 1;
  let NAME = BASE_NAME;      // v2: una base local POR CUENTA, para que dos personas en el mismo dispositivo no mezclen progreso
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(NAME, VERSION);
      // Se ejecuta al crear la BD o al subir VERSION (migraciones)
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('progress')) {
          db.createObjectStore('progress', { keyPath: 'lessonId' });
        }
        if (!db.objectStoreNames.contains('outbox')) {
          db.createObjectStore('outbox', { keyPath: 'id' }).createIndex('createdAt', 'createdAt');
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => { dbPromise = null; reject(req.error); };
    });
    return dbPromise;
  }

  /** Ejecuta una operación en un almacén y resuelve cuando la transacción termina. */
  async function run(storeName, mode, fn) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeName, mode);
      const request = fn(tx.objectStore(storeName));
      let result;
      if (request) request.onsuccess = () => { result = request.result; };
      tx.oncomplete = () => resolve(result);
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
  }

  return {
    /** Cambia a la base local de esta cuenta (llamar al iniciar sesión / cambiar de usuario). */
    use(userId) {
      NAME = userId ? `${BASE_NAME}-${userId}` : BASE_NAME;
      dbPromise = null;
      Mirror.use(userId);        // v3: copia local de cursos, tareas y entregas (offline.js)
    },

    getProgress: lessonId => run('progress', 'readonly', s => s.get(lessonId)),
    getAllProgress: () => run('progress', 'readonly', s => s.getAll()),

    /** Guarda progreso + entrada de la cola de envío en una sola transacción. */
    async saveAttempt(progress, outboxItem) {
      const db = await open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(['progress', 'outbox'], 'readwrite');
        tx.objectStore('progress').put(progress);
        tx.objectStore('outbox').put(outboxItem);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error);
      });
    },

    getOutbox: () => run('outbox', 'readonly', s => s.getAll()),
    countOutbox: () => run('outbox', 'readonly', s => s.count()),

    /** Elimina de la cola los registros que el servidor ya confirmó. */
    async removeFromOutbox(ids) {
      const db = await open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction('outbox', 'readwrite');
        ids.forEach(id => tx.objectStore('outbox').delete(id));
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    },

    /** Anota un intento fallido (sirve para depurar y mostrar en la UI). */
    async markFailed(ids, message) {
      const db = await open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction('outbox', 'readwrite');
        const os = tx.objectStore('outbox');
        ids.forEach(id => {
          const get = os.get(id);
          get.onsuccess = () => {
            if (get.result) os.put({ ...get.result, tries: (get.result.tries || 0) + 1, lastError: message });
          };
        });
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    },

    /** Borra todo (solo para la opción de reinicio de la demo). */
    async clearAll() {
      const db = await open();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(['progress', 'outbox'], 'readwrite');
        tx.objectStore('progress').clear();
        tx.objectStore('outbox').clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    }
  };
})();

/* =====================================================================
 * 5. Net · ESTADO DE RED (indicador Online / Offline)
 * navigator.onLine solo indica si hay una interfaz de red activa, no si
 * hay Internet real. Por eso Sync trata además los errores de fetch.
 * ===================================================================== */
const Net = {
  // v2: "en línea" = el navegador tiene red Y el servidor responde (ver Link en api.js)
  get online() { return navigator.onLine && Link.state !== 'offline'; },

  paint() {
    const state = Link.state === 'good' ? 'online' : Link.state;   // online | unstable | offline
    $('#net-status').dataset.state = state;
    $('#net-label').textContent = { online: 'En línea', unstable: 'Señal inestable', offline: 'Sin conexión' }[state];
  },

  init() {
    Net.paint();
    window.addEventListener('online', () => {
      Net.paint();
      toast('Conexión restablecida', 'ok');
      Auth.revalidate().then(refreshView);
    });
    window.addEventListener('offline', () => {
      Net.paint();
      toast('Sin conexión. Puedes seguir estudiando: tu progreso se guarda en este dispositivo.', 'warn');
      refreshView();
    });
  }
};

/* =====================================================================
 * 6. Sync · SINCRONIZACIÓN
 * ---------------------------------------------------------------------
 * - Escucha window "online" y envía la cola en cuanto vuelve la red.
 * - También intenta enviar al abrir la app y tras cada cuestionario.
 * - Si el navegador soporta Background Sync, registra una tarea para que
 *   el Service Worker avise a la app aunque la conexión vuelva más tarde.
 * - El servidor debe usar el campo "id" de cada registro para ignorar
 *   duplicados (así un reintento nunca cuenta dos veces la misma respuesta).
 * ===================================================================== */
const Sync = {
  syncing: false,
  retryTimer: null,

  init() {
    // ★ Requisito: al detectar conexión, enviar automáticamente lo encolado
    window.addEventListener('online', () => Sync.flush());

    // Mensaje del Service Worker (evento "sync" de Background Sync)
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.addEventListener('message', event => {
        if (event.data && event.data.type === 'SYNC_REQUESTED') Sync.flush();
      });
    }
  },

  /** Pide al navegador un Background Sync (solo Chromium; si no existe, se ignora). */
  async requestBackgroundSync() {
    try {
      const reg = await navigator.serviceWorker.ready;
      if ('sync' in reg) await reg.sync.register(CONFIG.BG_SYNC_TAG);
    } catch { /* no soportado: el evento "online" es el plan principal */ }
  },

  /**
   * Envía un lote al servidor (POST /api/sync).
   * Devuelve { accepted: [ids], rejected: [{id, reason}] }:
   *   accepted → el servidor los guardó (o ya los tenía): se borran de la cola.
   *   rejected → datos inválidos que nunca serán aceptados: también se descartan.
   * Los ids que no vengan en ninguna de las dos listas se quedan en la cola
   * para reintentarlo (error temporal del servidor).
   */
  async send(items) {
    // MODO DEMO: sin servidor configurado, simulamos un envío exitoso.
    if (!CONFIG.SYNC_ENDPOINT) {
      await new Promise(resolve => setTimeout(resolve, 700));
      console.info('[AulaSink][Sync · SIMULADO] Registros enviados:', items);
      return { accepted: items.map(i => i.id), rejected: [] };
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), CONFIG.SYNC_TIMEOUT_MS);
    try {
      const response = await fetch(CONFIG.SYNC_ENDPOINT, {
        method: 'POST',
        credentials: 'include',                       // cookie de sesión: el servidor sabe quién eres
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
        signal: controller.signal
      });
      if (response.status === 401) { Auth.expired(); throw new Error('Sesión terminada'); }
      if (!response.ok) throw new Error('HTTP ' + response.status);
      // Con un servidor real NUNCA se asume que se guardó: solo se borra de la
      // cola lo que el servidor confirma en "accepted". Si la respuesta no es el
      // JSON esperado (p. ej. la página de login de un WiFi público), es un error.
      const data = await response.json();
      if (!Array.isArray(data.accepted)) throw new Error('Respuesta inesperada del servidor');
      return { accepted: data.accepted, rejected: Array.isArray(data.rejected) ? data.rejected : [] };
    } finally {
      clearTimeout(timer);
    }
  },

  /** Vacía la cola de envío si hay red. manual=true muestra mensajes aunque no pase nada. */
  async flush({ manual = false } = {}) {
    if (Sync.syncing) return;
    if (!Auth.isStudent) return;                       // solo los estudiantes sincronizan cuestionarios

    if (!Net.online) {
      if (manual) toast('Sin conexión: se enviará automáticamente al reconectar.', 'warn');
      return;
    }

    let items;
    try { items = await DB.getOutbox(); } catch { return; }
    if (!items.length) {
      if (manual) toast('Todo está sincronizado ✅', 'ok');
      return;
    }

    Sync.syncing = true;
    refreshView();
    try {
      const { accepted, rejected } = await Sync.send(items);

      // Se borran de la cola los confirmados y los rechazados por inválidos
      const done = [...accepted, ...rejected.map(r => r.id).filter(Boolean)];
      await DB.removeFromOutbox(done);
      store.set('aulasink.lastSync', new Date().toISOString());

      if (accepted.length) toast(`✅ ${accepted.length} registro(s) sincronizado(s)`, 'ok');
      if (rejected.length) {
        console.warn('[AulaSink] El servidor descartó registros inválidos:', rejected);
        toast(`⚠️ El servidor descartó ${rejected.length} registro(s) inválido(s)`, 'warn');
      }
      // Quedaron registros sin confirmar (error temporal en el servidor): reintentar
      if (done.length < items.length) {
        clearTimeout(Sync.retryTimer);
        Sync.retryTimer = setTimeout(() => Sync.flush(), CONFIG.RETRY_DELAY_MS);
      }
    } catch (err) {
      console.warn('[AulaSink] Falló la sincronización:', err);
      await DB.markFailed(items.map(i => i.id), String(err && err.message || err)).catch(() => {});
      toast('No se pudo sincronizar. Reintentaremos en unos segundos.', 'warn');
      clearTimeout(Sync.retryTimer);
      Sync.retryTimer = setTimeout(() => Sync.flush(), CONFIG.RETRY_DELAY_MS);
    } finally {
      Sync.syncing = false;
      onOutboxChanged();
    }
  }
};

/* =====================================================================
 * 7. VISTAS Y ROUTER
 * Router por hash (#/dashboard, #/lessons, #/lesson/ID, #/quiz/ID, #/sync):
 * funciona en cualquier hosting estático sin configurar redirecciones.
 * ===================================================================== */
let quiz = null; // estado del cuestionario en curso (en memoria)

function parseHash() {
  const [, route = 'dashboard', param, p2, p3] = location.hash.replace(/^#/, '').split('/');
  return { route: route || 'dashboard', param, p2, p3 };
}

/** Estado de la lección para tarjetas del dashboard/listado. */
function lessonStatus(progress) {
  if (!progress) return el('span', { class: 'chip chip--warn' }, 'Sin empezar');
  if (progress.completed) return el('span', { class: 'chip chip--ok' }, `Completada · ${progress.bestScore}%`);
  return el('span', { class: 'chip chip--warn' }, `En curso · mejor ${progress.bestScore}%`);
}

function lessonCard(lesson, progress) {
  return el('a', {
      class: 'card lesson-card' + (lesson.cardBg ? ' lesson-card--bg' : ''),
      href: `#/lesson/${lesson.id}`,
      style: lesson.cardBg ? `background-image:url('${lesson.cardBg}')` : ''
    },
    el('div', { class: 'lesson-card__icon' + (lesson.iconImg ? ' lesson-card__icon--img' : ''), 'aria-hidden': 'true' },
      lesson.iconImg ? el('img', { src: lesson.iconImg, alt: '' }) : lesson.icon),
    el('div', { class: 'lesson-card__body' },
      el('span', { class: 'chip' }, lesson.subject),
      el('h3', {}, lesson.title),
      el('p', { class: 'muted' }, `${lesson.minutes} min · ${lesson.quiz.length} preguntas`),
      bar(progress ? progress.bestScore : 0, `Mejor nota en ${lesson.title}`),
      el('div', { style: 'margin-top:8px' }, lessonStatus(progress))
    )
  );
}

/* ---------- Tarjeta “Listo para usar sin conexión” ---------- */
async function offlineCard() {
  const appReady = !!(navigator.serviceWorker && navigator.serviceWorker.controller);
  const st = Offline.status();
  const have = await Mirror.count();
  const ready = appReady && have > 0 && st;
  const running = Offline.running;

  const title = running ? '⏳ Descargando tus cursos y tareas…'
    : ready ? '✅ Listo para usar sin conexión'
    : appReady ? '📥 Falta descargar tus cursos y tareas'
    : '⏳ Preparando el modo sin conexión…';
  const text = running ? 'No cierres la app: se guarda todo en tu dispositivo.'
    : ready ? `Tienes ${st.courses} curso(s) y ${st.items} actividad(es) guardados en este dispositivo (descargados ${formatDate(st.at)}). Puedes abrir AulaSink, ver tus tareas, responderlas y entregarlas sin Internet: se envían solas al volver la señal.`
    : appReady ? 'Conéctate a Internet y pulsa «Descargar ahora» para tener tus cursos y tareas sin conexión.'
    : 'Mantén la app abierta unos segundos con conexión para guardar todo el contenido.';

  return el('div', { class: 'card', id: 'offline-card' },
    el('h2', {}, title),
    el('p', { class: 'muted' }, text),
    el('div', { class: 'actions' },
      el('button', { class: 'btn btn--ghost btn--small', type: 'button', disabled: running || !Net.online,
        onclick: async () => { await Offline.prefetch({ manual: true }); refreshStatusCard(); } },
        running ? 'Descargando…' : '⬇️ Descargar ahora')));
}

/** Repinta solo la tarjeta de estado (al terminar una descarga automática). */
async function refreshStatusCard() {
  const old = document.getElementById('offline-card');
  if (old && Auth.user) old.replaceWith(await offlineCard());
}

/* ---------- Dashboard del estudiante ---------- */
async function viewDashboard() {
  if (Auth.isTeacher) return viewTeacherHome();       // panel docente (views-teacher.js)
  const [progressList, pending] = await Promise.all([DB.getAllProgress(), DB.countOutbox()]);
  const byId = new Map(progressList.map(p => [p.lessonId, p]));
  const done = LESSONS.filter(l => byId.get(l.id)?.completed).length;
  const avg = progressList.length
    ? Math.round(progressList.reduce((sum, p) => sum + p.bestScore, 0) / progressList.length) : 0;
  const overall = Math.round((done / LESSONS.length) * 100);
  const next = LESSONS.find(l => !byId.get(l.id)?.completed);
  const nodes = [
    el('h1', { class: 'view__title', tabindex: '-1' }, `¡Hola, ${Profile.name}! 👋`),
    el('p', { class: 'view__subtitle' }, 'Tu progreso se guarda en este dispositivo, con o sin Internet.')
  ];

  // Mis cursos y tareas pendientes (si no hay conexión se muestra la copia guardada en el dispositivo)
  const coursesNode = await studentHomeSection();
  if (coursesNode) nodes.push(coursesNode);

  // Estadísticas
  nodes.push(el('div', { class: 'grid grid--stats' },
    el('div', { class: 'card stat' }, el('div', { class: 'stat__value' }, `${done}/${LESSONS.length}`), el('div', { class: 'stat__label' }, 'Lecciones completadas')),
    el('div', { class: 'card stat' }, el('div', { class: 'stat__value' }, `${avg}%`), el('div', { class: 'stat__label' }, 'Promedio de notas')),
    el('div', { class: 'card stat' }, el('div', { class: 'stat__value' }, String(pending)), el('div', { class: 'stat__label' }, 'Por sincronizar'))
  ));

  // Progreso general + siguiente lección
  nodes.push(el('div', { class: 'card' },
    el('h2', {}, `Progreso general: ${overall}%`),
    bar(overall, 'Progreso general'),
    next
      ? el('div', { class: 'actions' }, el('a', { class: 'btn', href: `#/lesson/${next.id}` }, `Continuar: ${next.title}`))
      : el('p', { style: 'margin-top:12px' }, '🎉 ¡Completaste todas las lecciones!')
  ));

  // Disponibilidad offline
  nodes.push(await offlineCard());

  // Ayuda de instalación en iOS (Safari no dispara "beforeinstallprompt")
  if (PWA.isIOS && !PWA.isStandalone) {
    nodes.push(el('div', { class: 'card' },
      el('h2', {}, '📲 Instálala en tu iPhone / iPad'),
      el('p', { class: 'muted' }, 'En Safari toca el botón Compartir y elige «Añadir a pantalla de inicio».')
    ));
  }

  // Lecciones
  nodes.push(el('h2', {}, 'Lecciones de práctica'));
  nodes.push(el('div', { class: 'grid grid--lessons' }, LESSONS.map(l => lessonCard(l, byId.get(l.id)))));

  return el('section', { class: 'view' }, nodes);
}

/* ---------- Listado de lecciones ---------- */
async function viewLessons() {
  const byId = new Map((await DB.getAllProgress()).map(p => [p.lessonId, p]));
  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, 'Lecciones'),
    el('p', { class: 'view__subtitle' }, 'Todas disponibles sin conexión.'),
    el('div', { class: 'grid grid--lessons' }, LESSONS.map(l => lessonCard(l, byId.get(l.id))))
  );
}

/* ---------- Lectura de una lección ---------- */
async function viewLesson(id) {
  const lesson = getLesson(id);
  if (!lesson) return viewNotFound();
  const progress = await DB.getProgress(id);

  return el('section', { class: 'view' },
    el('a', { class: 'back-link', href: '#/lessons' }, '← Volver a lecciones'),
    el('span', { class: 'chip' }, `${lesson.icon} ${lesson.subject} · ${lesson.minutes} min`),
    el('h1', { class: 'view__title', tabindex: '-1', style: 'margin-top:8px' }, lesson.title),
    el('article', { class: 'card lesson-text' }, lesson.content.map(p => el('p', {}, p))),
    el('div', { class: 'card' },
      el('h2', {}, 'Cuestionario'),
      el('p', { class: 'muted' }, progress
        ? `Tu mejor nota: ${progress.bestScore}% · Intentos: ${progress.attempts}`
        : `${lesson.quiz.length} preguntas para comprobar lo aprendido.`),
      el('div', { class: 'actions' },
        el('a', { class: 'btn', href: `#/quiz/${lesson.id}`, onclick: () => { quiz = null; } }, progress ? 'Intentarlo de nuevo' : 'Comenzar cuestionario'),
        el('a', { class: 'btn btn--ghost', href: `#/tutor/${lesson.id}` }, '🤖 Preguntar al tutor')
      )
    )
  );
}

/* ---------- Cuestionario ---------- */
function viewQuiz(lessonId) {
  const lesson = getLesson(lessonId);
  if (!lesson) return viewNotFound();

  // Si es la primera vez (o se cambió de lección), reinicia el estado
  if (!quiz || quiz.lessonId !== lessonId) {
    quiz = { lessonId, index: 0, answers: [], locked: false, selected: null, result: null };
  }
  if (quiz.result) return viewQuizResult(lesson);

  const total = lesson.quiz.length;
  const question = lesson.quiz[quiz.index];
  const answered = quiz.locked;
  const wasCorrect = answered && quiz.selected === question.answer;

  const options = question.options.map((text, i) => {
    let cls = 'option';
    if (answered && i === question.answer) cls += ' is-correct';
    else if (answered && i === quiz.selected) cls += ' is-wrong';
    return el('button', { type: 'button', class: cls, disabled: answered, onclick: () => answerQuestion(lesson, i) },
      el('span', { class: 'option__letter', 'aria-hidden': 'true' }, 'ABCD'[i]),
      el('span', {}, text)
    );
  });

  return el('section', { class: 'view' },
    el('a', { class: 'back-link', href: `#/lesson/${lesson.id}` }, '← Salir del cuestionario'),
    el('h1', { class: 'view__title', tabindex: '-1' }, lesson.title),
    el('div', { class: 'card' },
      el('div', { class: 'quiz__meta' }, el('span', {}, `Pregunta ${quiz.index + 1} de ${total}`), el('span', {}, lesson.subject)),
      bar(Math.round((quiz.index / total) * 100), 'Avance del cuestionario'),
      el('h2', { class: 'quiz__question' }, question.q),
      el('div', { class: 'options' }, options),
      answered && el('div', { class: 'feedback ' + (wasCorrect ? 'is-ok' : 'is-bad'), role: 'status' },
        el('strong', {}, wasCorrect ? '¡Correcto! 🎉' : 'Casi… 🤔'),
        el('p', {}, question.explain)
      ),
      answered && el('div', { class: 'actions' },
        el('button', { id: 'btn-next', class: 'btn', type: 'button', onclick: () => nextQuestion(lesson) },
          quiz.index + 1 < total ? 'Siguiente' : 'Ver resultado')
      )
    )
  );
}

function answerQuestion(lesson, selected) {
  if (quiz.locked) return;
  const question = lesson.quiz[quiz.index];
  quiz.selected = selected;
  quiz.locked = true;
  quiz.answers.push({ questionId: question.id, selected, correct: selected === question.answer });
  render();
}

function nextQuestion(lesson) {
  if (quiz.index + 1 < lesson.quiz.length) {
    quiz.index += 1;
    quiz.locked = false;
    quiz.selected = null;
    render();
  } else {
    finishQuiz(lesson);
  }
}

/** Calcula la nota y GUARDA localmente (progreso + cola de envío). */
async function finishQuiz(lesson) {
  const total = lesson.quiz.length;
  const correct = quiz.answers.filter(a => a.correct).length;
  const score = Math.round((correct / total) * 100);
  const now = new Date().toISOString();

  try {
    const previous = await DB.getProgress(lesson.id);
    const progress = {
      lessonId: lesson.id,
      lastScore: score,
      bestScore: Math.max(previous ? previous.bestScore : 0, score),
      attempts: (previous ? previous.attempts : 0) + 1,
      completed: Boolean(previous && previous.completed) || score >= CONFIG.PASS_SCORE,
      updatedAt: now
    };
    // Registro que viajará al servidor cuando haya conexión
    const outboxItem = {
      id: uid(),                       // idempotencia: el servidor puede descartar duplicados
      type: 'quiz_attempt',
      studentId: Profile.id,
      lessonId: lesson.id,
      score, correct, total,
      answers: quiz.answers,
      createdAt: now,
      tries: 0
    };
    await DB.saveAttempt(progress, outboxItem);
  } catch (err) {
    console.error(err);
    toast('No se pudo guardar en este dispositivo.', 'warn');
    return;
  }

  quiz.result = { score, correct, total, passed: score >= CONFIG.PASS_SCORE };
  await render();            // pinta la pantalla de resultado (refreshView no repinta el cuestionario)
  await updateBadge();       // actualiza el contador de pendientes
  Sync.requestBackgroundSync();  // plan B en Chromium
  Sync.flush();                  // si hay red, se envía ya mismo
}

function viewQuizResult(lesson) {
  const r = quiz.result;
  const review = lesson.quiz.map((q, i) => {
    const a = quiz.answers[i];
    return el('li', { class: a.correct ? 'is-ok' : 'is-bad' },
      el('strong', {}, `${i + 1}. ${q.q}`),
      el('small', {}, `Tu respuesta: ${q.options[a.selected]} ${a.correct ? '✓' : '✗'}`),
      !a.correct && el('small', {}, `Correcta: ${q.options[q.answer]}`)
    );
  });

  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, r.passed ? '¡Buen trabajo! 🎉' : '¡Sigue practicando! 💪'),
    el('div', { class: 'card result' },
      el('div', { class: 'score-ring ' + (r.passed ? 'is-pass' : 'is-fail') }, `${r.score}%`),
      el('p', {}, `${r.correct} de ${r.total} respuestas correctas en «${lesson.title}».`),
      el('p', { class: 'sync-note' }, Net.online
        ? '💾 Guardado en tu dispositivo y enviándose al servidor…'
        : '💾 Guardado en tu dispositivo. Se enviará solo cuando vuelva la conexión.'),
      el('div', { class: 'actions' },
        el('a', { class: 'btn', href: `#/quiz/${lesson.id}`, onclick: () => { quiz = null; } }, 'Reintentar'),
        el('a', { class: 'btn btn--ghost', href: '#/lessons' }, 'Más lecciones')
      )
    ),
    el('div', { class: 'card' }, el('h2', {}, 'Revisión'), el('ul', { class: 'review' }, review))
  );
}

/* ---------- Tutor con IA (requiere conexión) ----------
 * El navegador NUNCA habla con Groq: envía la duda a POST /api/tutor y el
 * servidor (que guarda la API Key) consulta a la IA. El tutor está pensado
 * para guiar con preguntas y pistas, sin dar la respuesta de los ejercicios. */
let tutorChat = { lessonId: null, messages: [] }; // messages: { role: 'user' | 'assistant', content, local? }

function chatBubble(role, text, extraClass = '') {
  return el('div', { class: `bubble bubble--${role} ${extraClass}`.trim() }, text);
}

async function viewTutor(lessonId, courseId) {
  const lesson = lessonId ? getLesson(lessonId) : null;
  const courseLesson = lessonId && !lesson && courseId;      // lección creada por un profesor
  const key = lesson ? lesson.id : (courseLesson ? lessonId : null);
  if (tutorChat.lessonId !== key) tutorChat = { lessonId: key, messages: [] }; // conversación nueva por lección

  // Contenido para el tutor SIN conexión: lo que ya está guardado en el dispositivo
  let source = null;
  if (lesson) source = { id: lesson.id, title: lesson.title, paragraphs: lesson.content, questions: lesson.quiz };
  else if (courseLesson) {
    try {
      const { item } = await Api.get(`/courses/${courseId}/lessons/${lessonId}`);   // con copia local: funciona sin Internet
      source = { title: item.title, paragraphs: item.paragraphs || [], questions: item.questions || [] };
    } catch { /* sin contenido: solo preguntas generales */ }
  }
  const local = { source, list: TutorLocal.entries(source) };

  const log = el('div', { class: 'chat__log', role: 'log', 'aria-live': 'polite' });
  log.append(chatBubble('assistant', lesson || source
    ? `¡Hola! Soy tu tutor. Estás en «${(lesson || source).title}». Toca una de las preguntas de abajo para una respuesta al instante (funciona sin Internet), o escríbeme tu duda. 🙂`
    : '¡Hola! Soy tu tutor. Toca una pregunta de abajo (funciona sin Internet) o cuéntame en qué tema necesitas ayuda. 🙂'));
  tutorChat.messages.forEach(m => log.append(chatBubble(m.role, m.content, m.local ? 'is-local' : '')));
  requestAnimationFrame(() => { log.scrollTop = log.scrollHeight; });

  /* Preguntas predeterminadas: tocar y responder, sin servidor */
  const chips = el('div', { class: 'chips tutor-chips', role: 'group', 'aria-label': 'Preguntas frecuentes' });
  let showAll = false;
  const VISIBLE = 6;
  const paintChips = () => {
    const shown = showAll ? local.list : local.list.slice(0, VISIBLE);
    chips.replaceChildren(
      ...shown.map(e => el('button', { class: 'chip chip--button', type: 'button', onclick: () => tutorLocalReply(chat(), log, e.q, e.a) }, e.q)),
      local.list.length > VISIBLE && el('button', { class: 'chip chip--button chip--more', type: 'button',
        onclick: () => { showAll = !showAll; paintChips(); } }, showAll ? 'Ver menos' : `Ver ${local.list.length - VISIBLE} más…`));
  };
  const chat = () => tutorChat;
  paintChips();

  const input = el('textarea', {
    rows: '2', maxlength: '1000', 'aria-label': 'Escribe tu duda',
    placeholder: 'O escribe tu duda… (Enter para enviar)'
  });
  const button = el('button', { class: 'btn', type: 'submit' }, 'Enviar');
  const form = el('form', {
    class: 'chat__form',
    onsubmit: event => { event.preventDefault(); askTutor(input, button, log, local); }
  }, input, button);
  // Enter envía; Shift+Enter hace salto de línea
  input.addEventListener('keydown', event => {
    if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); form.requestSubmit(); }
  });

  return el('section', { class: 'view' },
    lesson && el('a', { class: 'back-link', href: `#/lesson/${lesson.id}` }, '← Volver a la lección'),
    courseLesson && el('a', { class: 'back-link', href: `#/clesson/${courseId}/${lessonId}` }, '← Volver a la lección'),
    el('h1', { class: 'view__title', tabindex: '-1' }, '🤖 Tutor'),
    el('p', { class: 'view__subtitle' }, 'Te guía con pistas, sin darte las respuestas de los ejercicios. Las preguntas de abajo funcionan sin conexión; escribir tu propia duda a la IA necesita Internet.'),
    !Net.online && el('div', { class: 'card' }, '🟠 Estás sin conexión: usa las preguntas de abajo (o escribe una duda y buscaré la respuesta en tu lección). La IA volverá cuando tengas Internet.'),
    el('div', { class: 'card chat' }, log, el('p', { class: 'muted tutor-chips__label' }, '💬 Toca una pregunta:'), chips, form)
  );
}

/** Respuesta del tutor local (sin servidor): se muestra como un mensaje más de la conversación. */
function tutorLocalReply(chat, log, question, answer) {
  chat.messages.push({ role: 'user', content: question, local: true }, { role: 'assistant', content: answer, local: true });
  log.append(chatBubble('user', question), chatBubble('assistant', answer, 'is-local'));
  log.scrollTop = log.scrollHeight;
}

async function askTutor(input, button, log, local) {
  const text = input.value.trim();
  if (!text) return;
  const chat = tutorChat;                       // por si el estudiante cambia de lección mientras espera

  /** Sin conexión (o la IA no responde): se busca en lo que hay guardado en el dispositivo. */
  const answerLocally = () => {
    const found = TutorLocal.answerFree(text, local && local.source, (local && local.list) || []);
    if (found) {
      tutorLocalReply(chat, log, text, found.answer);
      input.value = '';
    } else {
      log.append(chatBubble('assistant', 'No tengo esa respuesta guardada para usarla sin conexión. 🙁 Prueba con una de las preguntas de abajo, o escríbeme otra vez cuando tengas Internet y la IA te ayudará.', 'is-error'));
      log.scrollTop = log.scrollHeight;
    }
  };

  if (!Net.online || !CONFIG.TUTOR_ENDPOINT) { answerLocally(); return; }

  const history = chat.messages.filter(m => !m.local).slice(-8);   // contexto para la IA (sin las respuestas locales)
  chat.messages.push({ role: 'user', content: text });
  log.append(chatBubble('user', text));
  input.value = '';

  const waiting = chatBubble('assistant', 'Pensando…', 'is-waiting');
  log.append(waiting);
  log.scrollTop = log.scrollHeight;
  input.disabled = true;
  button.disabled = true;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 35000);
  try {
    const response = await fetch(CONFIG.TUTOR_ENDPOINT, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: text, lessonId: chat.lessonId, history }),
      signal: controller.signal
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || `Error ${response.status}`);

    chat.messages.push({ role: 'assistant', content: data.reply });
    waiting.textContent = data.reply;
    waiting.classList.remove('is-waiting');
  } catch (err) {
    chat.messages.pop();                        // el mensaje no obtuvo respuesta: no queda en el historial
    // Cortó la señal o tardó demasiado: se intenta responder con lo guardado en el dispositivo
    const found = (err.name === 'AbortError' || err instanceof TypeError)
      ? TutorLocal.answerFree(text, local && local.source, (local && local.list) || []) : null;
    if (found) {
      const reply = '📴 Sin conexión con la IA, esto es lo que encontré guardado:\n\n' + found.answer;
      chat.messages.push({ role: 'user', content: text, local: true }, { role: 'assistant', content: reply, local: true });
      waiting.textContent = reply;
      waiting.classList.remove('is-waiting');
      waiting.classList.add('is-local');
    } else {
      waiting.textContent = '⚠️ ' + (err.name === 'AbortError'
        ? 'El tutor tardó demasiado. Inténtalo de nuevo.'
        : (err.message || 'No se pudo contactar al tutor.'));
      waiting.classList.remove('is-waiting');
      waiting.classList.add('is-error');
      input.value = text;                       // devuelve el texto para reintentar
    }
  } finally {
    clearTimeout(timer);
    input.disabled = false;
    button.disabled = false;
    input.focus();
    log.scrollTop = log.scrollHeight;
  }
}

/* ---------- Estado de sincronización ---------- */
async function viewSync() {
  const items = Auth.isStudent ? await DB.getOutbox() : [];
  const actions = Queue.list();
  const last = store.get('aulasink.lastSync');
  const pendingTotal = items.length + actions.length;

  const list = items.length
    ? el('ul', { class: 'queue' }, items.map(item => el('li', {},
        el('span', {}, `${getLesson(item.lessonId)?.title || item.lessonId} · ${item.score}%`),
        el('span', { class: 'muted' }, formatDate(item.createdAt) + (item.tries ? ` · ${item.tries} reintento(s)` : ''))
      )))
    : el('p', { class: 'muted' }, '✅ No hay nada pendiente: todo está sincronizado.');

  // Acciones hechas sin conexión (entregas, calificaciones, lecciones guardadas…)
  const actionList = actions.length
    ? el('ul', { class: 'queue' }, actions.map(a => el('li', {},
        el('span', {}, a.label || 'Acción pendiente'),
        el('span', { class: 'muted' }, formatDate(a.createdAt) + ' '),
        el('button', { class: 'btn btn--ghost btn--small', type: 'button', onclick: () => {
          if (confirm('¿Descartar esta acción? No se enviará.')) { Queue.discard(a.id); render(); }
        } }, 'Descartar'))))
    : el('p', { class: 'muted' }, '✅ No hay acciones pendientes.');

  const linkText = { good: '🟢 En línea', unstable: '🟡 Señal inestable', offline: '🟠 Sin conexión' }[Link.state];
  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, 'Sincronización'),
    el('p', { class: 'view__subtitle' }, Auth.isTeacher
      ? 'Lo que hagas sin conexión (calificar, guardar lecciones…) se guarda aquí y se envía solo al volver la señal.'
      : 'Las respuestas hechas sin conexión se envían solas al volver a tener red.'),
    el('div', { class: 'card' },
      el('dl', { class: 'kv' },
        el('dt', {}, 'Red'), el('dd', {}, linkText + (Link.latency && Link.state !== 'offline' ? ` · ${Link.latency} ms` : '')),
        el('dt', {}, 'Pendientes'), el('dd', {}, String(pendingTotal)),
        el('dt', {}, 'Última sincronización'), el('dd', {}, formatDate(last)),
        el('dt', {}, 'Servidor'), el('dd', {}, CONFIG.SYNC_ENDPOINT || 'Modo demostración')
      ),
      !CONFIG.SYNC_ENDPOINT && el('p', { class: 'muted' }, 'No hay servidor configurado: el envío se simula. Define CONFIG.SYNC_ENDPOINT en app.js para enviar datos reales.'),
      el('div', { class: 'actions' },
        el('button', { class: 'btn', type: 'button', disabled: Sync.syncing || Queue.flushing, onclick: async () => {
          await Promise.all([Sync.flush({ manual: true }), Queue.flush({ manual: false })]);
          render();
        } }, Sync.syncing ? 'Sincronizando…' : 'Sincronizar ahora')
      )
    ),
    await offlineCard(),
    el('div', { class: 'card' }, el('h2', {}, 'Acciones pendientes'), actionList),
    Auth.isStudent && el('div', { class: 'card' }, el('h2', {}, 'Cola de cuestionarios de práctica'), list),
    Auth.isStudent && el('div', { class: 'card' },
      el('h2', {}, 'Datos de demostración'),
      el('p', { class: 'muted' }, 'Borra el progreso y la cola de este dispositivo. Los registros pendientes se perderán.'),
      el('button', { class: 'btn btn--danger btn--small', type: 'button', onclick: resetData }, 'Borrar datos locales')
    )
  );
}

async function resetData() {
  if (!confirm('¿Borrar progreso y registros pendientes de este dispositivo?')) return;
  await DB.clearAll();
  store.set('aulasink.lastSync', '');
  quiz = null;
  toast('Datos locales borrados.');
  await onOutboxChanged();
}

function viewNotFound() {
  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, 'No encontrado'),
    el('p', {}, 'Esa página no existe.'),
    el('a', { class: 'btn', href: '#/dashboard' }, 'Ir al inicio'));
}

function viewError(err) {
  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, 'Algo salió mal'),
    el('p', { class: 'muted' }, 'No se pudo abrir el almacenamiento local del navegador (¿modo privado?).'),
    el('p', { class: 'muted' }, String(err && err.message || err)));
}

/* ---------- Render y navegación ---------- */
const PUBLIC_ROUTES = ['login', 'register'];
const STUDENT_ONLY = ['lessons', 'lesson', 'quiz', 'tutor', 'clesson', 'task'];
const TEACHER_ONLY = ['edit-lesson', 'edit-task', 'subs', 'grade', 'assistant'];

let renderSeq = 0;   // evita que una pantalla lenta pise a otra más reciente

async function render({ navigated = false } = {}) {
  const mySeq = ++renderSeq;
  Autosave.flush('leave');            // guarda lo que estuviera a medias en la pantalla anterior
  Autosave.set(null);
  let { route, param, p2, p3 } = parseHash();

  // Inicio de sesión obligatorio: sin cuenta solo se ven login y registro
  if (!Auth.user && !PUBLIC_ROUTES.includes(route)) { route = 'login'; if (location.hash !== '#/login') history.replaceState(null, '', '#/login'); }
  else if (Auth.user && PUBLIC_ROUTES.includes(route)) { route = 'dashboard'; history.replaceState(null, '', '#/dashboard'); }
  // Cada rol solo ve sus pantallas
  else if (Auth.isTeacher && STUDENT_ONLY.includes(route)) route = 'dashboard';
  else if (Auth.isStudent && TEACHER_ONLY.includes(route)) route = 'dashboard';
  paintChrome();

  Offline.stale = null;
  let node;
  try {
    switch (route) {
      case 'login':     node = viewLogin(); break;
      case 'register':  node = viewRegister(); break;
      case 'profile':   node = await viewProfile(); break;
      case 'dashboard': node = await viewDashboard(); break;
      case 'courses':   node = Auth.isTeacher ? await viewTeacherCourses() : await viewStudentCourses(); break;
      case 'course':    node = await viewCourse(param, p2); break;
      case 'clesson':   node = await viewWork('lesson', param, p2); break;
      case 'task':      node = await viewWork('assignment', param, p2); break;
      case 'edit-lesson': node = await viewItemEditor('lesson', param, p2); break;
      case 'edit-task': node = await viewItemEditor('assignment', param, p2); break;
      case 'subs':      node = await viewSubmissions(param, p2, p3); break;
      case 'grade':     node = await viewGrade(param); break;
      case 'lessons':   node = await viewLessons(); break;
      case 'lesson':    node = await viewLesson(param); break;
      case 'quiz':      node = viewQuiz(param); break;
      case 'tutor':     node = await viewTutor(param, p2); break;
      case 'assistant': node = viewAssistant(); break;
      case 'sync':      node = await viewSync(); break;
      default:          node = viewNotFound();
    }
  } catch (err) {
    console.error(err);
    node = viewError(err);
  }

  if (mySeq !== renderSeq) return;       // mientras cargaba, el usuario ya fue a otra pantalla
  if (Offline.stale !== null && node && node.classList && node.classList.contains('view')) node.prepend(Offline.noteNode());
  $('#app').replaceChildren(node);

  // Resalta el ítem activo del menú (lesson y quiz cuentan como "Lecciones")
  const active = (route === 'lesson' || route === 'quiz') ? 'lessons'
    : ['course', 'clesson', 'task', 'edit-lesson', 'edit-task', 'subs', 'grade'].includes(route) ? 'courses' : route;
  document.querySelectorAll('.nav a').forEach(a => {
    if (a.dataset.route === active) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });

  // Accesibilidad: al cambiar de pantalla, el foco va al título
  if (navigated) {
    window.scrollTo(0, 0);
    const h1 = $('#app h1');
    if (h1) h1.focus({ preventScroll: true });
  } else if (route === 'quiz' && quiz && quiz.locked) {
    const next = $('#btn-next');
    if (next) next.focus({ preventScroll: true });
  }
}

/** Repinta solo pantallas informativas (no interrumpe un cuestionario ni un formulario). */
function refreshView() {
  const { route } = parseHash();
  if (route !== 'dashboard' && route !== 'sync') return;
  if (!Auth.user) return;
  if (document.activeElement && document.activeElement.tagName === 'INPUT') return;
  render();
}

/** Muestra el menú y el avatar según el rol (o los oculta si no hay sesión). */
function paintChrome() {
  const user = Auth.user;
  const nav = $('.nav');
  nav.hidden = !user;
  document.querySelectorAll('.nav a[data-roles]').forEach(a => {
    a.hidden = !user || !a.dataset.roles.split(' ').includes(user.role);
  });
  const coursesLabel = $('#nav-courses-label');
  if (coursesLabel) coursesLabel.textContent = user && user.role === 'teacher' ? 'Mis cursos' : 'Cursos';
  const homeLabel = $('#nav-home-label');
  if (homeLabel) homeLabel.textContent = user && user.role === 'teacher' ? 'Panel' : 'Inicio';

  const chip = $('#user-chip');
  chip.hidden = !user;
  if (user) {
    $('#user-initials').textContent = initials(user.name);
    $('#user-role').textContent = roleLabel(user.role);
    chip.setAttribute('aria-label', `Perfil de ${user.name} (${roleLabel(user.role)})`);
    chip.dataset.role = user.role;
  }
  document.body.dataset.role = user ? user.role : '';
  $('#net-label').dataset.offlineUser = Auth.offline ? '1' : '';
}

function onAuthChanged() { paintChrome(); }

async function updateBadge() {
  try {
    const n = (Auth.isStudent ? await DB.countOutbox() : 0) + Queue.count();
    const badge = $('#nav-badge');
    badge.hidden = n === 0;
    badge.textContent = String(n);
  } catch { /* IndexedDB no disponible */ }
}

async function onOutboxChanged() {
  await updateBadge();
  refreshView();
}

/* =====================================================================
 * 8. PWA · Service Worker, actualizaciones e instalación
 * ===================================================================== */
const PWA = {
  deferredPrompt: null,
  updateRequested: false,

  isIOS: /iphone|ipad|ipod/i.test(navigator.userAgent) ||
         (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1),
  isStandalone: window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true,

  init() {
    if ('serviceWorker' in navigator) {
      const register = async () => {
        try {
          const reg = await navigator.serviceWorker.register('./sw.js');

          // ¿Ya había una versión nueva esperando?
          if (reg.waiting && navigator.serviceWorker.controller) PWA.showUpdate(reg.waiting);

          // ¿Se está instalando una versión nueva?
          reg.addEventListener('updatefound', () => {
            const worker = reg.installing;
            if (!worker) return;
            worker.addEventListener('statechange', () => {
              if (worker.state === 'installed' && navigator.serviceWorker.controller) PWA.showUpdate(worker);
            });
          });
        } catch (err) {
          console.warn('[AulaSink] No se pudo registrar el Service Worker:', err);
        }
      };
      if (document.readyState === 'complete') register();
      else window.addEventListener('load', register);

      // Cambió el SW que controla la página
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (PWA.updateRequested) {
          location.reload();                       // el usuario aceptó actualizar
        } else {
          toast('✅ AulaSink ya funciona sin conexión', 'ok'); // primera instalación
          refreshView();
        }
      });
    }

    // Instalación (Chrome / Edge / Android): guardamos el evento y mostramos el botón
    window.addEventListener('beforeinstallprompt', event => {
      event.preventDefault();
      PWA.deferredPrompt = event;
      $('#btn-install').hidden = false;
    });
    $('#btn-install').addEventListener('click', async () => {
      const prompt = PWA.deferredPrompt;
      if (!prompt) return;
      prompt.prompt();
      await prompt.userChoice;
      PWA.deferredPrompt = null;
      $('#btn-install').hidden = true;
    });
    window.addEventListener('appinstalled', () => {
      $('#btn-install').hidden = true;
      toast('🎉 AulaSink se instaló en tu dispositivo', 'ok');
    });
  },

  showUpdate(worker) {
    $('#update-banner').hidden = false;
    $('#btn-update').onclick = () => {
      PWA.updateRequested = true;
      worker.postMessage({ type: 'SKIP_WAITING' }); // el SW nuevo toma el control → controllerchange → recarga
    };
  }
};

/* =====================================================================
 * 9. ARRANQUE
 * ===================================================================== */
async function boot() {
  Net.init();
  Link.start();                               // vigila la calidad de la conexión y guarda a tiempo
  await Auth.init();                          // ¿hay una sesión abierta? (sin red: usa el usuario recordado)
  if (Auth.user) DB.use(Auth.user.id);        // progreso local separado por cuenta
  paintChrome();
  Sync.init();
  PWA.init();
  Offline.init();

  window.addEventListener('hashchange', () => render({ navigated: true }));

  // Pide al navegador que NO borre los datos locales si falta espacio
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});

  await render();
  await updateBadge();
  Queue.flush();  // acciones que quedaron pendientes en una sesión anterior
  Sync.flush(); // si quedaron registros pendientes de una sesión anterior y hay red
  if (Auth.user) Offline.syncSoon(true);   // descarga/actualiza los cursos y tareas para usarlos sin conexión
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
