/* =====================================================================
 * AulaSink · views-auth.js
 * Inicio de sesión, registro (Estudiante / Profesor) y perfil.
 * ===================================================================== */
'use strict';

function authShell(title, subtitle, ...content) {
  return el('section', { class: 'view auth' },
    el('div', { class: 'auth__brand' },
      el('img', { src: 'img/icon-1.png', alt: '', width: '64', height: '64' }),
      el('h1', { class: 'view__title', tabindex: '-1' }, title),
      el('p', { class: 'view__subtitle' }, subtitle)),
    ...content);
}

function field(label, input, hint) {
  return el('label', { class: 'field' }, el('span', { class: 'field__label' }, label), input,
    hint && el('small', { class: 'muted' }, hint));
}

async function afterAuth() {
  DB.use(Auth.user.id);                  // datos locales separados por cuenta
  await updateBadge();
  onAuthChanged();
  location.hash = '#/dashboard';
  Queue.flush();
  Sync.flush();
  Offline.syncSoon(true);                // descarga tus cursos y tareas para usarlos sin conexión
}

function viewLogin() {
  const email = el('input', { class: 'input', type: 'email', name: 'email', autocomplete: 'username', required: true, placeholder: 'tucorreo@ejemplo.com' });
  const password = el('input', { class: 'input', type: 'password', name: 'password', autocomplete: 'current-password', required: true });
  const error = el('p', { class: 'form-error', role: 'alert', hidden: true });
  const submit = el('button', { class: 'btn', type: 'submit' }, 'Iniciar sesión');

  const form = el('form', { class: 'card auth__form', novalidate: true, onsubmit: async event => {
    event.preventDefault();
    error.hidden = true;
    submit.disabled = true;
    try {
      await Auth.login(email.value, password.value);
      await afterAuth();
    } catch (err) {
      error.textContent = err.message; error.hidden = false;
    } finally { submit.disabled = false; }
  } }, field('Correo electrónico', email), field('Contraseña', password), error, submit);

  return authShell('Bienvenido/a a AulaSink', 'Inicia sesión para continuar con tus cursos.', form,
    el('p', { class: 'auth__alt' }, '¿Aún no tienes cuenta? ', el('a', { href: '#/register' }, 'Crear cuenta')),
    !Net.online && el('p', { class: 'muted auth__alt' }, '🟠 Sin conexión: para iniciar sesión por primera vez necesitas Internet.'));
}

function viewRegister() {
  let role = 'student';
  const name = el('input', { class: 'input', type: 'text', maxlength: '80', autocomplete: 'name', required: true, placeholder: 'Nombre y apellido' });
  const email = el('input', { class: 'input', type: 'email', autocomplete: 'username', required: true });
  const password = el('input', { class: 'input', type: 'password', minlength: '8', autocomplete: 'new-password', required: true });
  const code = el('input', { class: 'input', type: 'text', autocomplete: 'off', placeholder: 'Solo si tu institución lo entregó' });
  const codeField = field('Código de profesor (opcional)', code);
  codeField.hidden = true;
  const error = el('p', { class: 'form-error', role: 'alert', hidden: true });
  const submit = el('button', { class: 'btn', type: 'submit' }, 'Crear cuenta de estudiante');

  const cards = ['student', 'teacher'].map(r => {
    const radio = el('input', { type: 'radio', name: 'role', value: r, checked: r === 'student' });
    const card = el('label', { class: 'role-card' + (r === 'student' ? ' is-active' : '') }, radio,
      el('span', { class: 'role-card__icon', 'aria-hidden': 'true' }, r === 'student' ? '🎒' : '🍎'),
      el('strong', {}, r === 'student' ? 'Soy estudiante' : 'Soy profesor/a'),
      el('small', { class: 'muted' }, r === 'student' ? 'Entro a cursos con un código y resuelvo lecciones y tareas.' : 'Creo cursos, asigno tareas y califico a mis estudiantes.'));
    radio.addEventListener('change', () => {
      role = r;
      cards.forEach(c => c.classList.toggle('is-active', c === card));
      codeField.hidden = r !== 'teacher';
      submit.textContent = r === 'teacher' ? 'Crear cuenta de profesor' : 'Crear cuenta de estudiante';
    });
    return card;
  });

  const form = el('form', { class: 'card auth__form', novalidate: true, onsubmit: async event => {
    event.preventDefault();
    error.hidden = true;
    submit.disabled = true;
    try {
      const res = await Auth.register({ name: name.value, email: email.value, password: password.value, role,
        teacherCode: role === 'teacher' ? code.value : undefined });
      if (res.enrolledCourses) toast(`Te añadimos a ${res.enrolledCourses} curso(s) al que te invitaron.`, 'ok');
      await afterAuth();
    } catch (err) {
      error.textContent = err.message; error.hidden = false;
    } finally { submit.disabled = false; }
  } },
    el('fieldset', { class: 'roles' }, el('legend', {}, '¿Qué tipo de cuenta necesitas?'), el('div', { class: 'roles__grid' }, cards)),
    field('Nombre completo', name), field('Correo electrónico', email),
    field('Contraseña', password, 'Mínimo 8 caracteres.'), codeField, error, submit);

  return authShell('Crear cuenta', 'Elige tu tipo de cuenta para empezar.', form,
    el('p', { class: 'auth__alt' }, '¿Ya tienes cuenta? ', el('a', { href: '#/login' }, 'Iniciar sesión')));
}

/* ---------- Perfil ---------- */
async function viewProfile() {
  const user = Auth.user;
  const nodes = [
    el('h1', { class: 'view__title', tabindex: '-1' }, 'Mi perfil'),
    el('div', { class: 'card profile' },
      el('div', { class: 'avatar avatar--lg', 'aria-hidden': 'true' }, initials(user.name)),
      el('div', {},
        el('h2', {}, user.name),
        el('p', { class: 'muted' }, user.email),
        el('span', { class: 'chip ' + (user.role === 'teacher' ? 'chip--ok' : '') }, roleLabel(user.role))),
      el('div', { class: 'actions' },
        el('button', { class: 'btn btn--ghost', type: 'button', onclick: doLogout }, 'Cerrar sesión')))
  ];

  // Cursos e integrantes
  nodes.push(el('h2', {}, user.role === 'teacher' ? 'Mis cursos y estudiantes' : 'Mis cursos e integrantes'));
  const holder = el('div', {}, el('p', { class: 'muted' }, 'Cargando cursos…'));
  nodes.push(holder);
  loadProfileCourses(holder);

  nodes.push(el('div', { class: 'card' },
    el('h2', {}, 'Sincronización'),
    el('p', { class: 'muted' }, 'Revisa lo que está pendiente de enviar desde este dispositivo.'),
    el('a', { class: 'btn btn--ghost btn--small', href: '#/sync' }, 'Ver sincronización')));

  // Cambiar contraseña
  const current = el('input', { class: 'input', type: 'password', autocomplete: 'current-password', required: true });
  const next = el('input', { class: 'input', type: 'password', minlength: '8', autocomplete: 'new-password', required: true });
  const pwError = el('p', { class: 'form-error', role: 'alert', hidden: true });
  const pwBtn = el('button', { class: 'btn btn--small', type: 'submit' }, 'Cambiar contraseña');
  nodes.push(el('form', { class: 'card auth__form', onsubmit: async event => {
    event.preventDefault();
    pwError.hidden = true;
    await withBusy(pwBtn, async () => {
      try {
        await Api.post('/auth/password', { current: current.value, next: next.value });
        current.value = ''; next.value = '';
        toast('Contraseña actualizada.', 'ok');
      } catch (err) { pwError.textContent = err.message; pwError.hidden = false; }
    });
  } }, el('h2', {}, 'Cambiar contraseña'), field('Contraseña actual', current), field('Contraseña nueva', next, 'Mínimo 8 caracteres.'), pwError, pwBtn));

  return el('section', { class: 'view' }, nodes);
}

async function loadProfileCourses(holder) {
  try {
    const { courses } = await Api.get('/courses');
    if (!courses.length) {
      holder.replaceChildren(emptyState(Auth.isTeacher ? 'Aún no has creado cursos.' : 'Todavía no estás en ningún curso.',
        el('a', { class: 'btn btn--small', href: '#/courses' }, Auth.isTeacher ? 'Crear un curso' : 'Unirme con un código')));
      return;
    }
    holder.replaceChildren(...courses.map(c => {
      const body = el('div', { class: 'details__body' }, el('p', { class: 'muted' }, 'Cargando integrantes…'));
      const details = el('details', { class: 'card details' },
        el('summary', {}, el('strong', {}, c.name), ' ', el('span', { class: 'muted' }, Auth.isTeacher ? `· ${c.students} estudiantes` : `· ${c.teacherName}`)),
        body);
      let loaded = false;
      details.addEventListener('toggle', async () => {
        if (!details.open || loaded) return;
        loaded = true;
        try { body.replaceChildren(membersList((await Api.get(`/courses/${c.id}/members`)).members), el('a', { href: `#/course/${c.id}` }, 'Abrir curso →')); }
        catch (err) { loaded = false; body.replaceChildren(el('p', { class: 'muted' }, err.message)); }
      });
      return details;
    }));
  } catch (err) {
    holder.replaceChildren(el('p', { class: 'muted' }, err.offline ? 'Conéctate a Internet para ver tus cursos.' : err.message));
  }
}

/** Lista de integrantes: el profesor primero, luego los compañeros. */
function membersList(members) {
  const teachers = members.filter(m => m.role === 'teacher');
  const students = members.filter(m => m.role === 'student');
  const row = m => el('li', { class: 'member' },
    el('span', { class: 'avatar' + (m.role === 'teacher' ? ' avatar--teacher' : ''), 'aria-hidden': 'true' }, initials(m.name)),
    el('span', { class: 'member__name' }, m.name, m.isMe && el('span', { class: 'chip' }, 'Tú'),
      m.email && el('small', { class: 'muted' }, m.email)),
    el('span', { class: 'chip ' + (m.role === 'teacher' ? 'chip--ok' : '') }, roleLabel(m.role)));
  return el('div', {},
    el('ul', { class: 'members' }, teachers.map(row)),
    el('h3', { class: 'members__title' }, `Compañeros (${students.length})`),
    students.length ? el('ul', { class: 'members' }, students.map(row)) : el('p', { class: 'muted' }, 'Todavía no hay estudiantes.'));
}

async function doLogout() {
  const pending = Queue.count();
  if (pending && !confirm(`Tienes ${pending} acción(es) sin enviar guardadas en este dispositivo. Siguen guardadas y se enviarán cuando vuelvas a iniciar sesión con esta cuenta con conexión. ¿Cerrar sesión?`)) return;
  await Offline.wipe().catch(() => {});      // privacidad: borra la copia local (si no hay nada pendiente)
  await Auth.logout();
  quiz = null;
  onAuthChanged();
  location.hash = '#/login';
  toast('Sesión cerrada.');
}
