/* =====================================================================
 * AulaSink · views-student.js
 * Cursos del estudiante: inicio, unirse con código, temario, tareas,
 * integrantes, calificaciones y el desarrollo de lecciones y tareas.
 * ===================================================================== */
'use strict';

/* ---------- Tarjeta de curso ---------- */
function studentCourseCard(c) {
  const st = c.stats || {};
  return el('a', { class: 'card course-card', href: `#/course/${c.id}` },
    el('div', { class: 'course-card__top' },
      el('span', { class: 'chip' }, c.subject || 'Curso'),
      c.finalGrade !== null && c.finalGrade !== undefined && el('span', { class: 'chip chip--ok' }, `Nota final ${pctText(c.finalGrade)}`)),
    el('h3', {}, c.name),
    el('p', { class: 'muted' }, `👩‍🏫 ${c.teacherName}`),
    bar(st.progress || 0, `Avance en ${c.name}`),
    el('p', { class: 'muted course-card__meta' },
      st.lessonsTotal ? `Avance ${st.progress}% · ${st.lessonsDone}/${st.lessonsTotal} lecciones` : 'Sin lecciones habilitadas aún',
      st.assignmentsTotal ? ` · ${st.assignmentsSubmitted}/${st.assignmentsTotal} tareas` : ''));
}

/** Formulario "Unirme con un código". */
function joinForm() {
  const code = el('input', { class: 'input code-input', type: 'text', maxlength: '12', placeholder: 'CÓDIGO', autocomplete: 'off',
    autocapitalize: 'characters', 'aria-label': 'Código del curso', required: true });
  const btn = el('button', { class: 'btn', type: 'submit' }, 'Unirme');
  return el('form', { class: 'card join-form', onsubmit: async event => {
    event.preventDefault();
    await withBusy(btn, async () => {
      const res = await Api.post('/courses/join', { code: code.value });
      toast(res.alreadyMember ? `Ya estabas en «${res.name}».` : `¡Te uniste a «${res.name}»!`, 'ok');
      location.hash = `#/course/${res.id}`;
    });
  } },
    el('label', { for: 'join-code' }, el('strong', {}, 'Unirme a un curso'), el('br'),
      el('span', { class: 'muted' }, 'Escribe el código que te dio tu profesor.')),
    el('div', { class: 'join-form__row' }, Object.assign(code, { id: 'join-code' }), btn));
}

/* ---------- Bloque "Mis cursos" del inicio ---------- */
async function studentHomeSection() {
  try {
    const data = await Api.get('/me/overview');       // con copia local: también funciona sin conexión
    const parts = [el('h2', {}, 'Mis cursos')];
    if (!data.courses.length) {
      parts.push(el('div', { class: 'card' },
        el('p', {}, 'Todavía no estás en ningún curso. Pide el código a tu profesor para unirte.'), joinForm()));
    } else {
      parts.push(el('div', { class: 'grid grid--lessons' }, data.courses.map(c => studentCourseCard({ ...c, teacherName: c.teacherName }))));
      parts.push(el('div', { class: 'actions' }, el('a', { class: 'btn btn--ghost btn--small', href: '#/courses' }, 'Ver todos / unirme con código')));
    }
    if (data.todo.length) {
      parts.push(el('h2', {}, 'Tareas pendientes'));
      parts.push(el('div', { class: 'card' }, el('ul', { class: 'todo' }, data.todo.map(t =>
        el('li', {}, el('a', { href: `#/task/${t.courseId}/${t.id}` }, t.title),
          el('span', { class: 'muted' }, `${t.courseName} · ${fmtDue(t.dueAt)}`),
          t.status === 'returned' && el('span', { class: 'chip chip--bad' }, 'Devuelta'),
          t.status === 'draft' && el('span', { class: 'chip chip--warn' }, 'En curso'))))));
    }
    return el('div', {}, parts);
  } catch (err) {
    return err.offline ? null : el('div', { class: 'card' }, el('p', { class: 'muted' }, 'No se pudieron cargar tus cursos: ' + err.message));
  }
}

/* ---------- #/courses (estudiante) ---------- */
async function viewStudentCourses() {
  let courses;
  try { ({ courses } = await Api.get('/courses')); } catch (err) { return errorView(err, () => render()); }
  return el('section', { class: 'view' },
    el('h1', { class: 'view__title', tabindex: '-1' }, 'Mis cursos'),
    el('p', { class: 'view__subtitle' }, 'Entra a un curso para ver su temario, tus tareas y a tus compañeros.'),
    joinForm(),
    courses.length ? el('div', { class: 'grid grid--lessons' }, courses.map(studentCourseCard))
      : emptyState('Aún no estás en ningún curso.'));
}

/* ---------- #/course/:cid/:tab (estudiante) ---------- */
const STUDENT_TABS = [['lessons', 'Temario'], ['tasks', 'Tareas'], ['people', 'Integrantes'], ['grades', 'Calificaciones']];

async function viewStudentCourse(cid, tab, detail) {
  const { course } = detail;
  const active = STUDENT_TABS.some(t => t[0] === tab) ? tab : 'lessons';
  let me;
  try { me = await Api.get(`/courses/${cid}/me`); } catch (err) { return errorView(err, () => render()); }
  const st = me.stats;

  let content;
  try {
    if (active === 'lessons') content = await studentLessonsTab(cid);
    else if (active === 'tasks') content = await studentTasksTab(cid);
    else if (active === 'people') content = await studentPeopleTab(cid);
    else content = await studentGradesTab(cid, me);
  } catch (err) { content = el('div', { class: 'card' }, el('p', {}, err.message)); }

  return el('section', { class: 'view' },
    el('a', { class: 'back-link', href: '#/courses' }, '← Mis cursos'),
    el('div', { class: 'card course-head' },
      el('span', { class: 'chip' }, course.subject || 'Curso'),
      el('h1', { class: 'view__title', tabindex: '-1' }, course.name),
      course.description && el('p', { class: 'muted' }, course.description),
      el('p', {}, `👩‍🏫 ${course.teacherName}`),
      bar(st.progress || 0, 'Tu avance en el curso'),
      el('p', { class: 'muted' }, st.lessonsTotal ? `Tu avance: ${st.progress}% (${st.lessonsDone} de ${st.lessonsTotal} lecciones)` : 'Aún no hay lecciones habilitadas.')),
    tabBar(STUDENT_TABS, active, key => `#/course/${cid}/${key}`),
    content);
}

async function studentLessonsTab(cid) {
  const { items } = await Api.get(`/courses/${cid}/lessons`);
  if (!items.length) return emptyState('Tu profesor aún no ha habilitado lecciones.');
  return el('div', { class: 'stack' }, items.map((l, i) => el('a', { class: 'card item-row', href: `#/clesson/${cid}/${l.id}` },
    el('span', { class: 'item-row__num', 'aria-hidden': 'true' }, String(i + 1)),
    el('div', { class: 'item-row__body' },
      el('h3', {}, l.title),
      el('p', { class: 'muted' }, `${l.minutes} min · ${l.questionCount} pregunta(s)`),
      bar(l.submission ? l.submission.progressPct : 0, `Avance de ${l.title}`)),
    statusChip(l.submission, { lesson: true }))));
}

async function studentTasksTab(cid) {
  const { items } = await Api.get(`/courses/${cid}/assignments`);
  if (!items.length) return emptyState('No tienes tareas asignadas por ahora. 🎉');
  return el('div', { class: 'stack' }, items.map(t => {
    const overdue = t.dueAt && new Date(t.dueAt) < new Date() && (!t.submission || ['draft', 'returned'].includes(t.submission.status));
    return el('a', { class: 'card item-row', href: `#/task/${cid}/${t.id}` },
      el('span', { class: 'item-row__num', 'aria-hidden': 'true' }, '📝'),
      el('div', { class: 'item-row__body' },
        el('h3', {}, t.title),
        el('p', { class: overdue ? 'is-overdue' : 'muted' }, fmtDue(t.dueAt) + (overdue ? ' · ¡vencida!' : '') + ` · ${t.questionCount} pregunta(s)`)),
      statusChip(t.submission));
  }));
}

async function studentPeopleTab(cid) {
  const { members } = await Api.get(`/courses/${cid}/members`);
  return el('div', { class: 'card' },
    el('h2', {}, `Integrantes del curso (${members.length})`),
    membersList(members));
}

async function studentGradesTab(cid, me) {
  const [lessons, tasks] = await Promise.all([Api.get(`/courses/${cid}/lessons`), Api.get(`/courses/${cid}/assignments`)]);
  const rows = [
    ...lessons.items.map(i => ({ kind: 'Lección', href: `#/clesson/${cid}/${i.id}`, ...i })),
    ...tasks.items.map(i => ({ kind: 'Tarea', href: `#/task/${cid}/${i.id}`, ...i }))
  ];
  const hasFinal = me.finalGrade !== null && me.finalGrade !== undefined;
  return el('div', {},
    el('div', { class: 'card result' },
      el('h2', {}, 'Calificación final del curso'),
      hasFinal
        ? [el('div', { class: 'score-ring ' + (me.finalGrade >= 60 ? 'is-pass' : 'is-fail') }, pctText(me.finalGrade)),
           me.finalComment && el('p', {}, '💬 ' + me.finalComment)]
        : el('p', { class: 'muted' }, 'Tu profesor aún no ha asignado la calificación final.'),
      me.stats.average !== null && el('p', { class: 'muted' }, `Promedio de tus entregas calificadas: ${pctText(me.stats.average)}`)),
    el('div', { class: 'card' },
      el('h2', {}, 'Detalle'),
      rows.length ? el('table', { class: 'table' },
        el('thead', {}, el('tr', {}, ['Actividad', 'Tipo', 'Estado'].map(h => el('th', {}, h)))),
        el('tbody', {}, rows.map(r => el('tr', {},
          el('td', {}, el('a', { href: r.href }, r.title)), el('td', {}, r.kind),
          el('td', {}, statusChip(r.submission, { lesson: r.kind === 'Lección' })))))) : el('p', { class: 'muted' }, 'Aún no hay actividades.')));
}

/* =====================================================================
 * Desarrollo de una lección o tarea
 * ===================================================================== */
const draftKey = (type, tid) => `aulasink.draft.${Auth.user.id}.${type}.${tid}`;

async function viewWork(type, cid, tid) {
  const seg = type === 'lesson' ? 'lessons' : 'assignments';
  let item;
  try { ({ item } = await Api.get(`/courses/${cid}/${seg}/${tid}`)); } catch (err) { return errorView(err, () => render()); }

  const sub = item.submission;
  const backHref = `#/course/${cid}/${type === 'lesson' ? 'lessons' : 'tasks'}`;
  const questions = item.questions;

  // Estado local: respuestas en edición
  let retrying = false;                                  // repetir una lección que se califica sola
  let editable = item.canSave;
  let answers = JSON.parse(JSON.stringify((sub && sub.answers) || {}));
  const autosave = () => editable && !retrying;

  // ¿Quedó algo sin guardar en este dispositivo?
  if (editable) {
    try {
      const backup = JSON.parse(store.get(draftKey(type, tid)) || 'null');
      if (backup && backup.answers && Object.keys(backup.answers).length) {
        answers = backup.answers;
        setTimeout(() => toast('Recuperamos tu avance que no se había guardado.', 'ok'), 300);
      }
    } catch { /* copia ilegible */ }
  }

  const progressBar = el('div', {});
  const progressText = el('p', { class: 'muted', role: 'status' });
  const saveStatus = el('small', { class: 'muted', role: 'status' });
  const formHolder = el('div', {});
  const actions = el('div', { class: 'actions' });

  const pctNow = () => (questions.length ? Math.round((answeredCount(questions, answers) / questions.length) * 100) : 0);

  function paintProgress() {
    const done = answeredCount(questions, answers);
    const pct = questions.length ? Math.round((done / questions.length) * 100) : (sub && sub.status !== 'draft' ? 100 : 0);
    progressBar.replaceChildren(bar(pct, 'Avance'));
    progressText.textContent = questions.length ? `${done} de ${questions.length} preguntas respondidas · ${pct}%` : '';
  }

  /* --- Guardado --- */
  let timer = null, saving = false, again = false, dirty = false, finished = false;
  async function saveDraft({ manual = false } = {}) {
    if (!editable || finished) return;
    if (saving) { again = true; return; }
    saving = true; saveStatus.textContent = 'Guardando…';
    try {
      const res = await Api.mutate('PUT', `/courses/${cid}/${seg}/${tid}/answers`, { answers },
        { label: `Avance: ${item.title}`, key: `draft:${type}:${tid}`,
          op: { k: 'draft', cid, seg, tid, answers: JSON.parse(JSON.stringify(answers)), progress: pctNow() } });
      dirty = false;
      store.set(draftKey(type, tid), '');
      if (res.queued) {
        saveStatus.textContent = '🟠 Sin conexión: avance guardado en este dispositivo; se enviará solo.';
        if (manual) toast('Sin conexión: tu avance se enviará solo al reconectar.', 'warn');
      } else {
        saveStatus.textContent = '✓ Avance guardado';
        if (manual) toast('Avance guardado.', 'ok');
      }
    } catch (err) {
      saveStatus.textContent = '⚠️ No se pudo guardar: ' + err.message;
      if (manual) toast(err.message, 'warn');
    } finally {
      saving = false;
      if (again) { again = false; saveDraft(); }
    }
  }

  function onChange() {
    paintProgress();
    if (!editable) return;
    dirty = true;
    store.set(draftKey(type, tid), JSON.stringify({ answers, at: Date.now() }));   // copia de seguridad local
    if (!autosave()) { saveStatus.textContent = ''; return; }
    saveStatus.textContent = 'Cambios sin guardar…';
    clearTimeout(timer);
    timer = setTimeout(() => saveDraft(), 1500);
  }

  async function submit(button) {
    const pending = questions.length - answeredCount(questions, answers);
    const msg = (pending ? `Tienes ${pending} pregunta(s) sin responder.\n\n` : '') +
      (type === 'lesson' && !item.hasManual ? '¿Entregar tus respuestas?' : '¿Entregar? Después no podrás modificar tus respuestas, salvo que tu profesor te la devuelva.');
    if (!confirm(msg)) return;
    clearTimeout(timer);
    await withBusy(button, async () => {
      const res = await Api.mutate('POST', `/courses/${cid}/${seg}/${tid}/submit`, { answers, clientSubmittedAt: new Date().toISOString() },
        { label: `Entrega: ${item.title}`, key: `submit:${type}:${tid}`, ok409: true, supersede: [`draft:${type}:${tid}`],
          op: { k: 'submit', cid, seg, tid, answers: JSON.parse(JSON.stringify(answers)) } });
      finished = true;
      if (res.queued) {
        // Sin señal: la entrega queda guardada en el dispositivo y se envía sola
        store.set(draftKey(type, tid), '');
        formHolder.replaceChildren(el('div', { class: 'card notice' }, el('strong', {}, '📬 Entrega guardada en este dispositivo'),
          el('p', {}, 'No hay conexión en este momento. Se enviará automáticamente cuando vuelva la señal, con la hora a la que la hiciste. No cierres la sesión. Tu nota aparecerá cuando se envíe.'),
          el('a', { class: 'btn btn--ghost btn--small', href: backHref }, 'Volver al curso')));
        actions.replaceChildren();
        toast('Sin conexión: tu entrega se enviará sola al reconectar.', 'warn');
        return;
      }
      store.set(draftKey(type, tid), '');
      toast(res.submission.needsReview ? '¡Entregado! Tu profesor lo revisará.' : `¡Listo! Tu nota: ${pctText(res.submission.scorePct)}`, 'ok');
      retrying = false;
      await render();
    });
  }

  function paintForm() {
    const review = !editable && sub && sub.review ? sub.review : null;
    formHolder.replaceChildren(questionForm({
      questions, answers, courseId: cid, editable,
      review, grading: !editable && sub ? sub.grading : null, onChange
    }));
    actions.replaceChildren();
    if (editable) {
      if (autosave() || !retrying) {
        actions.append(el('button', { class: 'btn btn--ghost', type: 'button', onclick: () => saveDraft({ manual: true }) }, 'Guardar avance'));
      }
      actions.append(el('button', { class: 'btn', type: 'button', onclick: event => submit(event.currentTarget) },
        type === 'lesson' && !item.hasManual ? 'Terminar y ver mi nota' : 'Entregar'));
      if (retrying) actions.append(el('button', { class: 'btn btn--ghost', type: 'button', onclick: () => render() }, 'Cancelar'));
    } else if (item.canSubmit && type === 'lesson') {
      actions.append(el('button', { class: 'btn', type: 'button', onclick: () => {
        retrying = true; editable = true; answers = {}; paintForm(); paintProgress(); window.scrollTo(0, 0);
      } }, 'Intentar de nuevo'));
    }
    if (type === 'lesson') actions.append(el('a', { class: 'btn btn--ghost', href: `#/tutor/${tid}/${cid}` }, '🤖 Preguntar al tutor'));
  }

  /* --- Tarjeta de estado de la entrega --- */
  function statusCard() {
    if (!sub) return null;
    if (sub.pendingSync && sub.status === 'submitted') {
      return el('div', { class: 'card notice' }, el('strong', {}, '📬 Entrega guardada en este dispositivo'),
        el('p', {}, 'Todavía no llegó al servidor. Se enviará sola cuando vuelva la conexión y entonces verás tu nota o la revisión de tu profesor.'));
    }
    if (sub.status === 'graded') {
      const pass = sub.scorePct === null || sub.scorePct >= 60;
      return el('div', { class: 'card result' },
        sub.scorePct !== null && el('div', { class: 'score-ring ' + (pass ? 'is-pass' : 'is-fail') }, pctText(sub.scorePct)),
        el('p', {}, sub.scorePct === null ? '✅ Lección completada.' : `Calificada · ${sub.autoPoints + (sub.manualPoints || 0)} de ${sub.totalPoints} puntos`),
        sub.late && el('p', { class: 'muted' }, '⏰ Entregada fuera de plazo.'),
        sub.teacherComment && el('p', {}, '💬 ' + sub.teacherComment));
    }
    if (sub.status === 'submitted') {
      return el('div', { class: 'card notice' }, el('strong', {}, '📬 Entregada'),
        el('p', {}, 'Tu profesor la está revisando.' + (sub.autoPoints ? ` Ya tienes ${sub.autoPoints} punto(s) de las preguntas automáticas.` : '')),
        sub.late && el('p', { class: 'muted' }, '⏰ Entregada fuera de plazo.'));
    }
    if (sub.status === 'returned') {
      return el('div', { class: 'card notice notice--bad' }, el('strong', {}, '↩️ Tu profesor te la devolvió para que la corrijas'),
        sub.teacherComment && el('p', {}, '💬 ' + sub.teacherComment));
    }
    return null;
  }

  // Guardado preventivo: si la señal se va, la pestaña se oculta o se cambia de pantalla, se guarda ya
  Autosave.set(() => {
    if (editable && dirty && !finished && autosave()) { clearTimeout(timer); saveDraft(); }
  });

  const overdue = type === 'assignment' && item.dueAt && new Date(item.dueAt) < new Date();
  paintForm();
  paintProgress();

  return el('section', { class: 'view' },
    el('a', { class: 'back-link', href: backHref }, '← Volver al curso'),
    el('span', { class: 'chip' }, type === 'lesson' ? `📖 Lección · ${item.minutes} min` : '📝 Tarea'),
    el('h1', { class: 'view__title', tabindex: '-1', style: 'margin-top:8px' }, item.title),
    type === 'lesson'
      ? (item.paragraphs.length ? el('article', { class: 'card lesson-text' }, item.paragraphs.map(p => el('p', {}, p))) : null)
      : el('div', { class: 'card' },
          el('p', { class: overdue && (!sub || sub.status !== 'graded') ? 'is-overdue' : 'muted' }, '📅 ' + fmtDue(item.dueAt)),
          item.instructions && el('p', { class: 'answer-text' }, item.instructions)),
    statusCard(),
    questions.length ? el('div', { class: 'card sticky-progress' }, progressBar, progressText, saveStatus) : null,
    formHolder, actions);
}
