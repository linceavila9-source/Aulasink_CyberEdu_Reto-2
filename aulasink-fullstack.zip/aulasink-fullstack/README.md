# AulaSink · Plataforma educativa offline-first (PWA + backend) · v3.1

Reto 02 · Aprender sin conexión. La app funciona sin Internet (Service Worker + IndexedDB)
y, al volver la red, sincroniza con un servidor real (Node.js + MySQL). Incluye un tutor con IA
(GroqCloud) que guía al estudiante sin darle las respuestas.

```
aulasink-fullstack/
├── iniciar.bat        Windows: doble clic y la app arranca (instala, configura y abre el navegador)
├── setup.js           Lo usa iniciar.bat: crea .env, enciende MySQL, crea / actualiza la base de datos
├── server.js          Backend Express: arranque, seguridad, /api/sync, /api/tutor, /api/health + sirve la PWA
├── routes/            auth · courses · content (temario y tareas) · work (respuestas, fotos) · submissions · files · overview
├── lib/               preguntas y puntajes (questions.js), contraseñas y sesiones, acceso a cursos, estadísticas
├── schema.sql         Base de datos MySQL (14 tablas; idempotente: se puede volver a ejecutar)
├── test/              questions.test.js (unitarias) · api-smoke.js (prueba de la API completa)
├── package.json
├── .env.example       Plantilla de configuración (cópiala a .env)
└── public/            Frontend PWA: index.html, app.js, api.js, ui.js, views-*.js, sw.js, styles.css…
```

## Novedades de la versión 2 · cuentas, cursos, tareas y calificaciones

Ahora hay **inicio de sesión obligatorio** con dos tipos de cuenta:

| | Estudiante | Profesor |
|---|---|---|
| Registro | Elige «Soy estudiante» | Elige «Soy profesor/a» (opcional: código `TEACHER_SIGNUP_CODE`) |
| Cursos | Se une con el **código del curso**, o el profesor lo añade | Crea cursos; cada uno tiene su código (se puede regenerar o desactivar) |
| Estudiantes | Ve a los **integrantes**: profesor y compañeros (Perfil y pestaña del curso) | Añade por **correo** (si no tiene cuenta queda invitado y entra al registrarse) o **crea su cuenta** directamente; puede quitarlos |
| Temario | Resuelve las lecciones **habilitadas**; el sistema guarda su **% de avance** | Crea lecciones ordenadas con contenido y preguntas; las **habilita / oculta** |
| Tareas | Responde y entrega (aviso de fecha límite); puede corregir si se la devuelven | Asigna tareas con fecha límite; revisa, califica por pregunta o la **devuelve para corregir** |
| Preguntas | **Opción múltiple** (se califica sola) · **Desarrollo escrito** · **Práctica a mano** (foto de la hoja) | Mezcla los tres tipos con puntos por pregunta |
| Notas | Ve su nota, comentarios y respuestas correctas al entregar; y su **calificación final** | Califica cada entrega y asigna el **porcentaje final** del curso (con sugerencia = promedio) |

Las 4 lecciones de práctica general de la v1 (con cuestionario **sin conexión**, sincronización idempotente y tutor IA) siguen
funcionando igual para los estudiantes, bajo «Práctica». El tutor también ayuda en las lecciones de un curso.

### Sin conexión inteligente (v2.1)
- **Vigila la señal de verdad:** cada 15 s mide la respuesta del servidor (no basta con «hay WiFi»). El indicador tiene 3 estados:
  *En línea*, *Señal inestable* (respuesta lenta o red 2G) y *Sin conexión*.
- **Guarda antes de perderla:** al pasar a *inestable* o *sin conexión*, al ocultar la pestaña, cerrar la página o cambiar de pantalla,
  se guarda solo lo que estuviera a medias (respuestas del estudiante, borrador de lección/tarea, calificación a medias).
- **Cola de acciones (estudiante y profesor):** entregar, calificar, devolver, guardar lecciones/tareas y poner notas finales se pueden hacer
  sin señal; quedan en el dispositivo (menú *Sincronizar*) y se envían solas, en orden, al volver la conexión. Reenviar nunca duplica.
  No se pueden hacer sin conexión: subir fotos, ver datos nuevos y usar la IA.

### Asistente de IA para el profesor (v2.1)
Menú **Asistente** (chat para planificar, rúbricas, ideas) y, dentro del editor de lecciones/tareas, el panel **✨ Asistente de IA**:
genera preguntas de los tres tipos, redacta un borrador de contenido y, al calificar, sugiere un comentario (y puntaje) para respuestas escritas.
Solo sugiere: el profesor revisa y decide. Usa la misma `GROQ_API_KEY` del tutor (límite `ASSISTANT_RATE_LIMIT` cada 10 min).

**Actualizar desde la v1:** reemplaza los archivos y abre `iniciar.bat` (o ejecuta `mysql -u root -p < schema.sql`): solo se añaden
las tablas nuevas, tus datos se conservan. Las respuestas locales de la v1 (hechas antes de existir cuentas) no se asignan a ninguna cuenta.

## Novedades de la versión 3 · TODA la plataforma sin conexión

Antes, solo las lecciones de práctica (que viven dentro de la app) funcionaban sin Internet; los cursos, las tareas y las
entregas se pedían al servidor y fallaban sin señal. Ahora **todo** funciona sin conexión, para estudiantes y profesores:

| Qué haces sin Internet | Qué pasa |
|---|---|
| Abrir la app, tus cursos, temario, tareas, integrantes y notas | Se leen de una **copia local** (IndexedDB) que se descarga sola al abrir la app, al reconectar y cada 15 min |
| Responder una tarea o lección | El avance se guarda en el dispositivo y se envía solo |
| **Entregar** una tarea o lección | Queda en cola, se ve ya como «📬 Entrega por enviar» y viaja al volver la señal **con la hora real en que la hiciste** (no cuenta como tardía por falta de señal) |
| Adjuntar **fotos** de práctica a mano | La foto se guarda en el dispositivo (⏳) y se sube sola antes de enviar la entrega |
| Profesor: crear / editar / publicar / eliminar / reordenar lecciones y tareas | Se ven al instante y se envían en orden; crear y luego editar no duplica nada |
| Profesor: calificar, devolver, poner nota final | Se ve el resultado ya mismo (nota calculada localmente) y se confirma al sincronizar |
| Profesor: revisar entregas ya descargadas (incluidas las fotos) | Disponible sin conexión |

**Cómo funciona** (archivo nuevo `public/offline.js`):
- **Mirror**: copia de cada respuesta de la API por cuenta. `Api.get` ahora es «red primero, copia local si falla».
- **Overlay**: los cambios pendientes de la cola se «pintan» encima de la copia al leerla. La copia nunca se altera, así lo que
  dijo el servidor siempre manda y nunca se mezcla con lo pendiente.
- **Photos**: fotos tomadas sin conexión con id provisional `local-…`, reemplazado por el real al subirlas.
- El Service Worker (v3.0.0) también guarda las fotos de las entregas (`/api/files/`), para que el profesor las vea sin conexión.
- Servidor: `POST …/submit` acepta `clientSubmittedAt` (acotado: no futuro, máx. 30 días atrás).

**Lo que sigue necesitando Internet** (por su naturaleza): iniciar sesión por primera vez en un dispositivo, registrarse, crear un
curso, unirse con código, añadir/quitar estudiantes, ajustes del curso, el tutor y el asistente de IA. Si se intenta sin red, la app
lo dice claramente.

**Privacidad en dispositivos compartidos**: al cerrar sesión se borra la copia local de esa cuenta (si hay cosas sin enviar, se
conservan hasta que se envíen y se avisa antes).

**Importante en iPhone/iPad**: instala la app («Añadir a pantalla de inicio»). Safari borra los datos de sitios que no se usan en
7 días, pero no los de apps instaladas.

### Tutor también sin conexión (v3.1)
El tutor ahora tiene dos modos (`public/tutor-local.js`):
- **Preguntas predeterminadas** (botones): «¿De qué trata esta lección?», «Dame los puntos clave», «Muéstrame un ejemplo»,
  «¿Qué significan las palabras importantes?», «Una pista para la pregunta N», dudas típicas de cada lección y ayuda de la app
  («¿Cómo entrego sin conexión?», consejos de estudio…). Responden **al instante y sin Internet**, con y sin conexión.
  Funcionan con las lecciones incluidas y con las que crea el profesor (se arman con el texto de la lección guardado en el dispositivo).
- **Pregunta escrita**: con Internet va a la IA, como antes. Sin Internet (o si la IA no responde) se busca la mejor respuesta guardada
  o el fragmento de la lección que más se parece. Si no hay nada, lo dice y sugiere una pregunta de los botones.
- Las **pistas nunca dan la respuesta** del cuestionario: solo indican qué fragmento de la lección releer.
- Para añadir respuestas a mano de una lección incluida, edita `FAQ` en `tutor-local.js` (`{ q, k: 'palabras clave', a }`).

## Inicio rápido en Windows (un clic)

Requisitos: **Node.js LTS** (https://nodejs.org) y **MySQL**. La forma más fácil de tener MySQL es
**XAMPP** (https://www.apachefriends.org), con el que `root` no tiene contraseña.

Haz **doble clic en `iniciar.bat`**. La primera vez:
1. Instala las dependencias (necesita Internet solo esta vez).
2. Crea el archivo `.env` con valores por defecto, sin que lo edites.
3. Si MySQL está apagado, intenta encenderlo (servicio de Windows o XAMPP) y espera a que responda.
4. Si MySQL pide contraseña, te la pregunta **una vez** y la guarda.
5. Crea la base de datos `aulasink`.
6. Te ofrece pegar tu API Key de Groq para el tutor. Es **opcional**: con Enter se omite y el resto de la app funciona igual.
7. Arranca el servidor y abre http://localhost:3000 en tu navegador.

Las siguientes veces no pregunta nada: arranca y abre el navegador. Para cerrar AulaSink, cierra la ventana negra.

**Si algo falla**
- *"No pude conectar con MySQL"*: abre el panel de XAMPP y pulsa **Start** en MySQL; luego vuelve a abrir `iniciar.bat`.
- *"El puerto 3000 ya está en uso"*: ya tienes AulaSink abierto en otra ventana, o cambia `PORT` en `.env`.
- Para añadir o cambiar la clave de Groq más adelante: abre `.env`, escribe la clave en `GROQ_API_KEY` y borra la línea `GROQ_SKIPPED`.

*(En Mac/Linux, o si prefieres hacerlo a mano, usa los pasos de abajo.)*

## Puesta en marcha manual (5 pasos)

Requisitos: **Node.js 18+** y **MySQL 8** (o MariaDB 10.5+). Una API Key de GroqCloud
(https://console.groq.com/keys) para el tutor.

1. **Instala dependencias**
   ```bash
   npm install
   ```
2. **Crea la base de datos**
   ```bash
   mysql -u root -p < schema.sql
   ```
   Crea el usuario de la app (recomendado en lugar de usar `root`):
   ```sql
   CREATE USER 'aulasink_app'@'localhost' IDENTIFIED BY 'una_clave_segura';
   GRANT SELECT, INSERT, UPDATE, DELETE ON aulasink.* TO 'aulasink_app'@'localhost';
   FLUSH PRIVILEGES;
   ```
3. **Configura el entorno**
   ```bash
   cp .env.example .env      # en Windows: copy .env.example .env
   ```
   Edita `.env`: `DB_USER`, `DB_PASSWORD` y `GROQ_API_KEY`.
4. **Arranca el servidor**
   ```bash
   npm start                 # o: npm run dev  (se reinicia al guardar cambios)
   ```
   Debes ver `✅ MySQL conectado` y `🚀 AulaSink en http://localhost:3000`.
5. **Abre http://localhost:3000** (localhost cuenta como origen seguro, así que el Service Worker funciona).

## Cómo probar el modo sin conexión
1. Inicia sesión **con conexión** y espera el aviso «✅ Listo para usar sin conexión» en el Inicio (descarga tus cursos y tareas).
2. DevTools → Network → marca **Offline** (o activa el modo avión). Recarga: la app, tus cursos y tus tareas siguen ahí, con un
   aviso «📴 Estás viendo la copia guardada…».
3. Estudiante: abre una tarea, responde, adjunta una foto y **Entrega**. Verás «📬 Entrega por enviar». Profesor: califica una
   entrega o crea una tarea nueva. Mira la pestaña **Sincronizar**: quedan acciones pendientes.
4. Desmarca Offline: todo se envía solo, en orden. Comprueba en MySQL:
   ```sql
   SELECT status, submitted_at, score_pct FROM submissions ORDER BY updated_at DESC LIMIT 5;
   ```
5. Las lecciones de práctica general (cuestionarios con `POST /api/sync`) siguen funcionando igual que antes:
   ```sql
   SELECT * FROM sync_queue ORDER BY received_at DESC;
   SELECT * FROM lesson_progress;
   ```

## API

### Cuentas y sesión
`POST /api/auth/register` `{name,email,password,role:'student'|'teacher',teacherCode?}` · `POST /api/auth/login` · `POST /api/auth/logout` ·
`GET /api/auth/me` · `POST /api/auth/password`. La sesión es una cookie `HttpOnly` (30 días); el servidor solo guarda su hash.

### Cursos, temario y tareas (resumen)
`/api/courses` (listar, crear, `join` con código, editar, eliminar) · `/:id/members` · `/:id/students` (añadir/quitar) ·
`/:id/lessons` y `/:id/assignments` (CRUD, orden) · `/:id/…/answers` (guardar avance) · `/:id/…/submit` (entregar) ·
`/:id/…/submissions` (profesor) · `/:id/uploads` (foto) · `/:id/gradebook` · `/:id/students/:sid/final` ·
`/api/submissions/:id` (+ `/grade`, `/return`) · `/api/files/:id` · `/api/me/overview`.
Un estudiante **nunca recibe la respuesta correcta antes de entregar**; el servidor califica la opción múltiple.

### `POST /api/sync`  (ahora requiere sesión de estudiante)
```json
{ "items": [{ "id": "uuid", "type": "quiz_attempt", "lessonId": "mate-01",
              "correct": 2, "total": 3, "createdAt": "2026-10-27T20:00:00.000Z",
              "answers": [{ "questionId": "mate-01-q1", "selected": 1, "correct": true }] }] }
```
Respuesta `200`: `{ ok, accepted: [ids], rejected: [{id, reason}], retry: [ids] }`
- `accepted`: guardados **o ya existentes** (idempotente: reenviar nunca duplica ni recuenta).
- `rejected`: datos inválidos; el navegador los descarta.
- `retry`: error temporal; se quedan en la cola del navegador.
- `4xx/5xx`: no se confirmó nada; el navegador conserva toda la cola.

La identidad del estudiante sale de la **sesión** (ya no del cuerpo de la petición). El servidor **recalcula la nota** (`correct/total`) y no confía en la que envíe el cliente.

### `POST /api/tutor`
`{ "message": "…", "lessonId": "mate-01", "history": [{"role":"user|assistant","content":"…"}] }` → `{ "reply": "…" }`

La API Key solo existe en el servidor. El historial solo admite roles `user`/`assistant`
(un `system` falso enviado por el cliente se descarta). Límite: 30 preguntas / 10 min por IP.

### `GET /api/health` → `{ ok, db, tutor }`

## Mantener el contenido sincronizado
Las lecciones están en `public/app.js` (`LESSONS`) y su catálogo en la tabla `lessons`
(`schema.sql`). Si añades una lección, agrega su `id` en **ambos** sitios; el servidor
rechaza intentos de lecciones que no estén en la tabla.

## Publicar
- **Un solo servicio (recomendado):** Render, Railway, Fly.io o un VPS ejecutan `server.js`, que ya
  sirve la PWA. Necesitas un MySQL gestionado (Railway, Aiven, PlanetScale…) y poner las variables
  de `.env` en el panel. Con proxy delante: `TRUST_PROXY=1`. HTTPS es obligatorio fuera de localhost.
- **Frontend en GitHub Pages / Vercel y API aparte:** en `public/app.js` pon URLs completas
  (`API_BASE`, `SYNC_ENDPOINT` y `TUTOR_ENDPOINT`, p. ej. `API_BASE: 'https://api.tudominio.com/api'`; las fotos también se piden a esa URL) y en `.env`
  `CORS_ORIGIN=https://tu-usuario.github.io`.
- **Cada vez que cambies archivos del frontend, sube `VERSION` en `public/sw.js`** (y si añades archivos `.js`, agrégalos a `PRECACHE_URLS`); si no, los
  dispositivos seguirán usando la versión guardada.

## Seguridad

Incluido: contraseñas con **scrypt**; sesiones con cookie `HttpOnly` + `SameSite`; comprobación de `Origin` (CSRF); límite de
intentos de login por cuenta+IP; cada ruta comprueba rol y pertenencia al curso (quien no tiene acceso recibe 404); fotos validadas
por su contenido real (JPG/PNG/WebP, máx. 3 MB) y visibles solo para su dueño y el profesor del curso.

Pendiente / a decidir antes de usarlo con estudiantes reales:
- **HTTPS** obligatorio fuera de localhost, y `COOKIE_SECURE=1`. Frontend y API deben servirse desde el **mismo dominio** (lo normal aquí);
  si los separas, define `CORS_ORIGIN` (la cookie pasa a `SameSite=None; Secure`).
- Para que solo docentes autorizados creen cuentas de profesor, define `TEACHER_SIGNUP_CODE`.
- No hay recuperación de contraseña por correo (un profesor puede crear la cuenta con clave temporal; el estudiante la cambia en su Perfil).
- Las fotos se guardan en `UPLOAD_DIR` (carpeta `uploads/`): inclúyela en tus copias de seguridad; en hostings con disco efímero usa un volumen persistente.
- **El tutor es una barrera de prompt, no una garantía.** Revisa conversaciones reales.
- **Datos de menores:** revisa la normativa de protección de datos aplicable (consentimiento, retención). El texto del estudiante se envía a Groq.

## Pruebas
```bash
npm test                                  # unitarias (preguntas, puntajes) + simulación sin conexión + tutor local: no necesitan base de datos
npm run test:offline                      # solo la simulación sin conexión (descargar → cortar señal → trabajar → reconectar)
BASE=http://localhost:3000 npm run test:api   # recorre la API completa con el servidor encendido
```
