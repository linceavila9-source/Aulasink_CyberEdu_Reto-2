@echo off
setlocal
chcp 65001 >nul
title AulaSink
cd /d "%~dp0"

echo ==================================================
echo   AulaSink - iniciando
echo ==================================================

rem --- 1. Node.js ---------------------------------------------------
where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo [ERROR] No se encontro Node.js.
  echo Instala la version LTS desde https://nodejs.org y vuelve a abrir iniciar.bat
  start "" https://nodejs.org
  pause
  exit /b 1
)

rem --- 2. Dependencias (solo la primera vez) -------------------------
if not exist node_modules\express (
  echo.
  echo Instalando dependencias, solo la primera vez...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo.
    echo [ERROR] No se pudieron instalar las dependencias. Revisa tu conexion a Internet.
    pause
    exit /b 1
  )
)

rem --- 3. Configuracion y base de datos (setup.js) -------------------
node setup.js
if errorlevel 1 (
  echo.
  pause
  exit /b 1
)

rem --- 4. Abrir el navegador en 3 segundos y arrancar el servidor ----
echo.
echo Abriendo http://localhost:3000
echo Para cerrar AulaSink, cierra esta ventana o pulsa Ctrl+C.
echo.
start "" /min powershell -NoProfile -WindowStyle Hidden -Command "Start-Sleep -Seconds 3; Start-Process 'http://localhost:3000'"

node server.js

echo.
echo El servidor se detuvo.
pause
