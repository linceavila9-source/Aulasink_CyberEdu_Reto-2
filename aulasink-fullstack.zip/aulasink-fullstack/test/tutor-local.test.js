'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const ctx = vm.createContext({});
vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'public', 'tutor-local.js'), 'utf8') + '\nthis.TutorLocal = TutorLocal;', ctx);
const T = ctx.TutorLocal;

const lesson = {
  id: 'mate-01', title: 'Fracciones: partes de un todo',
  paragraphs: [
    'Una fracción representa una o varias partes de un todo que se ha dividido en partes iguales.',
    'El número de abajo (denominador) indica en cuántas partes iguales se divide el todo. El de arriba (numerador) indica cuántas de esas partes tomamos.',
    'Ejemplo: si una pizza se corta en 8 porciones iguales y comes 3, comiste 3/8 de la pizza.',
    'Dos fracciones son equivalentes cuando representan la misma cantidad: 1/2 = 2/4 = 4/8.'],
  questions: [{ q: '¿Qué indica el denominador en la fracción 3/8?', explain: 'SECRETO-EXPLICACION', answer: 1 }]
};

test('genera preguntas predeterminadas con el contenido de la lección', () => {
  const list = T.entries(lesson);
  const qs = list.map(e => e.q);
  assert.ok(qs.some(q => q.includes('De qué trata')));
  assert.ok(qs.some(q => q.includes('puntos clave')));
  assert.ok(qs.some(q => q.includes('ejemplo')));
  assert.ok(qs.some(q => q.includes('pista para la pregunta 1')));
  assert.ok(qs.some(q => q.includes('equivalentes')), 'incluye las respuestas redactadas a mano de la lección');
  assert.ok(qs.some(q => q.includes('sin Internet')), 'incluye ayuda de la app');
  assert.ok(list.every(e => e.q && e.a), 'toda pregunta tiene respuesta');
});

test('la pista señala el fragmento pero NO filtra la respuesta del cuestionario', () => {
  const hint = T.entries(lesson).find(e => e.q.includes('pista para la pregunta 1')).a;
  assert.ok(hint.includes('denominador'));
  assert.ok(!hint.includes('SECRETO-EXPLICACION'));
  assert.match(hint, /No te doy la respuesta/);
});

test('el ejemplo sale del texto de la lección', () => {
  const a = T.entries(lesson).find(e => e.q.includes('ejemplo')).a;
  assert.ok(a.includes('pizza'));
});

test('entiende preguntas escritas (con tildes y variaciones)', () => {
  const list = T.entries(lesson);
  const r = T.answerFree('como se si dos fracciones son equivalentes?', lesson, list);
  assert.ok(r && r.answer.includes('MISMO número'));
  const r2 = T.answerFree('¿Puedo entregar mi tarea sin internet?', lesson, list);
  assert.ok(r2 && r2.answer.includes('Entregar'));
});

test('si no está en las respuestas, busca en el texto de la lección; si no hay nada, admite que no sabe', () => {
  const list = T.entries(lesson);
  const r = T.answerFree('que es el numerador', lesson, list);
  assert.ok(r && r.answer.includes('numerador'));
  assert.equal(T.answerFree('quien gano el mundial de futbol', lesson, list), null);
  assert.equal(T.answerFree('???', lesson, list), null);
});

test('sin lección, ofrece preguntas generales y de la app', () => {
  const list = T.entries(null);
  assert.ok(list.length >= 5);
  assert.ok(list.every(e => e.kind !== 'lesson'));
});
