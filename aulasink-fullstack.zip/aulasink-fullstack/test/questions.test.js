'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const Q = require('../lib/questions');

const mcq = { type: 'mcq', prompt: '2+2', options: ['3', '4'], correct: 1, points: 2, explanation: 'cuatro' };
const written = { type: 'written', prompt: 'Explica' };
const hand = { type: 'handwritten', prompt: 'Resuelve', points: 3 };

test('sanitizeQuestions asigna ids, puntos por defecto y valida opciones', () => {
  const qs = Q.sanitizeQuestions([mcq, written, hand]);
  assert.equal(qs.length, 3);
  assert.ok(qs.every(q => /^[A-Za-z0-9_-]{4,40}$/.test(q.id)));
  assert.equal(qs[1].points, 5);
  assert.equal(qs[0].correct, 1);
  assert.throws(() => Q.sanitizeQuestions([{ ...mcq, correct: 9 }]), /correcta/);
  assert.throws(() => Q.sanitizeQuestions([{ ...mcq, options: ['solo una'] }]), /opciones/);
  assert.throws(() => Q.sanitizeQuestions([{ ...mcq, options: ['a', ''] }]), /opciones/);
  assert.throws(() => Q.sanitizeQuestions([{ type: 'otro', prompt: 'x' }]), /tipo/);
  assert.throws(() => Q.sanitizeQuestions([{ type: 'written', prompt: '  ' }]), /enunciado/);
});

test('publicQuestions nunca expone la respuesta correcta ni la explicación', () => {
  const pub = Q.publicQuestions(Q.sanitizeQuestions([mcq]));
  assert.equal(JSON.stringify(pub).includes('correct'), false);
  assert.equal(JSON.stringify(pub).includes('cuatro'), false);
});

test('cleanAnswers descarta preguntas desconocidas y formas inválidas', () => {
  const qs = Q.sanitizeQuestions([mcq, written, hand]);
  const a = Q.cleanAnswers(qs, {
    [qs[0].id]: { selected: 7 },                       // fuera de rango
    [qs[1].id]: { text: '   ' },                       // vacío
    [qs[2].id]: { files: ['abcdefgh1', '../../etc', 5], text: 'nota' },
    desconocida: { text: 'x' }
  });
  assert.deepEqual(a, { [qs[2].id]: { files: ['abcdefgh1'], text: 'nota' } });
});

test('progreso, calificación automática y nota final', () => {
  const qs = Q.sanitizeQuestions([mcq, written, hand]);
  const answers = { [qs[0].id]: { selected: 1 }, [qs[1].id]: { text: 'hola' } };
  assert.equal(Q.progressPct(qs, answers), 67);
  const { total, auto, manualIds } = Q.autoGrade(qs, answers);
  assert.equal(total, 10);           // 2 + 5 + 3
  assert.equal(auto, 2);
  assert.deepEqual(manualIds, [qs[1].id, qs[2].id]);

  const grading = Q.sanitizeGrades(qs, { [qs[1].id]: { points: 4 }, [qs[2].id]: { points: 3, comment: 'ok' } });
  assert.ok(Q.allManualGraded(manualIds, grading));
  assert.equal(Q.scorePct(total, auto + Q.manualSum(manualIds, grading)), 90);
  assert.throws(() => Q.sanitizeGrades(qs, { [qs[1].id]: { points: 6 } }), /entre 0 y 5/);
});
