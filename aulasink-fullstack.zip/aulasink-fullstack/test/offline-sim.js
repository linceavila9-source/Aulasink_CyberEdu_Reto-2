/* =====================================================================
 * Simulación del modo sin conexión (sin navegador ni MySQL).
 * Carga api.js + offline.js en un contexto aislado con IndexedDB falsa y un
 * “servidor” en memoria, y comprueba el recorrido completo: descargar →
 * cortar la señal → trabajar → recuperar la señal → sincronizar.
 *   npm run test:offline
 * ===================================================================== */
'use strict';
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { test } = require('node:test');
require('fake-indexeddb/auto');
const { indexedDB, IDBKeyRange } = globalThis;

/* ---------- “servidor” en memoria ---------- */
function makeServer() {
  const log = [];
  const db = {
    submissions: {},
    lessons: [{ id: 'L1', title: 'Fracciones', published: true, questionCount: 1, hasManual: false, minutes: 5, position: 1 }],
    tasks: [{ id: 'T1', title: 'Tarea 1', published: true, questionCount: 1, hasManual: true, dueAt: '2030-01-01T00:00:00Z' }],
    files: 0
  };
  const taskDetail = () => ({ role: 'student', item: { id: 'T1', title: 'Tarea 1', questions: [{ id: 'q1', type: 'written', prompt: 'x', points: 5 }],
    instructions: 'Resuelve', dueAt: '2030-01-01T00:00:00Z', hasManual: true, submission: db.submissions.T1 || null, canSave: !db.submissions.T1 || db.submissions.T1.status === 'draft', canSubmit: true } });
  function handle(method, url, body) {
    log.push(`${method} ${url}`);
    const j = (status, data) => ({ ok: status < 400, status, json: async () => data });
    if (url === '/api/health') return j(200, { ok: true });
    if (method === 'GET') {
      if (url === '/api/me/overview') return j(200, { role: 'student', courses: [{ id: 'C1', name: 'Mate', subject: 'M', teacherName: 'Ana', finalGrade: null, stats: { progress: 0 } }],
        todo: db.submissions.T1 && db.submissions.T1.status === 'submitted' ? [] : [{ id: 'T1', title: 'Tarea 1', dueAt: null, courseId: 'C1', courseName: 'Mate', status: 'new' }] });
      if (url === '/api/courses') return j(200, { courses: [{ id: 'C1', name: 'Mate' }] });
      if (url === '/api/courses/C1') return j(200, { role: 'student', course: { id: 'C1', name: 'Mate', teacherName: 'Ana' } });
      if (url === '/api/courses/C1/me') return j(200, { stats: { progress: 0 }, finalGrade: null });
      if (url === '/api/courses/C1/members') return j(200, { members: [] });
      if (url === '/api/courses/C1/lessons') return j(200, { items: db.lessons.map(l => ({ ...l, submission: null })) });
      if (url === '/api/courses/C1/assignments') return j(200, { items: db.tasks.map(t => ({ ...t, submission: db.submissions.T1 || null })) });
      if (url === '/api/courses/C1/lessons/L1') return j(200, { role: 'student', item: { id: 'L1', title: 'Fracciones', questions: [], paragraphs: ['a'], submission: null, canSave: true, canSubmit: true } });
      if (url === '/api/courses/C1/assignments/T1') return j(200, taskDetail());
      return j(404, { error: 'No encontrado' });
    }
    if (url === '/api/courses/C1/assignments/T1/answers') { db.submissions.T1 = { status: 'draft', progressPct: 100, answers: body.answers }; return j(200, { ok: true }); }
    if (url === '/api/courses/C1/assignments/T1/submit') {
      db.submissions.T1 = { status: 'submitted', progressPct: 100, answers: body.answers, submittedAt: body.clientSubmittedAt }; return j(200, { ok: true, submission: { status: 'submitted' } });
    }
    if (url === '/api/courses/C1/uploads') { db.files++; return j(201, { id: 'file' + db.files }); }
    return j(404, { error: 'No encontrado' });
  }
  return { log, db, handle };
}

/* ---------- contexto del navegador simulado ---------- */
function makeBrowser(server) {
  const ls = new Map();
  const state = { online: true, serverUp: true, user: { id: 'u1', role: 'student', name: 'Eva' } };
  const toasts = [];
  const sandbox = {
    console, setTimeout, clearTimeout, setInterval, clearInterval, indexedDB, IDBKeyRange, structuredClone, URL, AbortController, JSON, Date, Promise, Math, Array, Object, Map, Set, Number, String, Error,
    crypto: { randomUUID: () => 'id' + Math.random().toString(36).slice(2) },
    localStorage: { getItem: k => (ls.has(k) ? ls.get(k) : null), setItem: (k, v) => ls.set(k, String(v)), removeItem: k => ls.delete(k) },
    navigator: { get onLine() { return state.online; }, serviceWorker: undefined },
    document: { hidden: false, addEventListener() {} },
    window: { addEventListener() {} },
    location: { hash: '' },
    caches: undefined,
    fetch: async (url, opts = {}) => {
      if (!state.online || !state.serverUp) throw new TypeError('Failed to fetch');
      return server.handle(opts.method || 'GET', url, opts.body ? JSON.parse(opts.body) : undefined);
    }
  };
  vm.createContext(sandbox);
  const run = code => vm.runInContext(code, sandbox);
  // Lo que normalmente aporta app.js
  run(`
    const CONFIG = { API_BASE: '/api' };
    const store = { get(k) { try { return localStorage.getItem(k); } catch { return null; } }, set(k, v) { localStorage.setItem(k, v); } };
    function uid() { return crypto.randomUUID(); }
    const __toasts = [];
    function toast(m, t) { __toasts.push(m); }
    function el() { return {}; }
    const Net = { get online() { return navigator.onLine && Link.state !== 'offline'; }, paint() {} };
    function refreshView() {}
  `);
  for (const f of ['api.js', 'offline.js']) run(fs.readFileSync(path.join(__dirname, '..', 'public', f), 'utf8'));
  run(`Auth.user = ${JSON.stringify(state.user)}; Mirror.use('u1');`);
  return { run, state, ls, toasts: () => run('__toasts') };
}

const go = async (b, code) => b.run(`(async () => { ${code} })()`);
const goOffline = async b => { b.state.online = false; await go(b, "Link.state = 'offline'; Link.fails = 2;"); };
const goOnline = async b => { b.state.online = true; await go(b, "Link.state = 'good'; Link.fails = 0;"); };

test('descarga todo y lo muestra sin conexión', async () => {
  const server = makeServer(); const b = makeBrowser(server);
  await go(b, 'await Offline.prefetch({ manual: true });');
  const st = await go(b, 'return Offline.status();');
  assert.equal(st.courses, 1);
  assert.equal(st.items, 2);                       // 1 lección + 1 tarea

  await goOffline(b);
  const before = server.log.length;
  const tasks = await go(b, "return Api.get('/courses/C1/assignments');");
  const detail = await go(b, "return Api.get('/courses/C1/assignments/T1');");
  const overview = await go(b, "return Api.get('/me/overview');");
  assert.equal(tasks.items[0].title, 'Tarea 1');
  assert.equal(detail.item.instructions, 'Resuelve');
  assert.equal(overview.todo.length, 1);
  assert.equal(server.log.length, before, 'sin conexión no debe tocar la red');
  await assert.rejects(go(b, "return Api.get('/courses/C1/lessons/NOEXISTE');"), e => e.offline);
});

test('estudiante: avance y entrega sin conexión se ven al instante y se envían al reconectar', async () => {
  const server = makeServer(); const b = makeBrowser(server);
  await go(b, 'await Offline.prefetch({ manual: true });');
  await goOffline(b);

  // avance (borrador)
  let r = await go(b, `return Api.mutate('PUT', '/courses/C1/assignments/T1/answers', { answers: { q1: { text: 'a medias' } } },
    { label: 'Avance', key: 'draft:assignment:T1', op: { k: 'draft', cid: 'C1', seg: 'assignments', tid: 'T1', answers: { q1: { text: 'a medias' } }, progress: 100 } });`);
  assert.equal(r.queued, true);
  let d = await go(b, "return Api.get('/courses/C1/assignments/T1');");
  assert.equal(d.item.submission.status, 'draft');
  assert.equal(d.item.submission.answers.q1.text, 'a medias');
  assert.equal(d.item.submission.pendingSync, true);

  // entrega: reemplaza al borrador en la cola
  r = await go(b, `return Api.mutate('POST', '/courses/C1/assignments/T1/submit', { answers: { q1: { text: 'final' } }, clientSubmittedAt: '2026-11-02T10:00:00.000Z' },
    { label: 'Entrega', key: 'submit:assignment:T1', ok409: true, supersede: ['draft:assignment:T1'],
      op: { k: 'submit', cid: 'C1', seg: 'assignments', tid: 'T1', answers: { q1: { text: 'final' } } } });`);
  assert.equal(r.queued, true);
  assert.equal(await go(b, 'return Queue.count();'), 1, 'la entrega anula al borrador');

  d = await go(b, "return Api.get('/courses/C1/assignments/T1');");
  assert.equal(d.item.submission.status, 'submitted');
  assert.equal(d.item.canSave, false);
  const list = await go(b, "return Api.get('/courses/C1/assignments');");
  assert.equal(list.items[0].submission.status, 'submitted');
  assert.equal(list.items[0].submission.pendingSync, true);
  const ov = await go(b, "return Api.get('/me/overview');");
  assert.equal(ov.todo.length, 0, 'la tarea entregada sale de pendientes');

  // vuelve la señal
  await goOnline(b);
  server.log.length = 0;
  await go(b, 'await Queue.flush();');
  assert.equal(await go(b, 'return Queue.count();'), 0);
  assert.deepEqual(server.log.filter(l => l.startsWith('POST') || l.startsWith('PUT')), ['POST /api/courses/C1/assignments/T1/submit']);
  assert.equal(server.db.submissions.T1.status, 'submitted');
  assert.equal(server.db.submissions.T1.submittedAt, '2026-11-02T10:00:00.000Z', 'se conserva la hora real de la entrega');

  // y la copia local ya refleja al servidor, sin “pendiente”
  d = await go(b, "return Api.get('/courses/C1/assignments/T1');");
  assert.equal(d.item.submission.status, 'submitted');
  assert.ok(!d.item.submission.pendingSync);
});

test('foto tomada sin conexión: se guarda local y se sube sola antes de enviar', async () => {
  const server = makeServer(); const b = makeBrowser(server);
  await go(b, 'await Offline.prefetch({ manual: true });');
  await goOffline(b);
  const id = await go(b, "return Photos.save('C1', 'data:image/jpeg;base64,AAAA');");
  assert.ok(id.startsWith('local-'));
  assert.equal(await go(b, `return Photos.dataUrl('${id}');`), 'data:image/jpeg;base64,AAAA');
  await go(b, `return Api.mutate('POST', '/courses/C1/assignments/T1/submit', { answers: { q1: { files: ['${id}'] } } },
    { key: 'submit:assignment:T1', op: { k: 'submit', cid: 'C1', seg: 'assignments', tid: 'T1', answers: { q1: { files: ['${id}'] } } } });`);
  await goOnline(b);
  await go(b, 'await Queue.flush();');
  assert.equal(await go(b, 'return Queue.count();'), 0);
  assert.deepEqual(server.db.submissions.T1.answers.q1.files, ['file1'], 'el id provisional se cambió por el real');
});

test('profesor: crea, edita y elimina sin conexión sin duplicar ni perder nada', async () => {
  const server = makeServer(); const b = makeBrowser(server);
  await go(b, "Auth.user = { id: 't1', role: 'teacher', name: 'Prof' }; Mirror.use('t1');");
  await goOffline(b);
  const payload = { id: 'NEWID001', title: 'Lección nueva', content: 'texto', minutes: 7, published: true, questions: [] };
  let r = await go(b, `return Offline.saveItem('C1', 'lessons', ${JSON.stringify(payload)}, { isNew: true, label: 'L' });`);
  assert.equal(r.queued, true);
  // editar de nuevo desde la lista: debe seguir siendo “crear” (POST), no PUT a algo que el servidor no conoce
  await go(b, `return Offline.saveItem('C1', 'lessons', ${JSON.stringify({ ...payload, title: 'Lección nueva v2' })}, { isNew: false, label: 'L' });`);
  const q = await go(b, 'return Queue.list();');
  assert.equal(q.length, 1);
  assert.equal(q[0].method, 'POST');
  assert.equal(q[0].body.title, 'Lección nueva v2');

  // se puede abrir para editarla aunque nunca se descargó
  const d = await go(b, "return Api.get('/courses/C1/lessons/NEWID001');");
  assert.equal(d.item.title, 'Lección nueva v2');
  assert.equal(d.item.minutes, 7);

  // eliminarla anula la creación pendiente
  await go(b, "return Offline.removeItem('C1', 'lessons', 'NEWID001', 'Eliminar');");
  const after = await go(b, 'return Queue.list();');
  assert.equal(after.length, 1);
  assert.equal(after[0].method, 'DELETE');
  assert.equal(after[0].ok404, true);
  await goOnline(b);
  await go(b, 'await Queue.flush();');          // el servidor responde 404 → se considera hecho
  assert.equal(await go(b, 'return Queue.count();'), 0);
});

test('profesor: calificar sin conexión actualiza la entrega, la lista y el panel', async () => {
  const server = makeServer(); const b = makeBrowser(server);
  await go(b, "Auth.user = { id: 't1', role: 'teacher', name: 'Prof' }; Mirror.use('t1');");
  await go(b, `await Mirror.set('/submissions/S1', { submission: { id: 'S1', status: 'submitted', scorePct: null, manualPoints: null, answers: {}, grading: {}, teacherComment: null },
      student: { name: 'Eva' }, course: { id: 'C1' }, target: { type: 'assignment', id: 'T1' }, questions: [] });
    await Mirror.set('/courses/C1/assignments/T1/submissions', { rows: [{ student: { id: 'u1' }, submission: { id: 'S1', status: 'submitted', scorePct: null } }] });
    await Mirror.set('/me/overview', { role: 'teacher', totals: { pending: 1 }, pending: [{ id: 'S1' }] });
    await Mirror.set('/courses/C1/gradebook', { students: [{ id: 'u1', finalGrade: null, finalComment: null }] });`);
  await goOffline(b);
  await go(b, `return Api.mutate('PUT', '/submissions/S1/grade', { grades: { q2: { points: '4', comment: 'bien' } }, comment: 'Buen trabajo' },
    { key: 'grade:S1', op: { k: 'grade', sid: 'S1', grades: { q2: { points: '4', comment: 'bien' } }, comment: 'Buen trabajo', status: 'graded', scorePct: 80, manualPoints: 4 } });`);
  await go(b, `return Api.mutate('PUT', '/courses/C1/students/u1/final', { grade: 90, comment: 'ok' },
    { key: 'final:C1:u1', op: { k: 'final', cid: 'C1', studentId: 'u1', grade: 90, comment: 'ok' } });`);

  const s = await go(b, "return Api.get('/submissions/S1');");
  assert.equal(s.submission.status, 'graded');
  assert.equal(s.submission.scorePct, 80);
  assert.equal(s.submission.grading.q2.points, 4);
  assert.equal(s.submission.teacherComment, 'Buen trabajo');
  const rows = await go(b, "return Api.get('/courses/C1/assignments/T1/submissions');");
  assert.equal(rows.rows[0].submission.status, 'graded');
  const ov = await go(b, "return Api.get('/me/overview');");
  assert.equal(ov.pending.length, 0);
  assert.equal(ov.totals.pending, 0);
  const gb = await go(b, "return Api.get('/courses/C1/gradebook');");
  assert.equal(gb.students[0].finalGrade, 90);
});

test('la copia guardada nunca se contamina con lo pendiente', async () => {
  const server = makeServer(); const b = makeBrowser(server);
  await go(b, 'await Offline.prefetch({ manual: true });');
  await goOffline(b);
  await go(b, `return Api.mutate('POST', '/courses/C1/assignments/T1/submit', { answers: {} },
    { key: 'submit:assignment:T1', op: { k: 'submit', cid: 'C1', seg: 'assignments', tid: 'T1', answers: {} } });`);
  await go(b, "await Api.get('/courses/C1/assignments/T1');");
  const raw = await go(b, "return (await Mirror.get('/courses/C1/assignments/T1')).data;");
  assert.equal(raw.item.submission, null, 'la copia sigue siendo lo que dijo el servidor');
});
